# Railway Environment Variable Setup
## Required GitHub Repository Secrets
**RAILWAY_TOKEN:**
1. Go to https://railway.app/account/tokens
2. Click "Create Token" -- name it (e.g., "GitHub Actions")
3. Copy token immediately
**Add to GitHub:** Repository > Settings > Secrets and variables > Actions > New repository secret
## GitHub Actions Variables (non-secret)
Set in Repository > Settings > Secrets and variables > Actions > Variables tab:
| Variable | Description | Example |
|----------|-------------|---------|
| `RAILWAY_SERVICE` | Service name for production deployment | `web` |
| `RAILWAY_PRODUCTION_URL` | Production URL for health checks | `https://myapp.up.railway.app` |
## Railway Service Variables
Set per-service in Dashboard (Service > Variables tab):
| Variable | Scope | Description |
|----------|-------|-------------|
| `DATABASE_URL` | All environments | Database connection (auto-set for Railway databases) |
| `PORT` | Auto-injected | Railway assigns port automatically |
| `RAILWAY_ENVIRONMENT` | Auto-injected | Current environment name |
| `REDIS_URL` | All environments | Redis connection (auto-set for Railway Redis) |
## Tips
- Always use `process.env.PORT` for server
- Use Railway internal networking for service-to-service: `${{web.RAILWAY_PRIVATE_DOMAIN}}`
- Shared variables propagate across all services
- PR env vars inherit from parent environment (staging by default)

---
name: railway-project-setup
description: Configure automated preview, staging, and production deployments with Railway
version: "0.55.0"
license: Complete terms in LICENSE.txt
---
**Purpose:** Guide developers through setting up Railway deployments with GitHub Actions integration
**Audience:** Developers deploying web applications and services to Railway
**Related Skills:** `ci-cd-pipeline-design` -- for broader CI/CD pipeline architecture
## Initial Setup
**Prerequisites:**
- Railway account (free tier or Pro plan for team features)
- Railway CLI: `npm install -g @railway/cli`
- GitHub repository with push access
```bash
railway login
railway link    # Link existing project
railway init    # Or initialize new project
```
**Project Structure:**
- **Project**: Top-level container (e.g., "my-app")
- **Service**: Individual deployable unit (e.g., "web", "api", "worker")
- **Environment**: Deployment target (e.g., "production", "staging", "pr-123")
## Environment Configuration
**Required Secrets** (GitHub > Settings > Secrets and variables > Actions):
| Secret | Source | Description |
|--------|--------|-------------|
| `RAILWAY_TOKEN` | Railway Dashboard > Account > Tokens | API authentication token |
**Environment Variables** (Service > Variables tab):
- Variables scoped to environments (production, staging, PR)
- Shared variables for cross-service configuration
- Auto-injected: `PORT`, `RAILWAY_ENVIRONMENT`, `RAILWAY_SERVICE_NAME`
See `resources/env-setup.md` for complete guide.
## GitHub Integration
**Native GitHub Integration:**
1. Connect GitHub repo in Dashboard (Project > Settings > Source)
2. Select branch for production deploys
3. Enable PR environments for preview deployments
**GitHub Actions Deployment:**
```yaml
- name: Deploy to Railway
  run: railway up --service ${{ vars.RAILWAY_SERVICE }}
  env:
    RAILWAY_TOKEN: ${{ secrets.RAILWAY_TOKEN }}
```
## PR Environments (Preview Deployments)
1. Dashboard: Project > Settings > Environments > Enable "PR Environments"
2. Each PR gets a full environment with its own service instances, database instances (cloned), and env vars
3. Automatically destroyed when PR is closed or merged
**Limitations:** Share project resource limits; database cloning may increase costs; some external services need manual config per PR.
## Deployment Strategies
**Production:** Auto-deploys from configured branch (`main` -> Production).
**Staging:**
1. Dashboard > Project > Environments > New Environment
2. Name "staging", configure branch trigger (e.g., `develop`)
**Manual Deployment:**
```bash
railway up --service web
railway up --service web --environment staging
```
**Rollback:**
```bash
railway deployments
railway rollback
```
## Monitoring and Debugging
```bash
railway logs --service web
railway logs --deployment-id <id>
```
**Dashboard:** CPU/memory/network metrics, real-time logs with search, deployment history with build logs.
**Health Checks** (`railway.toml`):
```toml
[deploy]
healthcheckPath = "/api/health"
healthcheckTimeout = 30
```
## Common Pitfalls
**Build Issues:**
- **Nixpacks detection failure**: Ensure standard config files exist or specify custom Dockerfile
- **Build timeout**: Optimize with `.railwayignore`
- **Missing dependencies**: Declare all system dependencies for Nixpacks
**Deployment Issues:**
- **Port binding**: Listen on `process.env.PORT` or `0.0.0.0:$PORT`
- **Database connection drops**: Use connection pooling; configure `PGBOUNCER_URL` for PostgreSQL
- **Cold starts**: Pro plan keeps services running; free tier may sleep
**CI/CD Issues:**
- **Token scoping**: Ensure `RAILWAY_TOKEN` has access to target project
- **Service targeting**: Always specify `--service` for multi-service projects
- **Environment isolation**: PR env vars default to staging unless overridden
## Resources
- `resources/railway.toml` -- Reference Railway configuration
- `resources/deploy.yml` -- GitHub Actions workflow
- `resources/env-setup.md` -- Environment variable setup guide

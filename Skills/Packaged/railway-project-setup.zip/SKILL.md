---
name: railway-project-setup
description: Configure automated preview, staging, and production deployments with Railway
version: "0.58.0"
license: Complete terms in LICENSE.txt
category: platform
relevantTechStack: [railway, docker, node, python, deployment]
invocationMode: direct-only
---
# Skill: railway-project-setup
**Purpose:** Guide developers through setting up Railway deployments with GitHub Actions integration
**Audience:** Developers deploying web applications and services to Railway
**Related Skills:** `ci-cd-pipeline-design` — for broader CI/CD pipeline architecture

## Overview
The `railway-project-setup` skill provides structured guidance for configuring Railway deployments across preview (PR environments), staging, and production environments. Railway excels at deploying full-stack applications with databases, background workers, and cron jobs in a unified platform.

## Initial Setup

### Prerequisites
- Railway account (free tier or Pro plan for team features)
- Railway CLI installed: `npm install -g @railway/cli`
- GitHub repository with push access

### Linking Your Project
```bash
# Login to Railway
railway login

# Link to an existing project
railway link

# Or initialize a new project
railway init
```

### Project Structure
Railway organizes deployments around **services** within a **project**:
- **Project**: Top-level container (e.g., "my-app")
- **Service**: Individual deployable unit (e.g., "web", "api", "worker")
- **Environment**: Deployment target (e.g., "production", "staging", "pr-123")

## Environment Configuration

### Required Secrets
Configure in GitHub repository settings (Settings > Secrets and variables > Actions):
| Secret | Source | Description |
|--------|--------|-------------|
| `RAILWAY_TOKEN` | Railway Dashboard > Account > Tokens | API authentication token |

### Environment Variables
Set per-service variables in the Railway Dashboard (Service > Variables tab):
- Variables are scoped to environments (production, staging, PR)
- Use shared variables for cross-service configuration
- Railway auto-injects `PORT`, `RAILWAY_ENVIRONMENT`, and `RAILWAY_SERVICE_NAME`
See `resources/env-setup.md` for a complete guide.

## GitHub Integration

### Native GitHub Integration
Railway offers built-in GitHub integration that auto-deploys on push:
1. Connect GitHub repo in Railway Dashboard (Project > Settings > Source)
2. Select branch for production deploys
3. Enable PR environments for preview deployments

### GitHub Actions Deployment
For more control, use GitHub Actions with the Railway CLI:
```yaml
# See resources/deploy.yml for complete workflow
- name: Deploy to Railway
  run: railway up --service ${{ vars.RAILWAY_SERVICE }}
  env:
    RAILWAY_TOKEN: ${{ secrets.RAILWAY_TOKEN }}
```

## PR Environments (Preview Deployments)
Railway's PR environments create isolated copies of your services for each pull request.

### Enabling PR Environments
1. In Railway Dashboard: Project > Settings > Environments
2. Enable "PR Environments"
3. Each PR gets a full environment with its own:
   - Service instances
   - Database instances (cloned from staging/production)
   - Environment variables

### Automatic Cleanup
PR environments are automatically destroyed when the PR is closed or merged.

### Limitations
- PR environments share the project's resource limits
- Database cloning may increase costs on large datasets
- Some external services may need manual configuration per PR

## Deployment Strategies

### Production via Branch Deploy
Railway deploys automatically when commits land on the configured production branch:
```
main branch → Production environment (automatic)
```

### Staging Environment
Create a dedicated staging environment in Railway:
1. Railway Dashboard > Project > Environments > New Environment
2. Name it "staging"
3. Configure branch trigger (e.g., `develop`)

### Manual Deployment
```bash
# Deploy current directory to a specific service
railway up --service web

# Deploy to a specific environment
railway up --service web --environment staging
```

### Rollback
```bash
# List recent deployments
railway deployments

# Rollback to a previous deployment
railway rollback
```

## Monitoring and Debugging

### Deployment Logs
```bash
# Stream logs from a service
railway logs --service web

# View logs from a specific deployment
railway logs --deployment-id <id>
```

### Railway Dashboard
- **Metrics**: CPU, memory, and network usage per service
- **Logs**: Real-time log streaming with search and filtering
- **Deployments**: History with build logs and status

### Health Checks
Railway supports health check configuration in `railway.toml`:
```toml
[deploy]
healthcheckPath = "/api/health"
healthcheckTimeout = 30
```

## Common Pitfalls and Troubleshooting

### Build Issues
- **Nixpacks detection failure**: Ensure your project has standard config files (`package.json`, `requirements.txt`, etc.) or specify a custom Dockerfile
- **Build timeout**: Large projects may exceed default build time. Optimize with `.railwayignore` to exclude unnecessary files
- **Missing dependencies**: Railway uses Nixpacks by default. Ensure all system dependencies are declared

### Deployment Issues
- **Port binding**: Railway injects `PORT` automatically. Listen on `process.env.PORT` or `0.0.0.0:$PORT`
- **Database connection drops**: Use connection pooling and configure `PGBOUNCER_URL` for PostgreSQL
- **Cold starts**: Railway keeps services running on Pro plan. Free tier may sleep after inactivity

### CI/CD Issues
- **Token scoping**: Ensure `RAILWAY_TOKEN` has access to the target project
- **Service targeting**: Always specify `--service` when deploying to multi-service projects
- **Environment isolation**: PR environment variables default to staging values unless overridden

## Configuration Reference

### railway.toml
See `resources/railway.toml` for a reference configuration covering:
- Build settings (builder, build command)
- Deploy settings (start command, health checks, replicas)
- Environment-specific overrides

## Related Skills
- **`ci-cd-pipeline-design`** — Architecture patterns for CI/CD pipelines, stage design, and security considerations

## Resources
- `resources/railway.toml` — Reference Railway configuration
- `resources/deploy.yml` — GitHub Actions workflow for Railway deployment
- `resources/env-setup.md` — Environment variable setup guide

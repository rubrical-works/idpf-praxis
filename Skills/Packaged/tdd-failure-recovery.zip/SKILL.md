---
name: tdd-failure-recovery
description: Guide experienced developers through TDD failure scenarios and recovery procedures when tests behave unexpectedly
version: "0.52.0"
license: Complete terms in LICENSE.txt
---
# TDD Failure Recovery
## When to Use
- RED phase test passes unexpectedly (should fail)
- GREEN phase test still fails (should pass)
- REFACTOR phase breaks tests (should stay green)
- Tests behave unpredictably or inconsistently
- Need to rollback to previous working state
## Prerequisites
- Knowledge of current TDD phase (RED/GREEN/REFACTOR)
- Test execution capability via Claude Code
- Version control or ability to undo changes
## Scenario 1: RED Phase Test Passes Unexpectedly
**Expected:** FAIL | **Actual:** PASSES
> "RED phase test passes unexpectedly: The test is invalid; ASSISTANT revises the test"
**Causes:** Feature already exists, test too permissive (assertion too broad, testing wrong thing, mock returns success), test setup incorrect (not exercising code, bypassing implementation)
**Recovery:**
1. **Verify test executes** - Add intentional failure, confirm test can fail, remove it
2. **Check existing implementation** - Search codebase; if found: delete impl OR test different behavior; verify fails
3. **Review test logic** - Correct assertion? Calling actual impl? Represents requirement?
4. **Revise test** - ASSISTANT provides corrected test, verify fails as expected
5. **Resume** - Proceed autonomously to GREEN phase
## Scenario 2: GREEN Phase Test Still Fails
**Expected:** PASS | **Actual:** Still FAILS
> "GREEN phase test fails: Implementation is incomplete; ASSISTANT revises the code"
**Causes:** Implementation incomplete/buggy, test expectations misunderstood, environmental issues
**Recovery:**
1. **Read failure message** - Expected vs actual, specific mismatch
2. **Verify implementation** - Executes without errors? Matches requirements?
3. **Check test requirements** - Re-read assertions, verify test data
4. **Revise implementation** - ASSISTANT provides corrected code, verify passes
5. **Run full test suite** - Ensure no regressions
6. **Resume** - Proceed autonomously to REFACTOR phase
## Scenario 3: REFACTOR Phase Breaks Tests
**Expected:** All GREEN | **Actual:** Tests FAIL
> "Refactoring breaks tests: Roll back refactoring; tests must stay green"
**Causes:** Behavioral change introduced, breaking API change, incomplete refactoring, test coupled to implementation
**Recovery:**
1. **IMMEDIATE ROLLBACK** - Undo changes, return to last green, verify green
```
TESTS MUST STAY GREEN
If refactoring breaks tests -> ROLLBACK
Do not proceed with broken tests
```
2. **Analyze** - Which tests? What failure? What refactoring caused it?
3. **Decide:**
   - **Skip** - Too risky, defer
   - **Smaller refactoring** - Micro-steps, test after each
   - **Fix test** - If over-coupled, update to test behavior not implementation
4. **Resume** - Proceed to next behavior or complete story
## Scenario 4: Rollback Procedure
**Valid:** Refactoring broke tests, implementation worse, wrong path, need known good state
```
TASK: Rollback to previous working state
STEP 1: [Identify changes to undo]
STEP 2: [Restore previous code version]
STEP 3: [Verify file state matches pre-change]
STEP 4: [Run full test suite]
STEP 5: [Verify all tests GREEN]
STEP 6: [Report back: Tests green and rollback complete?]
```
## Scenario 5: Inconsistent Test Results
**Causes:** Test order dependency (shared state), timing issues (race conditions, async), external dependencies (DB, network), random data
**Recovery:**
1. **Isolate** - Run test alone, different order
2. **Check isolation** - Cleans up? Own data? External state?
3. **Fix** - Setup/teardown, fixtures, mock externals, ensure determinism
4. **Verify** - Run multiple times, full suite
## Diagnostic Flowchart
```
Test failed unexpectedly
    |
What phase?
    |
+----------+-----------+------------+
RED        GREEN       REFACTOR
|          |           |
Should     Should      Should
fail       pass        stay green
|          |           |
But        But         But
passes     fails       fails
|          |           |
Test       Impl.       ROLLBACK
invalid    incomplete  immediately
|          |           |
Revise     Revise      Try smaller
test       impl.       or skip
```
## Prevention
- **RED:** Always run and verify fails; check failure message
- **GREEN:** Run and verify passes; full suite for regressions
- **REFACTOR:** Full suite after every change; small steps; rollback on failure
**Golden rule:**
```
Tests ALWAYS green except during RED phase
If not green when expected -> STOP and recover
```
## Common Recovery Patterns
| Pattern | Situation | Action |
|---------|-----------|--------|
| Reset | Confused state | Rollback to last green |
| Minimal Fix | Clear fix needed | Targeted correction |
| Skip | Risk > reward | Defer, maintain green |
| Divide & Conquer | Large change broke | Break into smaller changes |
## Resources
- `resources/failure-diagnostic-flowchart.md` - Visual decision tree
- `resources/recovery-procedures.md` - Step-by-step recovery per scenario
- `resources/test-isolation-guide.md` - Ensuring test independence
## Relationship to Other Skills
**Supports:** `tdd-red-phase`, `tdd-green-phase`, `tdd-refactor-phase`
**Related:** `test-writing-patterns`
---
**End of TDD Failure Recovery Skill**

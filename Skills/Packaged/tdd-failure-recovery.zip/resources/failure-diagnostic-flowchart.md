# TDD Failure Diagnostic Flowchart
**Version:** {{VERSION}}
## Primary Decision: Which Phase?
```
Test behaved unexpectedly
         |
  What phase are you in?
         |
+--------+--------+--------+
RED     GREEN    REFACTOR  OTHER
|        |         |        |
```
## RED Phase Diagnostics
**Expected:** FAIL | **Problem:** PASSES or ERRORS
### If Test Passes (Should Fail)
```
Test passes unexpectedly
         |
Check: Does feature already exist?
         |
    +----+----+
   YES       NO
    |         |
Delete    Check test
impl.     logic
    |         |
Verify    Is assertion
fails     correct?
         |
    +----+----+
   YES       NO
    |         |
Other    Fix test
issue    assertion
         |
      Revise test
```
**Recovery:** ASSISTANT provides corrected test
### If Test Errors (Should Fail Cleanly)
```
Test throws error/exception
         |
Syntax error? -> Fix syntax
No? -> Check imports/setup -> Fix test code -> Run again
```
## GREEN Phase Diagnostics
**Expected:** PASS | **Problem:** Still FAILS
```
Test fails after implementation
         |
Read failure message
         |
+---------+---------+---------+
Logic    Type      Missing
error    mismatch  feature
|        |         |
Fix      Fix       Add impl.
         |
    Run test again
    +----+----+
   PASS      FAIL -> Revise impl. again
    |
  GREEN phase done
```
### If Other Tests Break
```
Target passes BUT others fail -> Regression
Fix implementation to satisfy all tests -> Run full suite -> All green? Done
```
## REFACTOR Phase Diagnostics
**Expected:** GREEN | **Problem:** FAIL after refactoring
```
Tests fail after refactoring
         |
IMMEDIATE: ROLLBACK
         |
Undo changes -> Run tests
         |
All green? -> Decide: Skip / Try smaller / Fix test (if brittle)
Not green? -> Fix rollback first
```
## Inconsistent Test Results
```
Inconsistent results -> Run test alone (isolated)
Still inconsistent? -> Check: timing, random data, async ops
Order-dependent? -> Fix isolation: setup, teardown, shared state
```
## Quick Reference Table
| Phase    | Expected | Actual        | Action                    |
|----------|----------|---------------|---------------------------|
| RED      | FAIL     | PASS          | Revise test (invalid)     |
| RED      | FAIL     | ERROR         | Fix test (bug in test)    |
| GREEN    | PASS     | FAIL          | Revise impl (incomplete)  |
| GREEN    | PASS     | Others FAIL   | Fix regression            |
| REFACTOR | All PASS | Any FAIL      | ROLLBACK immediately      |
## Emergency Procedure
1. STOP
2. ROLLBACK to last known green state
3. Run full test suite
4. Verify all green
5. Start fresh, proceed carefully

# TDD Failure Recovery Procedures
**Version:** {{VERSION}}
## Test Pollution Recovery
**Symptom:** Tests pass in isolation but fail together
1. **Identify polluting test** - Run failing test alone (passes?), binary search with half the tests
2. **Find shared state** - Global variables, class attributes, DB records, file artifacts
3. **Fix isolation:**
   - Add cleanup in polluting test
   - Add setup in affected test
   - Use fresh fixtures per test
4. **Verify** - Run full suite multiple times, different orders
## Fixture Failure Recovery
**Symptom:** Setup or teardown fails
1. **Read error** - Which fixture? Setup or teardown? Missing resource?
2. **Check dependencies** - DB connection? Required files? External services?
3. **Fix:**
   - Database: ensure test DB exists
   - Files: create required test files
   - Services: mock external dependencies
4. **Add resilience** - try/finally for cleanup, precondition checks, clear error messages
5. **Verify** - Run affected tests, full suite
## Assertion Failure Recovery
**Symptom:** Assertion fails with unexpected value
1. **Read message:** `Expected: [X] Actual: [Y]`
2. **Root cause:**
   | Situation | Likely Cause |
   |-----------|--------------|
   | Expected correct, actual wrong | Implementation bug |
   | Expected wrong, actual correct | Test needs updating |
   | Both wrong | Requirements misunderstood |
3. **Fix:** Implementation bug -> fix code | Test outdated -> update test | Unclear -> clarify both
4. **Verify** - Specific test, related tests, full suite
## Timeout Failure Recovery
**Symptom:** Test fails due to timeout
1. **Type** - Framework, network, database, or async timeout
2. **Cause** - Infinite loop, slow query, network issue, deadlock
3. **Fix** - Fix slow code, mock slow deps, increase timeout only as last resort
## Flaky Test Recovery
**Symptom:** Passes sometimes, fails randomly
1. **Confirm** - Run 10+ times
2. **Source** - After specific test (pollution), random timing (race condition), local vs CI (environment)
3. **Fix** - Pollution: isolation | Race: synchronization | Environment: mock externals
## Quick Recovery Checklist
- [ ] Read full error message
- [ ] Check if test passes in isolation
- [ ] Review recent changes
- [ ] Apply recovery procedure
- [ ] Run full suite before proceeding

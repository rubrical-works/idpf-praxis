# Test Isolation Guide
**Version:** {{VERSION}}
Tests must be: **Independent** (any order), **Repeatable** (same result), **Self-contained** (own setup/cleanup)
## Mocking External Dependencies
**When:** External APIs, third-party services, system clock, random generators
```python
def test_user_creation():
    mock_email = Mock()
    user_service = UserService(email_service=mock_email)
    user_service.create_user("test@example.com")
    mock_email.send.assert_called_once()
```
**Key:** Mock at boundaries, inject dependencies, verify mock calls
## Test Doubles
| Type | Purpose | Use When |
|------|---------|----------|
| **Stub** | Returns fixed data | Need predictable input |
| **Mock** | Verifies interactions | Testing calls were made |
| **Fake** | Simplified implementation | Need working but fast version |
| **Spy** | Records calls to real object | Need real behavior + verification |
## Database Isolation
**Transaction Rollback:** `setUp: db.begin()` / `tearDown: db.rollback()` - Fast, automatic
**Fresh DB Per Test:** `setUp: db.create_all()` / `tearDown: db.drop_all()` - Complete isolation, slower
**In-Memory:** `sqlite:///:memory:` - Very fast, no cleanup
**Key:** Never share DB state, each test creates own data
## File System Isolation
**Temp directories:** `setUp: tempfile.mkdtemp()` / `tearDown: shutil.rmtree()`
**Mock file ops:** `@patch('builtins.open', mock_open(read_data='content'))`
**Key:** Never write to real project dirs, clean up in tearDown
## State Isolation Checklist
Before each test:
- [ ] Database in known state
- [ ] No leftover files
- [ ] Global variables reset
- [ ] Mocks configured fresh
After each test:
- [ ] Database rolled back/cleaned
- [ ] Temp files deleted
- [ ] Mocks reset
- [ ] Resources released
## Quick Reference
| What to Isolate | How |
|-----------------|-----|
| External APIs | Mock/Stub |
| Database | Transaction rollback or fresh DB |
| File system | Temp directories or mock |
| Time | Mock datetime/clock |
| Random values | Fixed seed or mock |
| Global state | Reset in setUp/tearDown |

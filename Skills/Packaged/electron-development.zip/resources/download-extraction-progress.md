# Framework Download and Extraction Pattern
## Problem
Downloading files in Electron needs progress tracking and reliable extraction.
## Solution
Electron `net` module for downloading, `adm-zip` for extraction, IPC events for progress.
## Download with Progress
```typescript
import { net } from 'electron';
import * as fs from 'fs';

export async function downloadFile(
  url: string, destPath: string,
  onProgress?: (progress: DownloadProgress) => void
): Promise<void> {
  return new Promise((resolve, reject) => {
    const request = net.request({ url, method: 'GET' });
    const chunks: Buffer[] = [];
    request.on('response', (response) => {
      // Handle GitHub redirects (302 to S3)
      if (response.statusCode >= 300 && response.statusCode < 400) {
        const redirectUrl = response.headers.location as string;
        downloadFile(redirectUrl, destPath, onProgress).then(resolve).catch(reject);
        return;
      }
      const contentLength = parseInt(response.headers['content-length'] as string, 10) || 0;
      let bytesDownloaded = 0;
      response.on('data', (chunk) => {
        chunks.push(chunk);
        bytesDownloaded += chunk.length;
        onProgress?.({ bytesDownloaded, totalBytes: contentLength,
          percentage: contentLength ? Math.round((bytesDownloaded / contentLength) * 100) : 0 });
      });
      response.on('end', () => { fs.writeFileSync(destPath, Buffer.concat(chunks)); resolve(); });
    });
    request.on('error', reject);
    request.end();
  });
}
```
## Progress via IPC
```typescript
// Main process
ipcMain.handle('download:file', async (event, url, targetDir) => {
  const onProgress = (progress: DownloadProgress) => {
    event.sender.send('download:progress', progress);
  };
  return downloadFile(url, targetDir, onProgress);
});
// Preload
contextBridge.exposeInMainWorld('electronAPI', {
  downloadFile: (url, dest) => ipcRenderer.invoke('download:file', url, dest),
  onDownloadProgress: (callback) => {
    const handler = (_event, progress) => callback(progress);
    ipcRenderer.on('download:progress', handler);
    return () => ipcRenderer.removeListener('download:progress', handler);
  },
});
```
## Zip Extraction
```typescript
import AdmZip from 'adm-zip';
export async function extractZip(zipPath: string, targetDir: string): Promise<void> {
  if (!fs.existsSync(targetDir)) fs.mkdirSync(targetDir, { recursive: true });
  new AdmZip(zipPath).extractAllTo(targetDir, true);
}
```
## Error Handling
| Error | Handling |
|-------|----------|
| Network failure | Return error result, log |
| No zip asset | Return "No zip asset found" |
| Extraction failure | Return error, clean up temp files |
## Consequences
- Requires `adm-zip` (~100KB)
- Download in main process (not renderer)
- Extraction is synchronous (blocks for large zips)

# GitHub API Update Checking Pattern
## Problem
Check for updates without full auto-update framework.
## Version Comparison
```typescript
export function compareVersions(local: string, remote: string): number {
  const localParts = local.replace(/^v/, '').split('.').map(Number);
  const remoteParts = remote.replace(/^v/, '').split('.').map(Number);
  const maxLength = Math.max(localParts.length, remoteParts.length);
  while (localParts.length < maxLength) localParts.push(0);
  while (remoteParts.length < maxLength) remoteParts.push(0);
  for (let i = 0; i < maxLength; i++) {
    if (localParts[i] < remoteParts[i]) return -1;
    if (localParts[i] > remoteParts[i]) return 1;
  }
  return 0;
}
```
## Using Electron net Module
```typescript
import { net } from 'electron';
async function fetchWithElectron(url: string) {
  return new Promise((resolve, reject) => {
    const request = net.request({ url, method: 'GET' });
    request.setHeader('Accept', 'application/vnd.github.v3+json');
    request.setHeader('User-Agent', 'my-app');
    let data = '';
    request.on('response', (response) => {
      response.on('data', (chunk) => { data += chunk; });
      response.on('end', () => {
        resolve({ ok: response.statusCode < 300, status: response.statusCode, json: () => JSON.parse(data) });
      });
    });
    request.on('error', reject);
    request.end();
  });
}
```
## Update Status States
| State | Badge Color | When |
|-------|-------------|------|
| `checking` | Blue | Request in progress |
| `update-available` | Orange | Remote > local |
| `up-to-date` | Green | Remote == local |
| `error` | Red | Network failure, API error |
## API Response
```json
{ "tag_name": "v0.30.0", "html_url": "https://github.com/owner/repo/releases/tag/v0.30.0" }
```
Strip `v` prefix for comparison.
## Rate Limiting
- Unauthenticated: 60 requests/hour
- Cache results for session, check on launch or user action only

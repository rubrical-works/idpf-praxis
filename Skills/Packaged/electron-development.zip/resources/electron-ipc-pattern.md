# Electron IPC Communication Pattern
Three-layer IPC for secure main-renderer communication.
## Implementation
### Main Process (main.ts)
```typescript
import { ipcMain } from 'electron';
ipcMain.handle('settings:get', () => getSettings());
ipcMain.handle('settings:save', (_event, settings) => {
  saveSettings(settings);
  return { success: true };
});
```
### Preload (preload.ts)
```typescript
import { contextBridge, ipcRenderer } from 'electron';
contextBridge.exposeInMainWorld('electronAPI', {
  getSettings: (): Promise<AppSettings> => ipcRenderer.invoke('settings:get'),
  saveSettings: (settings: Partial<AppSettings>): Promise<{ success: boolean }> =>
    ipcRenderer.invoke('settings:save', settings),
});
```
### Type Declarations (preload.d.ts)
```typescript
export interface ElectronAPI {
  getSettings: () => Promise<AppSettings>;
  saveSettings: (settings: Partial<AppSettings>) => Promise<{ success: boolean }>;
}
declare global {
  interface Window { electronAPI: ElectronAPI; }
}
```
### Renderer Usage
```typescript
const settings = await window.electronAPI.getSettings();
await window.electronAPI.saveSettings({ frameworkPath: '/path' });
```
## Channel Naming
Use `{domain}:{action}`: `settings:get`, `settings:save`, `dialog:selectDirectory`, `app:getVersion`
## Consequences
- contextBridge prevents direct IPC exposure (security)
- Declaration file provides full IntelliSense
- All renderer-to-main communication through exposed API
- Enables sandbox mode

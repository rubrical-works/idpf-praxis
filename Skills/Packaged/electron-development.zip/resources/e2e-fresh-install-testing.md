# E2E Fresh Install Testing
## Problem
E2E tests need to simulate first-run, but electron-store persists settings between runs.
## Solution
Environment variable triggers settings clear on startup.
### Main Process
```typescript
const store = new Store<Settings>({ name: 'app-settings', defaults: { setupCompleted: false } });
if (process.env.CLEAR_CONFIG === 'true') { store.clear(); }
```
### E2E Test Launch
```typescript
const electronApp = await electron.launch({
  executablePath: getExecutablePath(),
  env: { ...process.env, CLEAR_CONFIG: 'true' },
});
```
## Test Patterns
```typescript
// First run - clear config
test('shows setup wizard on first run', async () => {
  const electronApp = await electron.launch({
    executablePath, env: { ...process.env, CLEAR_CONFIG: 'true' },
  });
  const window = await electronApp.firstWindow();
  await expect(window.locator('#setup-wizard')).toBeVisible();
  await electronApp.close();
});
// Normal run - don't clear
test('shows main screen when setup complete', async () => {
  const electronApp = await electron.launch({ executablePath });
  const window = await electronApp.firstWindow();
  await expect(window.locator('#main-screen')).toBeVisible();
  await electronApp.close();
});
```
## Config File Locations
| Platform | Path |
|----------|------|
| Windows | `%APPDATA%/{app-name}/config.json` |
| macOS | `~/Library/Application Support/{app-name}/config.json` |
| Linux | `~/.config/{app-name}/config.json` |

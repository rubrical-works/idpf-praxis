# Vite Renderer Output Path
## Problem
With `root: 'src/renderer'` in `vite.renderer.config.ts`, output goes to `src/renderer/.vite/` instead of project root `.vite/` where Forge expects.
**Symptom:** Packaged app shows blank window.
## Solution
```typescript
import { defineConfig } from 'vite';
import * as path from 'path';
export default defineConfig({
  root: 'src/renderer',
  build: {
    outDir: path.resolve(__dirname, '.vite/renderer/main_window'),
    emptyOutDir: true,
  },
});
```
## Detection
If `root:` set to non-project-root path, verify:
1. `build.outDir` explicitly set
2. Points to correct absolute path
3. Forge's expected output location matches
## Verification
```bash
npx asar list out/YourApp-win32-x64/resources/app.asar | grep -i renderer
```
Should show renderer files (index.html, bundled JS).

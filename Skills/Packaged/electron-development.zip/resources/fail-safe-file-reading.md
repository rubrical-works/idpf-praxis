# Fail-Safe File Reading Pattern
## Problem
Config file reading can fail (missing file, invalid JSON, wrong permissions). Need pattern that never throws.
## Pattern
```typescript
import * as fs from 'fs';
import * as path from 'path';

export interface ConfigInfo {
  version: string | null;
  name: string | null;
  path: string;
  found: boolean;
}

export function getConfigInfo(configPath: string): ConfigInfo {
  if (!configPath || configPath.trim() === '')
    return { version: null, name: null, path: '', found: false };
  const manifestPath = path.join(configPath, 'manifest.json');
  try {
    if (!fs.existsSync(manifestPath))
      return { version: null, name: null, path: configPath, found: false };
    const manifest = JSON.parse(fs.readFileSync(manifestPath, 'utf-8'));
    return { version: manifest.version || null, name: manifest.name || null, path: configPath, found: true };
  } catch {
    return { version: null, name: null, path: configPath, found: false };
  }
}
```
## Error Handling Strategy
| Condition | Return |
|-----------|--------|
| Empty path | `{ found: false }` |
| Path doesn't exist | `{ found: false }` |
| Invalid JSON | `{ found: false }` |
| Valid config | `{ found: true, version: "x.y.z" }` |
## Generic Version
```typescript
export function readJsonFile<T>(filePath: string): { found: boolean; data?: T } {
  try {
    if (!fs.existsSync(filePath)) return { found: false };
    return { found: true, data: JSON.parse(fs.readFileSync(filePath, 'utf-8')) as T };
  } catch { return { found: false }; }
}
```
## Consequences
- Renderer must handle "Not Found" state
- All errors silent (caller never needs try/catch)
- Updates require re-fetching (no file watching)

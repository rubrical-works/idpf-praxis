# Electron App Naming Conventions
## Problem
App names with spaces cause issues: Playwright launch hangs, Git Bash path parsing, CI scripts.
**Symptom:** `DEP0190: Passing args to a child process with shell option true`
## Solution
| Name Type | Convention | Example |
|-----------|------------|---------|
| Executable | No spaces, PascalCase or kebab-case | `PraxisManager` |
| Display | Full name with spaces | `Praxis Project Manager` |
## Configuration
```json
// package.json
{ "name": "my-app", "productName": "MyApp" }
```
```typescript
// forge.config.ts
packagerConfig: { name: 'MyApp' }
```
```html
<title>My App Name</title>  <!-- Display name -->
```
## Result
| Location | Shows |
|----------|-------|
| Executable file | `MyApp.exe` |
| Window title bar | `My App Name` |
| Output directory | `out/MyApp-win32-x64/` |
## E2E Path Helper
```typescript
const APP_EXECUTABLE_NAME = 'MyApp';
function getExecutablePath(): string {
  const basePath = path.join(__dirname, '..', 'out');
  if (process.platform === 'win32')
    return path.join(basePath, `${APP_EXECUTABLE_NAME}-win32-x64`, `${APP_EXECUTABLE_NAME}.exe`);
  else if (process.platform === 'darwin')
    return path.join(basePath, `${APP_EXECUTABLE_NAME}-darwin-x64`,
      `${APP_EXECUTABLE_NAME}.app`, 'Contents', 'MacOS', APP_EXECUTABLE_NAME);
  else
    return path.join(basePath, `${APP_EXECUTABLE_NAME}-linux-x64`, APP_EXECUTABLE_NAME.toLowerCase());
}
```

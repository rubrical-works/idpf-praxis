# Electron Multi-Screen Navigation Pattern
## Problem
Simple apps need navigation between 2-5 screens without a router library.
## Solution
CSS class toggling with screen state tracking.
### HTML
```html
<main id="setup-wizard" class="hidden">...</main>
<main id="main-screen" class="hidden">...</main>
<main id="settings-screen" class="hidden">...</main>
```
### CSS
```css
.hidden { display: none !important; }
```
### TypeScript
```typescript
let previousScreen: 'wizard' | 'main' = 'main';
function showSetupWizard(): void {
  setupWizard.classList.remove('hidden');
  mainScreen.classList.add('hidden');
  settingsScreen.classList.add('hidden');
  previousScreen = 'wizard';
}
function showMainScreen(): void {
  setupWizard.classList.add('hidden');
  mainScreen.classList.remove('hidden');
  settingsScreen.classList.add('hidden');
  previousScreen = 'main';
}
function showSettingsScreen(): void {
  setupWizard.classList.add('hidden');
  mainScreen.classList.add('hidden');
  settingsScreen.classList.remove('hidden');
}
function handleCancel(): void {
  previousScreen === 'wizard' ? showSetupWizard() : showMainScreen();
}
```
## When to Use
- Single-window apps with 2-5 screens
- Linear or simple branching flows
## When to Consider Alternatives
- Many screens -> router library
- Browser history/back button needed -> hash-based routing
- Deep linking -> proper routing library
## E2E Test Pattern
```typescript
test('settings screen opens and closes', async () => {
  await window.locator('#settings-button').click();
  await expect(window.locator('#settings-screen')).toBeVisible();
  await window.locator('#cancel-button').click();
  await expect(window.locator('#main-screen')).toBeVisible();
});
```
## Consequences
- All screens exist in DOM at all times
- No URL changes (can't bookmark)
- State must be manually loaded when showing screens

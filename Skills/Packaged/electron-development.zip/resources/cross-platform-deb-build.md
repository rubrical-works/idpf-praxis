# Cross-Platform .deb Build from Windows
## Problem
Electron apps targeting Linux need `.deb` packages, but `fpm` (Ruby gem) isn't available natively on Windows.
```
Error: Cannot find "fpm"
```
| Attempt | Problem |
|---------|---------|
| `npx electron-builder --linux deb` | `fpm` not available on Windows |
| `docker run -v "$(pwd):/project" ...` | Git Bash mangles `$(pwd)` |
| Docker with `-w /project` | MSYS2 rewrites `/project` to `C:/Program Files/Git/project` |
## Solution: Docker-Based Build (Recommended)
```bash
MSYS_NO_PATHCONV=1 docker run --rm   -v "$(pwd):/project"   -w /project   node:22   npx electron-builder --linux deb --config electron-builder.yml
```
**Key details:**
- `MSYS_NO_PATHCONV=1` prevents Git Bash from rewriting `/project` as Windows path
- `--rm` removes container after build
- `node:22` base image (~1 GB); electron-builder auto-downloads `fpm` 1.17.0
- Output lands in `dist/` via bind mount (e.g., `your-app_1.0.0_amd64.deb`, ~91 MB)
**Alternative image:** `electronuserland/builder:wine` bundles `fpm`, `wine`, Linux build tools pre-installed.
## Alternative: WSL-Based Build
```bash
cd /mnt/e/Projects/your-app
npx electron-builder --linux deb --config electron-builder.yml
```
**WSL Prerequisites:** Node.js/npm, `fpm` gem (`sudo apt-get install ruby-dev build-essential && sudo gem install fpm`), project deps installed.
## Alternative: GitHub Actions CI Build
```yaml
name: Build Linux
on:
  push:
    tags: ['v*']
jobs:
  build-deb:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
      - run: npm ci
      - run: npx electron-builder --linux deb --config electron-builder.yml
      - uses: actions/upload-artifact@v4
        with:
          name: linux-deb
          path: dist/*.deb
```
## Pre-Commit / Local CI Integration
```bash
if command -v docker &>/dev/null; then
  MSYS_NO_PATHCONV=1 docker run --rm     -v "$(pwd):/project" -w /project node:22     npx electron-builder --linux deb --config electron-builder.yml
else
  echo "Skipped .deb build (Docker not available)"
fi
```
Skip condition: "Docker not available" (not "fpm not found" which is always true on Windows).
## Common Pitfalls
| Pitfall | Cause | Fix |
|---------|-------|-----|
| Docker path error `C:/Program Files/Git/project` | MSYS2 auto-converts `/` paths | Set `MSYS_NO_PATHCONV=1` |
| Symlink errors in Docker | Windows mounts lack Linux symlinks | Use `--config` flag |
| Permission errors on `.deb` contents | Windows has no Unix permissions | Docker build handles this |
| Native dependency mismatch | `node_modules` built for Windows | Run `npm install` inside Docker/WSL |
## Detection
Build fails with:
- `Cannot find "fpm"` — Missing Linux packaging tool
- `is invalid, it needs to be an absolute path` — Docker path mangling
- `ENOENT` during packaging — Native dependency mismatch
# E2E Testing Packaged Electron Apps
## Problem
Dev mode is unreliable for E2E (Vite timing issues, different behavior from production). Test packaged executable instead.
## Prerequisites
1. Run `npm run package` before E2E tests
2. Enable `EnableNodeCliInspectArguments` fuse
3. Use no-space executable name
## Test Structure
```typescript
import { _electron as electron, ElectronApplication, Page } from 'playwright';
import * as path from 'path';
import * as fs from 'fs';

const APP_EXECUTABLE_NAME = 'MyApp';

function getExecutablePath(): string {
  const basePath = path.join(__dirname, '..', 'out');
  if (process.platform === 'win32') {
    return path.join(basePath, `${APP_EXECUTABLE_NAME}-win32-x64`, `${APP_EXECUTABLE_NAME}.exe`);
  } else if (process.platform === 'darwin') {
    return path.join(basePath, `${APP_EXECUTABLE_NAME}-darwin-x64`,
      `${APP_EXECUTABLE_NAME}.app`, 'Contents', 'MacOS', APP_EXECUTABLE_NAME);
  } else {
    return path.join(basePath, `${APP_EXECUTABLE_NAME}-linux-x64`, APP_EXECUTABLE_NAME.toLowerCase());
  }
}

test.describe('App Tests', () => {
  let electronApp: ElectronApplication;
  let window: Page;
  test.beforeAll(async () => {
    const executablePath = getExecutablePath();
    if (!fs.existsSync(executablePath)) throw new Error(`Run 'npm run package' first.`);
    electronApp = await electron.launch({ executablePath, timeout: 30000 });
    window = await electronApp.firstWindow();
    await window.waitForLoadState('domcontentloaded');
  });
  test.afterAll(async () => { if (electronApp) await electronApp.close(); });
});
```
## CI Workflow
```yaml
- run: npm ci
- run: npm run package
- run: npm run test:e2e
```
## Common Issues
| Issue | Solution |
|-------|----------|
| `firstWindow()` hangs | Check fuses, DevTools not opening |
| Path not found | Verify executable name, run package first |
| Timeout on load | Increase timeout, check startup errors |

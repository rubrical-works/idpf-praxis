# Windows Process Kill Pattern
## Problem
Electron processes lock files on Windows, causing rebuild failures. Standard commands don't work in Git Bash.
## What Fails in Git Bash
| Attempt | Problem |
|---------|---------|
| `taskkill /F /IM "electron.exe"` | Git Bash interprets `/F` as path |
| `powershell -Command "... $_.Name ..."` | Git Bash expands `$_` |
## Solution
PowerShell with **single quotes** (passed verbatim):
```bash
powershell -Command 'Stop-Process -Name "electron" -Force -ErrorAction SilentlyContinue'
```
## Recommended Cleanup Sequence
```bash
powershell -Command 'Stop-Process -Name "YourAppName" -Force -ErrorAction SilentlyContinue'
powershell -Command 'Stop-Process -Name "electron" -Force -ErrorAction SilentlyContinue'
sleep 2
rm -rf .vite
rm -rf out
```
## macOS/Linux Alternative
```bash
pkill -f electron || true
sleep 2
rm -rf .vite out
```
## Detection
Build fails with: `cannot remove '...app.asar': Device or resource busy` -- processes still holding file handles.

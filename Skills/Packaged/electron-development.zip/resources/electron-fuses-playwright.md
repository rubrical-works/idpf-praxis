# Electron Fuses and Playwright E2E Testing
## Problem
`electron.launch()` times out even though app works manually.
## How Playwright Connects
1. Launches Electron with `--remote-debugging-port=XXXXX`
2. Connects via Chrome DevTools Protocol (CDP)
3. If `EnableNodeCliInspectArguments` fuse is `false`, Electron ignores debug port -> timeout
## Solution
```typescript
new FusesPlugin({
  version: FuseVersion.V1,
  [FuseV1Options.RunAsNode]: false,
  [FuseV1Options.EnableCookieEncryption]: true,
  [FuseV1Options.EnableNodeOptionsEnvironmentVariable]: false,
  [FuseV1Options.EnableNodeCliInspectArguments]: true,  // Required for Playwright
  [FuseV1Options.EnableEmbeddedAsarIntegrityValidation]: true,
  [FuseV1Options.OnlyLoadAppFromAsar]: true,
});
```
## Production Security
```typescript
const isProduction = process.env.NODE_ENV === 'production';
new FusesPlugin({
  [FuseV1Options.EnableNodeCliInspectArguments]: !isProduction,
});
```
Or maintain separate forge configs for dev vs production.
## Troubleshooting
| Symptom | Likely Cause |
|---------|--------------|
| Timeout in `electron.launch()` | Fuses blocking debug port |
| Timeout in `firstWindow()` | DevTools opening, window not loading |
| DEP0190 warning | Spaces in path (cosmetic) |
| App opens but tests fail | CDP connection blocked by fuses |

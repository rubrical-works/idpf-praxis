# electron-store Settings Persistence
## Basic Usage
### Main Process
```typescript
import Store from 'electron-store';
interface Settings {
  setupCompleted: boolean;
  frameworkPath: string;
  repoUrl: string;
  theme: 'light' | 'dark' | 'system';
}
const store = new Store<Settings>({
  name: 'app-settings',
  defaults: { setupCompleted: false, frameworkPath: '', repoUrl: '', theme: 'system' },
});
export function getSettings(): Settings { return store.store; }
export function saveSettings(settings: Partial<Settings>): void {
  Object.entries(settings).forEach(([key, value]) => store.set(key, value));
}
export function clearSettings(): void { store.clear(); }
export function isFirstRun(): boolean { return !store.get('setupCompleted'); }
```
### IPC Integration
```typescript
ipcMain.handle('settings:get', () => getSettings());
ipcMain.handle('settings:save', (_event, settings) => { saveSettings(settings); return { success: true }; });
ipcMain.handle('settings:isFirstRun', () => isFirstRun());
if (process.env.CLEAR_CONFIG === 'true') { clearSettings(); }
```
## Storage Locations
| Platform | Path |
|----------|------|
| Windows | `%APPDATA%/{productName}/app-settings.json` |
| macOS | `~/Library/Application Support/{productName}/app-settings.json` |
| Linux | `~/.config/{productName}/app-settings.json` |
## Schema Validation (Optional)
```typescript
const store = new Store<Settings>({
  schema: {
    frameworkPath: { type: 'string', default: '' },
    theme: { type: 'string', enum: ['light', 'dark', 'system'], default: 'system' },
  },
});
```
## Migration Support
```typescript
const store = new Store<Settings>({
  migrations: {
    '1.0.0': (store) => {
      if (store.has('oldKey')) { store.set('newKey', store.get('oldKey')); store.delete('oldKey'); }
    },
  },
});
```
## Best Practices
1. Type your store with TypeScript interface
2. Provide defaults for all settings
3. Wrap store access in getter/setter functions
4. Never import electron-store in renderer -- expose via IPC

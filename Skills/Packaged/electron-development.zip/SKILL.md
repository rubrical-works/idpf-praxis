---
name: electron-development
description: Patterns and solutions for Electron app development with Vite, Playwright E2E testing, and Windows platform considerations
version: "0.55.0"
license: Complete terms in LICENSE.txt
---
# Electron Development
Patterns and solutions for Electron Forge + Vite, Playwright E2E testing, and Windows platform considerations.
## When to Use This Skill
- Setting up Electron application with Vite
- Configuring Playwright E2E tests for Electron
- Debugging Windows-specific issues (process locking, path issues)
- Implementing IPC communication patterns
- Adding settings persistence with electron-store
- Building update checking or download features (autoUpdater)
- Packaging for cross-platform distribution (DMG, AppImage, Snap, Docker-based builds)
- Code signing and notarization for macOS apps
---
## Quick Reference
| Problem | Solution | Resource |
|---------|----------|----------|
| Vite output in wrong location | Set explicit `build.outDir` | [vite-renderer-output-path.md](resources/vite-renderer-output-path.md) |
| Playwright times out on launch | Enable `EnableNodeCliInspectArguments` fuse | [electron-fuses-playwright.md](resources/electron-fuses-playwright.md) |
| Spaces in app name cause issues | Use no-space `productName` | [electron-app-naming.md](resources/electron-app-naming.md) |
| E2E tests flaky in dev mode | Test packaged app instead | [e2e-testing-packaged.md](resources/e2e-testing-packaged.md) |
| Windows processes lock files | PowerShell `Stop-Process` | [windows-process-kill.md](resources/windows-process-kill.md) |
| IPC communication pattern | Three-layer contextBridge | [electron-ipc-pattern.md](resources/electron-ipc-pattern.md) |
| Settings persistence | electron-store package | [electron-store-settings.md](resources/electron-store-settings.md) |
| E2E fresh install testing | CLEAR_CONFIG env var | [e2e-fresh-install-testing.md](resources/e2e-fresh-install-testing.md) |
| Simple multi-screen nav | CSS class toggling | [multi-screen-navigation.md](resources/multi-screen-navigation.md) |
| Config file reading | Fail-safe pattern | [fail-safe-file-reading.md](resources/fail-safe-file-reading.md) |
| GitHub update checking | Electron net module | [github-api-update-checking.md](resources/github-api-update-checking.md) |
| Download with progress | IPC events pattern | [download-extraction-progress.md](resources/download-extraction-progress.md) |
| Linux .deb build from Windows | Docker + MSYS_NO_PATHCONV | [cross-platform-deb-build.md](resources/cross-platform-deb-build.md) |
---
## Setup & Build
### Vite Renderer Configuration
When `root` set to subdirectory, explicitly set `build.outDir` to absolute path.
**Problem:** `root: 'src/renderer'` causes output to `src/renderer/.vite/` instead of where Forge expects.
```typescript
export default defineConfig({
  root: 'src/renderer',
  build: {
    outDir: path.resolve(__dirname, '.vite/renderer/main_window'),
    emptyOutDir: true,
  },
});
```
**Detection:** Packaged app shows blank window -> check if renderer files are in ASAR.
See: [vite-renderer-output-path.md](resources/vite-renderer-output-path.md)
---
## Windows Platform
### Dangerous rm Patterns
```bash
# DANGEROUS - rm -rf .vite/ out/ dist/
# SAFE - one at a time
rm -rf .vite
rm -rf out
```
### Process Management
```bash
powershell -Command 'Stop-Process -Name "electron" -Force -ErrorAction SilentlyContinue'
sleep 2
rm -rf .vite
```
**Detection:** "Device or resource busy" = processes still running.
See: [windows-process-kill.md](resources/windows-process-kill.md)
---
## E2E Testing with Playwright
### Test Packaged App, Not Dev Mode
```typescript
const electronApp = await electron.launch({
  executablePath: getExecutablePath(),
  timeout: 30000,
});
```
CI: `npm run package` then `npm run test:e2e`
See: [e2e-testing-packaged.md](resources/e2e-testing-packaged.md)
### Electron Fuses Configuration
`EnableNodeCliInspectArguments` must be `true` for Playwright CDP.
```typescript
new FusesPlugin({
  [FuseV1Options.EnableNodeCliInspectArguments]: true,
});
```
**Symptom:** `electron.launch()` times out but app opens manually -> fuses blocking CDP.
See: [electron-fuses-playwright.md](resources/electron-fuses-playwright.md)
### App Naming
No-space executable names: `{ "productName": "PraxisManager" }`
Display name via HTML: `<title>Praxis Project Manager</title>`
See: [electron-app-naming.md](resources/electron-app-naming.md)
### Fresh Install Testing
```typescript
if (process.env.CLEAR_CONFIG === 'true') { clearSettings(); }
const electronApp = await electron.launch({
  executablePath,
  env: { ...process.env, CLEAR_CONFIG: 'true' },
});
```
See: [e2e-fresh-install-testing.md](resources/e2e-fresh-install-testing.md)
---
## Architecture Patterns
### IPC Communication
Three-layer pattern:
1. **Main:** `ipcMain.handle('channel', handler)`
2. **Preload:** `contextBridge.exposeInMainWorld('api', { ... })`
3. **Types:** `preload.d.ts` with Window interface extension
**Channel naming:** `settings:get`, `dialog:selectDirectory`
See: [electron-ipc-pattern.md](resources/electron-ipc-pattern.md)
### Settings Persistence
```typescript
const store = new Store<Settings>({
  name: 'app-settings',
  defaults: { setupCompleted: false },
});
```
Storage: Windows `%APPDATA%/{app}/`, macOS `~/Library/Application Support/{app}/`, Linux `~/.config/{app}/`
See: [electron-store-settings.md](resources/electron-store-settings.md)
### Multi-Screen Navigation
CSS class toggling for 2-5 screen apps:
```typescript
function showScreen(id: string) {
  document.querySelectorAll('main').forEach(el => el.classList.add('hidden'));
  document.getElementById(id)?.classList.remove('hidden');
}
```
See: [multi-screen-navigation.md](resources/multi-screen-navigation.md)
### Fail-Safe File Reading
```typescript
function getConfig(path: string): { found: boolean; data?: Config } {
  try {
    if (!fs.existsSync(path)) return { found: false };
    return { found: true, data: JSON.parse(fs.readFileSync(path, 'utf-8')) };
  } catch { return { found: false }; }
}
```
See: [fail-safe-file-reading.md](resources/fail-safe-file-reading.md)
---
## Network & Updates
### GitHub API Update Checking
```typescript
const request = net.request({
  url: `https://api.github.com/repos/${owner}/${repo}/releases/latest`,
  method: 'GET',
});
request.setHeader('Accept', 'application/vnd.github.v3+json');
```
Rate limit: 60 requests/hour unauthenticated.
See: [github-api-update-checking.md](resources/github-api-update-checking.md)
### Download with Progress
```typescript
ipcMain.handle('download', async (event, url, dest) => {
  const onProgress = (p) => event.sender.send('download:progress', p);
  return downloadFile(url, dest, onProgress);
});
```
GitHub releases: follow 302 redirects to S3.
See: [download-extraction-progress.md](resources/download-extraction-progress.md)
---
## Troubleshooting Matrix
| Symptom | Likely Cause | Solution |
|---------|--------------|----------|
| Blank window in packaged app | Renderer files not in ASAR | Check Vite output path |
| `electron.launch()` timeout | Fuses blocking CDP | Enable `EnableNodeCliInspectArguments` |
| `firstWindow()` timeout | DevTools opening | Check for console errors |
| DEP0190 warning | Spaces in executable path | Use no-space productName |
| "Device or resource busy" | Processes holding file handles | Kill processes before cleanup |
| E2E different from manual | Testing dev mode | Test packaged executable |
| Settings persist between tests | electron-store not cleared | Use CLEAR_CONFIG env var |
| `Cannot find "fpm"` on Windows | Linux packaging tools missing | Use Docker build |
| Docker path `C:/Program Files/Git/...` | MSYS2 rewrites `/` paths | Set `MSYS_NO_PATHCONV=1` |
|  on Windows | Linux packaging tools missing | Use Docker build |
| Docker path  | MSYS2 rewrites  paths | Set  |
---
## Resources
| Resource | Description |
|----------|-------------|
| [vite-renderer-output-path.md](resources/vite-renderer-output-path.md) | Vite config for root subdirectory |
| [windows-process-kill.md](resources/windows-process-kill.md) | PowerShell approach for Windows |
| [electron-fuses-playwright.md](resources/electron-fuses-playwright.md) | Fuse config for E2E |
| [electron-app-naming.md](resources/electron-app-naming.md) | No-space naming |
| [e2e-testing-packaged.md](resources/e2e-testing-packaged.md) | Testing packaged apps |
| [electron-ipc-pattern.md](resources/electron-ipc-pattern.md) | Three-layer IPC |
| [e2e-fresh-install-testing.md](resources/e2e-fresh-install-testing.md) | Fresh install simulation |
| [electron-store-settings.md](resources/electron-store-settings.md) | Settings persistence |
| [multi-screen-navigation.md](resources/multi-screen-navigation.md) | Simple navigation |
| [fail-safe-file-reading.md](resources/fail-safe-file-reading.md) | Defensive file reading |
| [github-api-update-checking.md](resources/github-api-update-checking.md) | Update checking |
| [download-extraction-progress.md](resources/download-extraction-progress.md) | Download with progress |
| [cross-platform-deb-build.md](resources/cross-platform-deb-build.md) | Linux .deb packaging from Windows |
---
**End of Electron Development Skill**

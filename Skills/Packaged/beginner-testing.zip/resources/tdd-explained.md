# TDD Explained for Beginners
**Version:** {{VERSION}}
## The TDD Cycle in Detail
### Phase 1: RED (Write Failing Test)
1. Decide what to build (e.g., "edit notes")
2. Write a test for that feature
3. Run the test - it fails (feature doesn't exist yet)

```python
def test_edit_note():
    client = app.test_client()
    client.post('/add', data={'note': 'Original text'})
    response = client.post('/edit/1', data={'note': 'Updated text'})
    assert response.status_code == 302
    response = client.get('/')
    assert b'Updated text' in response.data
```
Run: FAIL (404 Not Found) - RED
### Phase 2: GREEN (Make Test Pass)
Write minimum code to pass:
```python
@app.route('/edit/<int:note_id>', methods=['POST'])
def edit_note(note_id):
    new_text = request.form['note']
    conn = get_db()
    conn.execute('UPDATE notes SET text = ? WHERE id = ?', (new_text, note_id))
    conn.commit()
    conn.close()
    return redirect('/')
```
Run: PASS - GREEN
### Phase 3: REFACTOR (Clean Up)
Extract database logic:
```python
def update_note(note_id, text):
    conn = get_db()
    conn.execute('UPDATE notes SET text = ? WHERE id = ?', (text, note_id))
    conn.commit()
    conn.close()

@app.route('/edit/<int:note_id>', methods=['POST'])
def edit_note(note_id):
    update_note(note_id, request.form['note'])
    return redirect('/')
```
Run: Still PASS - REFACTOR complete
---
## Real Example: Building a Notes App with TDD
### Iteration 1: Homepage
**RED:** `assert client.get('/').status_code == 200` -> FAIL
**GREEN:** Add `@app.route('/')` returning template -> PASS
### Iteration 2: Add Note
**RED:** `assert client.post('/add', data={'note': 'Test'}).status_code == 302` -> FAIL
**GREEN:** Add `/add` route -> PASS
### Iteration 3: Display Notes
**RED:** `assert b'My note' in client.get('/').data` -> FAIL
**GREEN:** Pass notes to template -> PASS
### All Tests Still Pass!
```
test_homepage_exists PASSED
test_add_note PASSED
test_notes_display PASSED
```
Nothing broke! Safe to continue.
---
## Common TDD Patterns
### ARRANGE-ACT-ASSERT
```python
def test_something():
    # ARRANGE - Set up test data
    note = "Test note"
    # ACT - Do the thing
    response = client.post('/add', data={'note': note})
    # ASSERT - Check it worked
    assert response.status_code == 302
```
### One Assert Per Test
Each test checks one thing. When it fails, you know exactly what broke.
### Test Names Describe Behavior
```python
def test_homepage_returns_200(): ...
def test_adding_note_redirects_to_homepage(): ...
def test_empty_form_shows_error(): ...
```
---
## When Tests Are Hard
If writing a test is difficult, your code might be too complex. Break it into smaller pieces - each piece easier to test. TDD helps you write better code!
---
## TDD Workflow Tips
1. **Keep tests fast** - test DB, no network, no sleep()
2. **Run tests often** - after every small change
3. **Trust your tests** - if they pass, code works
4. **Write test first** - test defines "done"
---
## Next Steps
After mastering basics: fixtures, mocking, test coverage, CI, test databases.
But first: Practice RED-GREEN-REFACTOR until it feels natural!

---
name: beginner-testing
description: Introduce test-driven development to beginners with simple Flask/Sinatra test examples and TDD concepts
version: "0.52.0"
license: Complete terms in LICENSE.txt
---
# Beginner Testing Introduction
## When to Use
- User has working Vibe app ready to transition to Structured Phase
- User mentions "testing" or asks "how to test"
- Evolution Point reached (user says "Ready-to-Structure")
- User has built 3-4 features and wants quality assurance
- User asks "How do I know if my code works?"
## Prerequisites
- Working Flask or Sinatra app with 3-4 features
- Understanding of routes and functions
- Comfortable with basic programming concepts
- Code that works, but no tests yet
---
## The TDD Cycle
```
RED -> GREEN -> REFACTOR

1. RED: Write a test that fails (feature doesn't exist yet)
2. GREEN: Write just enough code to make test pass
3. REFACTOR: Clean up the code (tests still pass)

Then repeat for next feature!
```
---
## Types of Tests
1. **Unit Tests** - Test individual functions (e.g., `add_numbers(2, 3)` returns `5`)
2. **Route Tests** - Test web pages load correctly (e.g., `/` returns 200)
3. **Integration Tests** - Test parts work together (e.g., form adds note to DB)

**For beginners: Start with route tests!**
---
## Your First Test (Flask)
```python
# test_app.py
def test_homepage_loads():
    """Test that homepage loads without errors."""
    from app import app
    client = app.test_client()
    response = client.get('/')
    assert response.status_code == 200  # 200 = success
```
**How to run:**
```bash
pip install pytest
pytest
```
See `resources/flask-test-example.py` for complete example.
---
## Your First Test (Sinatra)
```ruby
# test_app.rb
require 'minitest/autorun'
require 'rack/test'
require_relative 'app'

class AppTest < Minitest::Test
  include Rack::Test::Methods
  def app; Sinatra::Application; end

  def test_homepage_loads
    get '/'
    assert last_response.ok?
  end
end
```
**Run:** `ruby test_app.rb`
---
## Common Assertions
**Python (pytest):**
```python
assert something == True
assert value == 5
assert 'text' in response.data
assert value != 0
```
**Ruby (minitest):**
```ruby
assert something
assert_equal 5, value
assert_includes body, 'text'
```
---
## TDD Example: Adding Delete Feature
**Step 1: RED - Write failing test**
```python
def test_delete_note():
    client = app.test_client()
    client.post('/add', data={'note': 'Test note'})
    response = client.get('/delete/1')
    assert response.status_code == 302
```
Run: Fails (route doesn't exist) - RED
**Step 2: GREEN - Make test pass**
```python
@app.route('/delete/<int:note_id>')
def delete_note(note_id):
    conn = get_db()
    conn.execute('DELETE FROM notes WHERE id = ?', (note_id,))
    conn.commit()
    conn.close()
    return redirect('/')
```
Run: Passes - GREEN
**Step 3: REFACTOR** - Extract database operations. Tests still pass!
---
## Test Organization
```
my-project/
├── app.py              # Your code
├── test_app.py         # Your tests
├── templates/
│   └── index.html
└── notes.db
```
**Naming:** Python: `test_*.py`, Ruby: `*_test.rb` - auto-discovered by test runners.
---
## Reading Test Output
**Pass (Green):**
```
test_app.py::test_homepage_loads PASSED
test_app.py::test_add_note PASSED
3 passed in 0.12s
```
**Fail (Red):**
```
FAILED test_app.py::test_add_note - assert 404 == 200
```
Something broke! Route not found.
---
## What to Test (Beginners)
**Test these:** Routes exist (not 404), forms submit, data saves, data displays
**Don't worry yet about:** Edge cases, error handling, performance, security
**Start simple, add complexity later!**
---
## Common Mistakes
1. **Not running tests** - Run after every change
2. **Tests depend on order** - Each test should work independently
3. **Testing too much at once** - Small tests, one thing each
4. **Not testing the right thing** - Verify the important behavior
---
## Next Steps After First Tests
1. Add more route tests
2. Test form submissions
3. Test database operations
4. Test error handling
5. Learn fixtures (test data setup)
6. Learn mocking (fake external services)

But first: Master the basics!
---
## Complete Examples
- `resources/flask-test-example.py`
- `resources/sinatra-test-example.rb`
- `resources/tdd-explained.md`

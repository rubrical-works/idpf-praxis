# REFACTOR Phase Checklist
**Version:** {{VERSION}}
## Before Refactoring
- [ ] GREEN phase complete, all tests passing
- [ ] Code analyzed for opportunities
- [ ] Decision made: refactor OR skip
- [ ] If refactoring: specific improvements identified
## If Refactoring
- [ ] Scope small and focused
- [ ] One refactoring at a time
- [ ] All tests currently GREEN
- [ ] Won't change behavior
- [ ] No new features
## Applying
- [ ] Code is clear and improved
- [ ] Structure or naming enhanced
- [ ] Changes minimal and focused
## Testing After
- [ ] Full test suite executed
- [ ] ALL tests PASS (green)
- [ ] No behavioral changes
## If Tests Break
- [ ] IMMEDIATE ROLLBACK
- [ ] Tests returned to green
- [ ] Decision: skip OR try smaller change
## Before Next Feature
- [ ] Refactoring complete OR skipped
- [ ] All tests green
- [ ] Proceed autonomously
## Quick Diagnostics
- **Breaks tests** -> ROLLBACK, try smaller or skip
- **Seems risky** -> Skip, defer
- **Unsure of value** -> Skip, don't refactor for its own sake
## When to Skip
- Premature abstraction (one use case)
- Code already clear
- High risk, low value
- Over-engineering
## Principles
**Do:** Small changes, test after each, rollback on failure
**Don't:** Add features, change behavior, accept broken tests, big bang changes

---
name: tdd-refactor-phase
description: Guide experienced developers through REFACTOR phase of TDD cycle - improving code quality while maintaining green tests
version: "0.52.0"
license: Complete terms in LICENSE.txt
---
# TDD REFACTOR Phase
## When to Use
- GREEN phase complete with passing test
- Proceeding autonomously from GREEN phase
- Code works but could be improved
## Prerequisites
- Completed GREEN phase with all tests passing
- Full test suite available to verify safety
- Claude Code available for analysis and execution
## Objectives
1. **Improve code quality** - Cleaner, more maintainable, better structured
2. **Keep tests green** - All improvements maintain existing functionality
**IS:** Improving structure without changing behavior, eliminating duplication, simplifying logic, improving naming
**IS NOT:** Adding features, changing behavior, fixing bugs, premature optimization
## Workflow
### Step 1: Analyze Opportunities
Identify: code duplication, long/complex functions, unclear names, missing abstractions, SOLID/DRY violations, complex conditionals, magic numbers
### Step 2: Evaluate
**Refactor Now:** Clear improvement, low risk/high value, won't over-engineer
**Skip:** Premature abstraction, risk > reward, code already clear
> "ASSISTANT evaluates findings and either: Option A: Provides refactored code | Option B: Recommends skipping"
### Step 3: Apply (if approved)
```
TASK: [Brief description of refactoring]
STEP 1: [Open implementation file]
STEP 2: [Navigate to code being refactored]
STEP 3: [Apply refactored code - COMPLETE implementation]
STEP 4: [Explanation of what improved and why]
STEP 5: [Save file]
STEP 6: [Run full test suite]
STEP 7: [Verify ALL tests still PASS (green)]
STEP 8: [Report back: All tests green?]
```
### Step 4: Verify Tests Green
- Run FULL test suite, ALL must pass
- **If any fail** -> Rollback immediately, try smaller or skip
### Step 5: Complete
- Refactoring applied + green OR skipped -> Proceed to next behavior or story
- TDD cycle continues autonomously. Only checkpoint: story completion (In Review -> Done).
## Best Practices
1. **Small steps** - One change at a time, test after each
2. **One refactoring at a time** - Then run tests, then next
3. **Keep tests green** - If breaks -> rollback -> try smaller or skip
4. **Clarity over cleverness** - Easier to understand, not "elegant"
## Common Refactorings
| Refactoring | When |
|-------------|------|
| Extract Variable | Expression hard to understand |
| Extract Function | Long function, logic buried |
| Rename | Unclear names, abbreviations |
| Eliminate Duplication | Same code in multiple places |
| Simplify Conditional | Nested conditions -> guard clauses |
## When to Skip
| Scenario | Decision |
|----------|----------|
| Premature abstraction (one use) | Skip - Rule of Three |
| Code already clear | Skip - good enough |
| High risk, low value | Skip or defer |
| Over-engineering | Skip - keep simple |
## Anti-Patterns
- **Without tests** -> Always run tests after changes
- **Accepting broken tests** -> Rollback, never "fix later"
- **Big bang refactoring** -> Small incremental changes
- **Refactoring + features** -> Never both at same time
## Rollback
1. **Immediate:** Rollback changes (git checkout or undo)
2. **Verify:** Tests green again
3. **Options:** Smaller refactoring, skip, investigate
Rollback is autonomous -- assistant handles it.
## REFACTOR Phase Checklist
- [ ] Code analyzed for opportunities
- [ ] If applied: all tests PASS, behavior unchanged
- [ ] If skipped: valid reason, tests still green
## Resources
- `resources/refactor-checklist.md` - Quick reference checklist
- `resources/common-refactorings.md` - Catalog of patterns
- `resources/when-to-skip-refactoring.md` - Decision guide
## Relationship to Other Skills
**Flows from:** `tdd-green-phase` | **Flows to:** `tdd-red-phase` (next feature)
**Related:** `tdd-failure-recovery`
---
**End of TDD REFACTOR Phase Skill**

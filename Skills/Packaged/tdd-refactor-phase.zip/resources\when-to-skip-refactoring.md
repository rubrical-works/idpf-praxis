# When to Skip Refactoring
**Version:** 0.52.0
**Golden Rule:** Refactoring is optional. Tests passing is mandatory.
## Time Constraints
- **Skip:** Deadline imminent, critical bug fix, demo hours away
- **Don't skip:** "No time" is excuse for tech debt, code touched again soon
```
> 15 minutes available -> Consider refactoring
< 15 minutes -> Skip, create tech debt ticket
```
## Code Stability
| Code Type | Refactor Priority |
|-----------|------------------|
| Core domain logic | High |
| Shared utilities | High |
| Feature-specific | Medium |
| One-off scripts | Low |
| Deprecated | Skip |
## Risk Assessment
```
High Impact + Low Confidence -> Skip
High Impact + High Confidence -> Careful refactor
Low Impact + Low Confidence -> Skip
Low Impact + High Confidence -> Refactor
```
## Code Smell Severity
**Must Refactor:** Security vulnerabilities, data corruption risks, memory leaks
**Should Refactor:** Duplicated logic (3+), functions > 50 lines, deep nesting, misleading names
**Can Skip:** Minor naming, style preferences, premature abstractions
## Quick Decision Checklist
Before skipping:
- [ ] Tests passing and comprehensive
- [ ] Code readable for next developer
- [ ] No bugs or security issues
- [ ] Tech debt documented if significant
**Skip signals:** Code works and clear, improvement cosmetic, real time pressure, high breakage risk
**Don't skip:** Don't understand what you wrote, copy-paste duplication, misleading names, next feature touches this
## Documenting Skipped Refactoring
```
// TODO: Refactor - [what needs improving]
// Skipped: [date] - [reason]
```
Or create tech debt ticket with: what, why, suggested approach, priority.

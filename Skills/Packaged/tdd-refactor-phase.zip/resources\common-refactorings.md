# Common Refactorings Catalog
**Version:** 0.52.0
## Extract Method
**When:** Code block does one identifiable thing; function too long.
```python
# Before
def process_order(order):
    total = 0
    for item in order.items:
        total += item.price * item.quantity
    total *= (1 - order.discount)
    send_email(order.customer, f"Total: {total}")

# After
def process_order(order):
    total = calculate_total(order)
    send_confirmation(order.customer, total)

def calculate_total(order):
    subtotal = sum(item.price * item.quantity for item in order.items)
    return subtotal * (1 - order.discount)
```
## Rename
**When:** Name doesn't describe purpose.
```python
# Before: def proc(d): for x in d: if x.a > 100: x.f = True
# After:
def flag_high_value_transactions(transactions):
    for transaction in transactions:
        if transaction.amount > 100:
            transaction.flagged = True
```
## Inline
**When:** Method body as clear as name; indirection adds no value.
```python
# Before: total = get_price(item) * quantity
# After:  total = item.price * quantity
```
**Caution:** Don't inline if multiple callers or encapsulated logic.
## Move
**When:** Method uses more from another class (feature envy).
```python
# Before: Order.calculate_shipping() uses self.address.distance * self.address.rate
# After:  Address.calculate_shipping() -> Order delegates to address
```
## Simplify Conditionals
**Guard Clauses:**
```python
# Before: nested if/else
# After:
def get_payment(employee):
    if not employee.is_active:
        return 0
    if employee.is_full_time:
        return employee.salary
    return employee.hourly_rate * employee.hours
```
## Quick Reference
| Smell | Refactoring |
|-------|-------------|
| Long method | Extract Method |
| Unclear name | Rename |
| Trivial delegation | Inline |
| Feature envy | Move Method |
| Deep nesting | Guard Clauses |
| Type checking | Polymorphism |
| Duplicated code | Extract + Reuse |
| Magic numbers | Extract Constant |
## Safety Checklist
Before: [ ] All tests passing [ ] Behavior-preserving [ ] Can verify with tests
After: [ ] All tests passing [ ] No new behavior [ ] Code clearer

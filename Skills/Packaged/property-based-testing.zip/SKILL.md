---
name: property-based-testing
description: Guide developers through property-based testing including property definition, shrinking, and framework-specific implementation
version: "0.52.0"
license: Complete terms in LICENSE.txt
---
# Property-Based Testing
## When to Use
- Writing tests for functions with many possible inputs
- Testing mathematical or algorithmic properties
- Finding edge cases traditional testing might miss
- Verifying serialization/deserialization roundtrips
- Testing parsers or data transformations
## Key Concepts
- **Property:** Assertion that should hold for all valid inputs
- **Generator:** Creates random test inputs
- **Shrinking:** When test fails, finds the minimal failing case
- **Counterexample:** Specific input that violates the property
## Property Definition Patterns
### Common Property Types
**Roundtrip/Inverse:**
```
For all x: decode(encode(x)) == x
```
**Idempotence:**
```
For all x: f(f(x)) == f(x)
```
**Commutativity:**
```
For all a, b: f(a, b) == f(b, a)
```
**Associativity:**
```
For all a, b, c: f(f(a, b), c) == f(a, f(b, c))
```
**Identity:**
```
For all x: f(x, identity) == x
```
**Invariant:**
```
For all operations: invariant(state) remains true
```
**Comparison to Reference:**
```
For all x: new_implementation(x) == reference_implementation(x)
```
### Writing Good Properties
- **Describe what, not how** - "sorting preserves length", not "first pass puts smallest element first"
- **Make properties specific** - `len(reverse(list)) == len(list)`, not "reverse works correctly"
- **Combine multiple properties:**
```
Properties of sort(list):
1. len(sort(list)) == len(list)           [preserves length]
2. is_sorted(sort(list)) == true          [ordering]
3. multiset(sort(list)) == multiset(list) [same elements]
```
## Generators
### Custom Generators
**Constrained values:**
```
positive_int = integers(min_value=1)
email = from_regex(r'[a-z]+@[a-z]+\.[a-z]{2,3}')
small_list = lists(integers(), min_size=0, max_size=10)
```
**Composite generators:**
```
user = builds(User, name=text(min_size=1, max_size=50), age=integers(0, 150), email=emails())
```
**Dependent generators:**
```
list_and_index = lists(integers(), min_size=1).flatmap(
    lambda lst: tuples(just(lst), integers(0, len(lst)-1))
)
```
### Best Practices
1. Start simple - use built-in generators first
2. Add constraints gradually
3. Cover edge cases - include boundaries and special values
4. Match domain - generate realistic data
## Shrinking
When test fails, framework finds simpler input that still fails:
```
Original failing input: [43, -91, 7, 0, -15, 28, -3, 99]
After shrinking:        [0, -1]
```
### Analyzing Shrunk Counterexamples
1. **Understand why it fails** - minimal case reveals the bug
2. **Add as regression test** - keep counterexample as example test
3. **Fix the bug** - use counterexample to guide fix
4. **Verify** - re-run property test to confirm
## Framework-Specific Guidance
### Python (Hypothesis)
```python
from hypothesis import given, strategies as st

@given(st.lists(st.integers()))
def test_sort_preserves_length(lst):
    assert len(sorted(lst)) == len(lst)
```
### JavaScript (fast-check)
```javascript
const fc = require('fast-check');
test('sort preserves length', () => {
  fc.assert(fc.property(fc.array(fc.integer()), (arr) => {
    return arr.sort().length === arr.length;
  }));
});
```

| Language | Framework | Notes |
|----------|-----------|-------|
| Python | Hypothesis | Most popular, excellent shrinking |
| JavaScript | fast-check | Good performance, TypeScript support |
| Java | jqwik | JUnit 5 integration |
| Scala | ScalaCheck | Inspired by QuickCheck |
| Rust | proptest | Good Rust integration |
| Go | gopter | Based on ScalaCheck |
| Erlang | PropEr | For concurrent systems |
## Common Pitfalls
1. **Overly constrained generators** - Test with varying sizes including empty
2. **Testing implementation details** - Test properties, not implementation
3. **Non-deterministic properties** - Use deterministic properties
4. **Slow generators** - Size inputs appropriately, use max_examples
5. **Ignoring counterexamples** - Fix the bug, don't hide with @seed
## Debugging Failed Properties
1. Read the counterexample
2. Reproduce manually with exact counterexample
3. Simplify if needed
4. Add debug logging
5. Fix the bug
6. Add regression test with counterexample
## Resources
- `resources/property-patterns.md` - Additional property patterns
- `resources/shrinking-guide.md` - Detailed shrinking explanation
- `resources/framework-examples.md` - Framework-specific code examples
## Related Skills
- `test-writing-patterns` - Example-based testing patterns
- `mutation-testing` - Test suite quality assessment
- `tdd-red-phase` - Writing failing tests first
---
**End of Property-Based Testing Skill**

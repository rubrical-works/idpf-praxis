# Framework Examples
**Version:** {{VERSION}}
## Python - Hypothesis
```bash
pip install hypothesis
```
### Basic Example
```python
from hypothesis import given, strategies as st

@given(st.integers(), st.integers())
def test_addition_commutative(a, b):
    assert a + b == b + a

@given(st.lists(st.integers()))
def test_sort_idempotent(xs):
    assert sorted(sorted(xs)) == sorted(xs)
```
### Custom Strategies
```python
from hypothesis import strategies as st
from dataclasses import dataclass

emails = st.from_regex(r'[a-z]+@[a-z]+\.[a-z]{2,3}', fullmatch=True)

@dataclass
class User:
    name: str
    age: int
    email: str

users = st.builds(User, name=st.text(min_size=1, max_size=50),
    age=st.integers(min_value=0, max_value=150), email=emails)

@given(users)
def test_user_serialization(user):
    assert User.from_json(user.to_json()) == user
```
### Settings and Stateful Testing
```python
from hypothesis import given, settings, Verbosity
from hypothesis.stateful import RuleBasedStateMachine, rule, invariant

@given(st.lists(st.integers()))
@settings(max_examples=500, verbosity=Verbosity.verbose, deadline=None)
def test_with_many_examples(xs):
    assert my_property(xs)

class DatabaseStateMachine(RuleBasedStateMachine):
    def __init__(self):
        super().__init__()
        self.db = Database()
        self.expected_keys = set()
    @rule(key=st.text(), value=st.integers())
    def insert(self, key, value):
        self.db.insert(key, value)
        self.expected_keys.add(key)
    @rule(key=st.text())
    def delete(self, key):
        self.db.delete(key)
        self.expected_keys.discard(key)
    @invariant()
    def keys_match(self):
        assert set(self.db.keys()) == self.expected_keys

TestDatabase = DatabaseStateMachine.TestCase
```
## JavaScript - fast-check
```bash
npm install fast-check
```
### Basic Example
```javascript
const fc = require('fast-check');
test('addition is commutative', () => {
  fc.assert(fc.property(fc.integer(), fc.integer(), (a, b) => {
    return a + b === b + a;
  }));
});
```
### Custom Arbitraries
```javascript
const emailArb = fc.tuple(
  fc.stringOf(fc.char().filter(c => /[a-z]/.test(c)), { minLength: 1 }),
  fc.stringOf(fc.char().filter(c => /[a-z]/.test(c)), { minLength: 1 }),
  fc.constantFrom('com', 'org', 'net')
).map(([user, domain, tld]) => `${user}@${domain}.${tld}`);

const userArb = fc.record({
  name: fc.string({ minLength: 1, maxLength: 50 }),
  age: fc.integer({ min: 0, max: 150 }),
  email: emailArb
});
```
### Async and Model-Based Testing
```javascript
// Async
await fc.assert(fc.asyncProperty(fc.string(), async (input) => {
  const result = await asyncFunction(input);
  return result !== undefined;
}));

// Model-based
class InsertCommand {
  constructor(key, value) { this.key = key; this.value = value; }
  check(model) { return true; }
  run(model, real) {
    model.set(this.key, this.value);
    real.insert(this.key, this.value);
  }
}
```
## Java - jqwik
```xml
<dependency>
    <groupId>net.jqwik</groupId>
    <artifactId>jqwik</artifactId>
    <version>1.8.0</version>
    <scope>test</scope>
</dependency>
```
```java
import net.jqwik.api.*;
class MathProperties {
    @Property
    boolean additionCommutative(@ForAll int a, @ForAll int b) {
        return a + b == b + a;
    }
}
```
## Rust - proptest
```toml
[dev-dependencies]
proptest = "1.0"
```
```rust
use proptest::prelude::*;
proptest! {
    #[test]
    fn addition_commutative(a: i32, b: i32) {
        prop_assert_eq!(a.wrapping_add(b), b.wrapping_add(a));
    }
    #[test]
    fn sort_idempotent(mut vec: Vec<i32>) {
        vec.sort();
        let first = vec.clone();
        vec.sort();
        prop_assert_eq!(first, vec);
    }
}
```
## Go - gopter
```bash
go get github.com/leanovate/gopter
```
```go
func TestAdditionCommutative(t *testing.T) {
    properties := gopter.NewProperties(nil)
    properties.Property("addition is commutative", prop.ForAll(
        func(a, b int) bool { return a+b == b+a },
        gen.Int(), gen.Int(),
    ))
    properties.TestingRun(t)
}
```
## Framework Comparison

| Feature | Hypothesis | fast-check | jqwik | proptest |
|---------|------------|------------|-------|----------|
| Language | Python | JavaScript | Java | Rust |
| Shrinking | Excellent | Good | Good | Good |
| Stateful | Yes | Yes | Yes | Limited |
| Async | Limited | Yes | Yes | Yes |
---
**See SKILL.md for complete property-based testing guidance**

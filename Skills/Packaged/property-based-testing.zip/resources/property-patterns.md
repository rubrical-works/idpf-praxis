# Property Patterns
**Version:** {{VERSION}}
## Data Structure Properties
### List/Array
**Length preservation:**
```
len(reverse(xs)) == len(xs)
len(sort(xs)) == len(xs)
len(filter(p, xs)) <= len(xs)
len(map(f, xs)) == len(xs)
```
**Element preservation:**
```
set(reverse(xs)) == set(xs)
x in xs implies x in reverse(xs)
```
**Ordering:**
```
is_sorted(sort(xs))
```
**Concatenation:**
```
len(xs + ys) == len(xs) + len(ys)
(xs + ys) + zs == xs + (ys + zs)  # associative
xs + [] == xs  # identity
```
### Map/Dictionary
```
get(insert(m, k, v), k) == v
k not in keys(delete(m, k))
len(keys(m)) == len(values(m))
```
### Set
```
union(a, b) == union(b, a)           # commutative
union(a, empty) == a                  # identity
intersect(a, b) == intersect(b, a)   # commutative
intersect(a, a) == a                  # idempotent
diff(a, a) == empty
```
## Numeric Properties
**Addition:** commutative, associative, identity (0), inverse (-a)
**Multiplication:** commutative, associative, identity (1), annihilator (0)
**Comparison:** transitivity, trichotomy, reflexivity
## String Properties
```
len(s + t) == len(s) + len(t)
s + "" == s
lower(lower(s)) == lower(s)  # idempotent
len(lower(s)) == len(s)
join(sep, split(sep, s)) == s  # for simple cases
```
## Encoding/Serialization Properties
**Roundtrip:**
```
decode(encode(x)) == x
deserialize(serialize(x)) == x
decrypt(encrypt(x, key), key) == x
```
**Length bounds:**
```
len(compress(x)) <= len(x) + overhead
len(base64encode(x)) == ceiling(len(x) * 4 / 3)
```
## State Machine Properties
**Invariants:**
```
for all operations: balance >= 0
for all operations: total_in - total_out == balance
for all states: count <= max_capacity
```
**Operations:**
```
close(close(resource)) == close(resource)  # idempotent
undo(do(state, action), action) == state   # reversible
```
## API/Protocol Properties
**REST:**
```
GET is safe and idempotent
PUT is idempotent
DELETE is idempotent
valid_request implies status in [200, 201, 204]
invalid_request implies status in [400, 422]
```
## Fuzzing-Oriented Properties
**Parser:**
```
for all input: parse(input) returns result or error, never crashes
parse(input) == parse(input)  # deterministic
```
**Sanitization:**
```
sanitize(sanitize(input)) == sanitize(input)  # idempotent
sanitize(any_input) contains no dangerous patterns
```
## Test Oracle Patterns
**Reference implementation:**
```
optimized_impl(x) == reference_impl(x)
new_code(x) == old_code(x)  # for refactoring
```
**Metamorphic relations:**
```
sum(permute(xs)) == sum(xs)
mean(scale(xs, k)) == scale(mean(xs), k)
```
---
**See SKILL.md for complete property-based testing guidance**

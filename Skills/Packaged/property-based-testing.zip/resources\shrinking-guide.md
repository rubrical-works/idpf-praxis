# Shrinking Guide
**Version:** 0.52.0
## What is Shrinking?
Finding the smallest input that still fails a property test.
```
Property: All lists have length < 100
Generated: [42, -17, 88, 0, -5, 33, 91, 12, ...]  (150 elements) - FAILED
Shrinking: ...binary search...
Minimal counterexample: [0] * 100
```
## Shrinking Strategies
### Integer Shrinking
Try 0, then values closer to 0, halving distance:
```
Original: 847
Attempts: 0, 423, 211, 105, 52, 26, 13, 6, 3, 1
If fails at 3: minimal counterexample is 3
```
### String Shrinking
Try empty string, remove characters, simplify characters (all 'a').
### List Shrinking
Try empty list, remove elements from end/middle, shrink individual elements.
### Composite Shrinking
Shrink each component independently:
```python
User(name="Alice", age=30, active=True)
# Shrink attempts:
User(name="", age=0, active=True)
User(name="a", age=0, active=False)
```
## Framework-Specific Shrinking
### Hypothesis (Python)
```python
@given(st.lists(st.integers()))
@settings(max_examples=1000)  # More examples = better shrinking
def test_my_property(xs):
    assert my_function(xs)
```
### fast-check (JavaScript)
```javascript
fc.assert(
  fc.property(fc.array(fc.integer()), (arr) => myFunction(arr)),
  { numRuns: 1000 }
);
```
## Analyzing Shrunk Counterexamples
1. **Read** the counterexample carefully
2. **Understand** what it represents
3. **Identify** the failure pattern
4. **Verify** by reproducing manually
5. **Fix** the code

### Red Flags
- **Suspiciously simple** (0, [], "") - boundary conditions not handled
- **Special values** (None, NaN) - missing null/special value handling
- **Exact boundaries** (MAX_INT, MIN_INT) - overflow issues
## Best Practices
1. **Don't fight the shrinker** - avoid over-constraining generators
2. **Save counterexamples** as regression tests
3. **Debug shrinking** with verbose mode: `@settings(verbosity=Verbosity.verbose)`
## Common Issues
- **Shrinking takes too long** - Limit iterations, use simpler generators, custom shrinking
- **Counterexample not minimal** - Run more examples, use different seed
- **Invalid shrunk values** - Filter invalid values in shrink function, use constrained generators
---
**See SKILL.md for complete property-based testing guidance**

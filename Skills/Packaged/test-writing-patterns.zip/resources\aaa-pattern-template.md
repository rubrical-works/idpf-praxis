# AAA Pattern Template
**Version:** 0.52.0
## Template
```
test_[unit]_[scenario]_[expected]:
    // ===== ARRANGE =====
    [Set up test data and preconditions]
    [Create required objects]
    [Configure dependencies]

    // ===== ACT =====
    [Execute the behavior being tested]

    // ===== ASSERT =====
    [Verify the expected outcome]
    [Check side effects if applicable]
```
## Section Guidelines
**ARRANGE:** Create test data, init objects, configure mocks, define expected values. Keep minimal, explicit, intention-revealing.
**ACT:** Usually one line. Call function under test, capture result. One action per test.
**ASSERT:** Specific assertions (not generic), include failure messages, test behavior not implementation.
## Examples
### Simple Function
```
test_add_with_positive_numbers_returns_sum:
    // ARRANGE
    a = 2; b = 3; expected = 5
    // ACT
    result = add(a, b)
    // ASSERT
    assert result == expected
```
### Exception Testing
```
test_divide_by_zero_raises_exception:
    // ARRANGE
    numerator = 10; denominator = 0
    // ACT & ASSERT
    assert_raises(DivisionByZeroError):
        divide(numerator, denominator)
```
### Mock Verification
```
test_send_email_calls_email_service:
    // ARRANGE
    mock_email = create_mock()
    service = NotificationService(mock_email)
    // ACT
    service.send_welcome_email("alice@example.com", "Welcome!")
    // ASSERT
    mock_email.verify_called_once_with(to="alice@example.com", subject="Welcome", body="Welcome!")
```
## Variations
- **Minimal AAA:** Trivially simple tests can inline Act: `result = is_even(4); assert result == true`
- **Extended AAA:** Complex setup with CLEANUP phase at end for resources
## Common Mistakes
- **Mixing Act and Assert** -> Keep sections separate
- **Too much in Arrange** -> Extract to fixtures/builders
- **Multiple Acts** -> Split into separate tests, one action each
## Quick Reference
| Section | Goal | Keep |
|---------|------|------|
| ARRANGE | Prepare everything | Minimal, clear |
| ACT | One clear action | Simple, obvious |
| ASSERT | Prove correct | Specific, meaningful |

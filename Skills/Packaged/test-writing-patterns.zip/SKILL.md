---
name: test-writing-patterns
description: Guide experienced developers on test structure, patterns, assertions, and test doubles for effective test-driven development
version: "0.53.1"
license: Complete terms in LICENSE.txt
---
# Test Writing Patterns
## When to Use
- Guidance on test structure or organization
- Deciding test type or test double approach
- Assertion strategy questions
- Improving test quality and maintainability
## Test Structure Patterns
### AAA Pattern (Arrange-Act-Assert)
```
test_function_name():
    // ARRANGE - Setup test data, create objects, configure dependencies
    // ACT - result = call_function_under_test(inputs)
    // ASSERT - verify(result == expected)
```
### Given-When-Then (BDD Style)
`GIVEN = ARRANGE | WHEN = ACT | THEN = ASSERT`
### Four-Phase Test (Complex Tests)
`SETUP -> EXERCISE -> VERIFY -> TEARDOWN`
Use for: expensive setup, cleanup needed, integration tests
## Test Organization
### File Organization
Mirror production structure: `src/services/user_service` -> `tests/services/test_user_service`
### Naming Convention
**Pattern:** `test_[unit]_[scenario]_[expected]`
```
test_add_positive_numbers_returns_sum
test_get_user_when_not_found_returns_null
test_create_order_with_invalid_data_raises_exception
```
### Suite Organization
By type: `unit/`, `integration/`, `e2e/`, `performance/`
By feature: `user_management/`, `order_processing/`, etc.
## Assertion Strategies
### Single Concept Per Test
```
// GOOD: Related assertions verifying same concept
assert user.name == "Alice"
assert user.age == 30
// BAD: Unrelated operations - split into separate tests
```
### Assertion Quality
- Specific and precise, not generic `assert True`
- Include helpful failure messages
- Test observable behavior, not implementation details
### Common Assertion Types
| Type | Example |
|------|---------|
| Equality | `assert actual == expected` |
| Truthiness | `assert condition is true` |
| Comparison | `assert value > 0` |
| Collection | `assert item in collection` |
| Exception | `assert raises(ExpectedException)` |
| Type | `assert isinstance(obj, ExpectedType)` |
## Test Doubles
| Type | Purpose | When to Use |
|------|---------|-------------|
| **Stub** | Returns fixed data | Control dependency behavior |
| **Mock** | Verifies interactions | Verify method called, check params |
| **Fake** | Simplified working impl | Real impl too slow/complex |
| **Spy** | Records calls to real object | Real behavior + verification |
**Selection:** Control response -> Stub | Verify call -> Mock | Working simple version -> Fake | Real + verify -> Spy
## Test Isolation
**Each test:** Sets up own data, cleans up, runs in any order, no dependencies on other tests
- **Setup/Teardown:** Fresh data before, cleanup after
- **Fixtures:** Reusable test data, fresh per test, no shared mutable state
- **Database:** Transaction rollback, separate test DB, or in-memory
## Test Data Strategies
- **Explicit over random** - Deterministic, clear test data
- **Minimal** - Simplest data that tests the behavior
- **Builders** - For complex objects: defaults for irrelevant fields, explicit about what matters
## Testing Types
| Type | Speed | Dependencies | Focus |
|------|-------|-------------|-------|
| Unit | Fast | None (doubles) | Logic, edge cases |
| Integration | Medium | Real deps | Contracts, data flow |
| E2E | Slow | Real system | Critical paths, business scenarios |
## Parameterized Tests
Same test logic, different data - reduces duplication, easy to add cases:
```
test_add_numbers:
    parameters: (2,3,5), (-2,-3,-5), (2,-3,-1), (0,0,0)
    for each (a, b, expected): assert add(a, b) == expected
```
## Test Smells
| Smell | Fix |
|-------|-----|
| Does too much | Split into focused tests |
| Brittle | Test behavior, not implementation |
| Slow | Use doubles, optimize setup |
| Unclear | Better naming, clear AAA |
| Order-dependent | Ensure isolation |
| Duplicate setup | Extract to fixtures/builders |
## Resources
- `resources/aaa-pattern-template.md` - AAA test template
## Relationship to Other Skills
**Used by:** `tdd-red-phase`, `tdd-green-phase`, `tdd-refactor-phase`
**Complements:** `tdd-failure-recovery`
---
**End of Test Writing Patterns Skill**

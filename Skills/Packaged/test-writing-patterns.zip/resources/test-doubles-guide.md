# Test Doubles Guide
**Version:** {{VERSION}}
When to use each type of test double, with selection criteria and usage examples.
## Quick Selection Guide
```
Need to control response?       → Stub
Need to verify call made?       → Mock
Need working but simple version? → Fake
Need real behavior + verification? → Spy
```
---
## Stub
**Purpose:** Provide predetermined responses to calls
**When to use:** Control dependency behavior, isolate unit under test, avoid external dependencies (APIs, databases, file systems)
**Characteristics:** Returns fixed values, no behavior verification, simplest test double
```
stub_database.when_called_with(user_id=1).returns({name: "Alice"})
stub_api.when_called_with(url="/status").returns({status: 200})
stub_fs.when_read("config.json").returns('{"debug": true}')
```
**Common mistake:** Over-stubbing — if you stub most of the class, reconsider your design.
---
## Mock
**Purpose:** Verify interactions/calls were made correctly
**When to use:** Verify method was called, check call parameters, verify call count or order
**Characteristics:** Records calls, can verify expectations after test, behavior verification
```
mock_logger = create_mock()
service.process(invalid_data)
mock_logger.verify_called_with("error", "Invalid data")

mock_email = create_mock()
registration.complete(user)
mock_email.verify_called_once_with(to=user.email, subject="Welcome")
```
**Common mistake:** Verifying too many interactions — test behavior, not implementation.
---
## Fake
**Purpose:** Working implementation (simplified)
**When to use:** Real implementation too slow/complex, need realistic behavior for integration tests
**Characteristics:** Functional implementation, simpler than production, actually works
```
fake_db = InMemoryDatabase()
fake_db.insert({id: 1, name: "Alice"})
result = fake_db.query({name: "Alice"})
assert result.id == 1

fake_fs = InMemoryFileSystem()
fake_fs.write("/tmp/test.txt", "content")
assert fake_fs.read("/tmp/test.txt") == "content"
```
**Common mistake:** Making fakes too complex — if the fake is as complex as the real thing, use the real thing.
---
## Spy
**Purpose:** Record information about calls while delegating to real object
**When to use:** Need real behavior plus verification, observe interactions without changing behavior
**Characteristics:** Wraps real object, records calls, delegates to real implementation
```
spy_cache = spy_on(real_cache)
service.get_user(1)  // cache miss
service.get_user(1)  // cache hit
assert spy_cache.call_count("get") == 2
assert spy_cache.call_count("set") == 1
```
**Common mistake:** Using spies when stubs would suffice — spies add complexity.
---
## Decision Matrix
| Scenario | Best Double | Reason |
|----------|-------------|--------|
| Database in unit test | Stub or Fake | Control data, avoid real DB |
| Verifying email sent | Mock | Need to verify interaction |
| Testing with simplified DB | Fake | Need working behavior |
| Logging behavior | Spy | Keep real logging + verify |
| External API | Stub | Control responses |
| Event publisher | Mock | Verify events emitted |
| Cache layer | Spy or Fake | Observe behavior or simplify |
| File system | Stub or Fake | Avoid real file operations |
---
## Anti-Patterns
### Over-Mocking
**Symptom:** Test has more mock setup than assertions
**Fix:** Simplify dependencies, consider integration test instead
### Testing Implementation
**Symptom:** Test breaks when refactoring without behavior change
**Fix:** Verify outcomes, not method calls
### Mocking Value Objects
**Symptom:** Mocking simple data objects
**Fix:** Use real value objects — they have no external dependencies
### Complex Stub Chains
**Symptom:** `stub.returns(stub.returns(stub.returns(...)))`
**Fix:** Extract into a fake with real behavior
---
**Use the simplest double that satisfies the test requirement**

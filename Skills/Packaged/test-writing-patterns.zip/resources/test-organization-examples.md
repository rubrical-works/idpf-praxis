# Test Organization Examples
**Version:** 0.53.1
Practical examples of test file and suite organization.
## Principle: Mirror Production Structure
```
Production:                    Tests:
  src/                           tests/
    services/                      services/
      user_service                   test_user_service
    utils/                         utils/
      validator                      test_validator
    models/                        models/
      user                           test_user
```
---
## Organization by Test Type
```
tests/
  unit/              # Fast, isolated (~80%)
  integration/       # Real dependencies (~15%)
  e2e/               # Full workflows (~5%)
  fixtures/          # Shared test data
  helpers/           # Shared utilities
```
**Benefits:** Clear speed separation, CI can run unit first, easy gap identification.
## Organization by Feature
```
tests/
  user_management/
    test_registration.py
    test_authentication.py
  order_processing/
    test_cart.py
    test_checkout.py
```
**Benefits:** Easy feature-test mapping, aligns with user stories.
---
## Language-Specific Conventions
### Python (pytest)
- `test_` prefix on files and functions
- `conftest.py` for shared fixtures
- `pyproject.toml` for config
### JavaScript (Jest/Vitest)
- `.test.js` or `.spec.js` suffix
- Co-located tests for unit, `__tests__/` for integration
- `jest.config.js` for config
### Ruby (RSpec)
- `_spec.rb` suffix
- Mirror `app/` in `spec/`
- `spec_helper.rb` for config
---
## Naming Conventions
### Test File Naming
| Pattern | Example | When |
|---------|---------|------|
| `test_[module]` | `test_user_service.py` | Python (pytest) |
| `[module].test.js` | `userService.test.js` | JavaScript (Jest) |
| `[module]_spec.rb` | `user_service_spec.rb` | Ruby (RSpec) |
| `[Module]Test.java` | `UserServiceTest.java` | Java (JUnit) |
### Test Function Naming
**Pattern:** `test_[unit]_[scenario]_[expected]`
```
test_create_user_with_valid_data_returns_user
test_create_user_with_missing_email_raises_error
test_delete_user_as_admin_succeeds
```
### Test Suite Naming
```
describe "UserService":
  describe "create_user":
    it "returns user with valid data"
    it "raises error with missing email"
```
---
## Fixtures and Test Data
### Factory Pattern
```
function createUser(overrides = {}):
    return {
        id: 1, name: "Test User",
        email: "test@example.com",
        role: "member", ...overrides
    }

user = createUser({role: "admin"})
```
---
## CI Integration
```yaml
steps:
  - name: Unit tests
    run: test --type unit          # ~seconds
  - name: Integration tests
    run: test --type integration   # ~minutes
  - name: E2E tests
    run: test --type e2e           # ~minutes
```
---
**Consistency within a project matters more than which convention you choose**

# Assertion Patterns
**Version:** {{VERSION}}
Common assertion patterns organized by scenario.
## Core Principles
1. **One concept per test** — related assertions about the same concept are fine
2. **Specific over generic** — `assert result == 5` over `assert result is not null`
3. **Meaningful failure messages** — include context that helps diagnose failures
4. **Test behavior, not implementation** — assert on observable outcomes
---
## Assertion Patterns by Scenario
### Value Equality
```
assert result == expected_value
assert abs(result - expected) < tolerance  // floating point
assert result.lower() == expected.lower()  // case-insensitive
```
### Truthiness and Existence
```
assert condition is true
assert result is not null
assert collection is empty
```
### Collection Assertions
```
assert item in collection
assert len(collection) == expected_count
assert collection == [1, 2, 3]  // ordered
assert set(collection) == set(expected)  // unordered
assert all(item in collection for item in required_items)  // subset
```
### Exception and Error Assertions
```
assert_raises(ExpectedError):
    function_that_should_fail()

assert_raises(ValueError, message="Invalid input"):
    validate(bad_data)
```
### Object State Assertions
```
assert user.name == "Alice"
assert order.status == "completed"
assert order.total == 99.99
```
### API Response Assertions
```
assert response.status == 200
assert response.json()["name"] == "Alice"
assert response.headers["content-type"] == "application/json"
```
### Side Effect Assertions
```
assert db.count("users") == initial_count + 1
assert file_exists("/tmp/output.txt")
mock.verify_called_once()
mock.verify_called_with(expected_args)
```
---
## Anti-Patterns
### Assert True (Useless)
**Bad:** `assert True` or `assert result` — too vague
**Good:** `assert result == expected_value`
### Assert Everything
**Bad:** Testing too many unrelated properties in one test
**Good:** Split into focused tests or assert only relevant properties
### Magic Numbers
**Bad:** `assert result == 42`
**Good:** `expected_total = item_price * quantity; assert result == expected_total`
### Assertion Without Message
**Bad:** `assert response.status == 200` — failure: "AssertionError"
**Good:** `assert response.status == 200, "Expected OK but got {response.status}: {response.body}"`
---
## Framework-Specific Styles
| Framework | Equality | Exception | Approximate |
|-----------|----------|-----------|-------------|
| pytest | `assert a == b` | `with pytest.raises(E)` | `assert a == pytest.approx(b)` |
| Jest | `expect(a).toBe(b)` | `expect(fn).toThrow(E)` | `expect(a).toBeCloseTo(b)` |
| JUnit | `assertEquals(a, b)` | `assertThrows(E, fn)` | `assertEquals(a, b, delta)` |
| RSpec | `expect(a).to eq(b)` | `expect{fn}.to raise_error(E)` | `expect(a).to be_within(d).of(b)` |
| Node assert | `assert.equal(a, b)` | `assert.throws(fn, E)` | manual |
---
**Write assertions that read like specifications**

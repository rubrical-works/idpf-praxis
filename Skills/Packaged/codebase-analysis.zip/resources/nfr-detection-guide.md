# NFR Detection Guide
**Version:** {{VERSION}}
**Purpose:** Patterns for inferring Non-Functional Requirements from code
---
## Security (SEC)
### SEC-001: Password Hashing
**Patterns:** `bcrypt.hashpw()`, `argon2.hash()`, `hashlib.pbkdf2_hmac()`, `crypto.pbkdf2()`
**Inferred NFR:** Passwords must be hashed using industry-standard algorithms before storage.
### SEC-002: Authentication Required
**Patterns:** `@login_required`, `@jwt_required`, `authMiddleware`, `@UseGuards(AuthGuard)`, `@PreAuthorize`
**Inferred NFR:** Protected resources require valid authentication.
### SEC-003: Authorization Controls
**Patterns:** `@requires_permission('admin')`, `@roles_required()`, `@Roles('admin')`, `checkPermission()`
**Inferred NFR:** Role-based access control (RBAC) for sensitive operations.
### SEC-004: CSRF Protection
**Patterns:** `csrf_token()`, `@csrf_protect`, `app.use(csrf())`, `<input type="hidden" name="_csrf">`
**Inferred NFR:** CSRF protection for state-changing requests.
### SEC-005: Security Headers
**Patterns:** `helmet()`, `X-Frame-Options`, `Content-Security-Policy`, `Strict-Transport-Security`
**Inferred NFR:** Security headers configured per OWASP recommendations.
### SEC-006: Input Validation
**Patterns:** `validate(data, schema)`, `joi.validate()`, `sanitizeHtml()`, `@Valid @RequestBody`
**Inferred NFR:** All user input validated and sanitized.
### SEC-007: Data Encryption
**Patterns:** `cipher.encrypt()`, `Fernet(key).encrypt()`, `crypto.createCipheriv('aes-256-gcm')`
**Inferred NFR:** Sensitive data encrypted at rest using AES-256 or equivalent.
### SEC-008: Rate Limiting
**Patterns:** `@ratelimit(limit=100, per=60)`, `rateLimit({ windowMs: 60000, max: 100 })`, `@Throttle(100, 60)`
**Inferred NFR:** API rate limiting to prevent abuse.
---
## Performance (PERF)
### PERF-001: Caching
**Patterns:** `@cache.cached()`, `redis.get(key)`, `@lru_cache()`, `@Cacheable({ ttl: 300 })`
**Inferred NFR:** Frequently accessed data cached with TTL expiry.
### PERF-002: Async Processing
**Patterns:** `async def`, `await`, `asyncio.gather()`, `Promise.all()`
**Inferred NFR:** Non-blocking async processing for I/O operations.
### PERF-003: Connection Pooling
**Patterns:** `create_pool(min_size=5, max_size=20)`, `new Pool({ max: 20 })`
**Inferred NFR:** Database connection pooling configured.
### PERF-004: Database Indexing
**Patterns:** `Index('idx_user_email')`, `create_index()`, `CREATE INDEX`
**Inferred NFR:** Indexes on frequently queried columns.
### PERF-005: Pagination
**Patterns:** `query.limit().offset()`, `Paginator(per_page=20)`, `.skip().limit()`
**Inferred NFR:** List endpoints support pagination.
### PERF-006: Response Compression
**Patterns:** `Compress(app)`, `app.use(compression())`, `Content-Encoding: gzip`
**Inferred NFR:** HTTP responses compressed.
---
## Reliability (REL)
### REL-001: Retry Logic
**Patterns:** `@retry(max_attempts=3)`, `tenacity.retry()`, `retry(operation, { retries: 3 })`
**Inferred NFR:** Transient failures handled with retry logic.
### REL-002: Circuit Breaker
**Patterns:** `@circuit(failure_threshold=5)`, `CircuitBreaker(fail_max=5)`, `opossum`
**Inferred NFR:** Circuit breaker prevents cascade failures.
### REL-003: Timeout Handling
**Patterns:** `requests.get(url, timeout=30)`, `axios.get(url, { timeout: 30000 })`, `AbortController`
**Inferred NFR:** External calls have timeout limits.
### REL-004: Fallback Behavior
**Patterns:** `except: result = fallback_value`, `.catch(() => fallbackValue)`, `getOrDefault()`
**Inferred NFR:** Graceful degradation with fallback behavior.
### REL-005: Transaction Support
**Patterns:** `with db.begin()`, `prisma.$transaction()`, `@Transactional`
**Inferred NFR:** Data operations wrapped in transactions.
### REL-007: Health Checks
**Patterns:** `@app.route('/health')`, `app.get('/health')`, `livenessProbe`/`readinessProbe`
**Inferred NFR:** Health check endpoint for monitoring.
---
## Observability (OBS)
### OBS-001: Logging
**Patterns:** `logger.info()` with structured data, `winston.createLogger()`
**Inferred NFR:** Structured logging implemented.
### OBS-002: Metrics
**Patterns:** `prometheus_client.Counter()`, `statsd.increment()`, `promClient.register.metrics()`
**Inferred NFR:** Application metrics collected.
### OBS-003: Distributed Tracing
**Patterns:** `opentelemetry`, `tracer.startSpan()`
**Inferred NFR:** Distributed tracing enabled.
### OBS-004: Audit Logging
**Patterns:** `audit_log.record()`, `AuditLog.create()`
**Inferred NFR:** Security-relevant actions recorded in audit log.
---
## Confidence Scoring
| Evidence Type | Confidence |
|---------------|------------|
| Explicit decorator/annotation | High |
| Library import + usage | High |
| Configuration value | Medium |
| Pattern in single location | Medium |
| Comment/docstring mention | Low |
| Naming convention only | Low |
---
**End of Guide**

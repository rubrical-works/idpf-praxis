# Architecture Inference Guide
**Version:** {{VERSION}}
**Purpose:** Patterns for inferring system architecture from codebase structure
---
## Architecture Style Detection
### Monolith Patterns
**Indicators:** Single `src/`/`app/` directory, shared DB models, no service-to-service comms, single deployment unit.
```
project/
+-- src/
|   +-- models/
|   +-- views/
|   +-- controllers/
|   +-- utils/
+-- tests/
```
### Microservices Patterns
**Indicators:** Multiple `services/*/` with independent deps, service-to-service communication (gRPC, HTTP, message queues), multiple Dockerfiles, independent databases.
```
project/
+-- services/
|   +-- user-service/
|   |   +-- src/
|   |   +-- Dockerfile
|   +-- order-service/
|   +-- payment-service/
+-- shared/
+-- infrastructure/
```
### Modular Monolith Patterns
**Indicators:** Single deployment but modular `modules/`/`features/`, shared infrastructure, internal module boundaries.
---
## Architectural Patterns
### MVC
**Indicators:** `models/`, `views/`, `controllers/` directories or framework conventions (Rails, Django, Laravel).
| Pattern | Confidence |
|---------|------------|
| All three directories present | High |
| Two directories + framework | High |
| Only naming conventions | Medium |
### Clean Architecture / Hexagonal
**Indicators:** `domain/`, `application/`, `infrastructure/` separation, `ports/`/`adapters/` directories, dependency inversion.
```
project/
+-- domain/
|   +-- entities/
|   +-- repositories/  (interfaces)
+-- application/
|   +-- usecases/
+-- infrastructure/
|   +-- repositories/  (implementations)
|   +-- adapters/
+-- presentation/
```
### Layered Architecture
Clear layer separation: presentation -> business -> data. Dependencies flow downward.
### Event-Driven Architecture
**Indicators:** Message queue deps (RabbitMQ, Kafka, SQS), event handlers/emitters, `events/`/`handlers/`/`subscribers/` directories.
---
## Layer Detection
| Layer | Patterns |
|-------|---------|
| Presentation | `views/`, `templates/`, `components/`, `pages/`, `controllers/`, `handlers/`, `routes/` |
| Business Logic | `services/`, `usecases/`, `domain/`, `core/`, `interactors/` |
| Data Access | `repositories/`, `models/`, `db/`, `persistence/`, `entities/` |
| Infrastructure | `config/`, `infrastructure/`, `adapters/`, `utils/`, `lib/` |
---
## API Style Detection
| Style | Indicators |
|-------|-----------|
| REST | HTTP method annotations, resource-based routes, JSON responses |
| GraphQL | `schema.graphql`, `resolvers/`, `typeDefs`/`Query`/`Mutation` |
| gRPC | `.proto` files, generated code |
| WebSocket | Socket.io/ws deps, WebSocket handlers |
---
## Confidence Assessment
| Evidence Type | Confidence |
|---------------|------------|
| Explicit directory structure match | High |
| Framework conventions match | High |
| Partial pattern + supporting files | Medium |
| Only naming conventions | Medium |
| Inferred from code style | Low |
---
**End of Architecture Inference Guide**

# Tech Stack Detection Guide
**Version:** 0.53.1
**Purpose:** Patterns for detecting technology stacks from codebase analysis
---
## Language Detection
### By File Extension
| Extension | Language |
|-----------|----------|
| `.py` | Python |
| `.js`, `.mjs`, `.cjs` | JavaScript |
| `.ts`, `.tsx` | TypeScript |
| `.go` | Go |
| `.rs` | Rust |
| `.java` | Java |
| `.cs` | C# |
| `.rb` | Ruby |
| `.php` | PHP |
| `.swift` | Swift |
| `.kt`, `.kts` | Kotlin |
| `.scala` | Scala |
| `.ex`, `.exs` | Elixir |
### By Package Manager
| File | Language/Runtime |
|------|------------------|
| `package.json` | Node.js |
| `requirements.txt` | Python |
| `pyproject.toml` | Python (modern) |
| `go.mod` | Go |
| `Cargo.toml` | Rust |
| `Gemfile` | Ruby |
| `pom.xml` | Java (Maven) |
| `build.gradle` | Java/Kotlin (Gradle) |
| `composer.json` | PHP |
| `*.csproj` | .NET |
---
## Framework Detection
### Python
| Dependency | Framework | Type |
|------------|-----------|------|
| `flask` | Flask | Web micro-framework |
| `django` | Django | Full-stack web |
| `fastapi` | FastAPI | Async API |
| `celery` | Celery | Task queue |
| `sqlalchemy` | SQLAlchemy | ORM |
### JavaScript/TypeScript
| Dependency | Framework | Type |
|------------|-----------|------|
| `express` | Express.js | Web server |
| `fastify` | Fastify | Web server |
| `next` | Next.js | React framework |
| `nuxt` | Nuxt.js | Vue framework |
| `react` | React | Frontend |
| `vue` | Vue.js | Frontend |
| `angular` | Angular | Frontend |
| `nest` | NestJS | Backend |
### Go
| Import Path | Framework |
|-------------|-----------|
| `github.com/gin-gonic/gin` | Gin |
| `github.com/labstack/echo` | Echo |
| `github.com/gofiber/fiber` | Fiber |
| `gorm.io/gorm` | GORM (ORM) |
### Ruby
| Gem | Framework | Type |
|-----|-----------|------|
| `rails` | Ruby on Rails | Full-stack |
| `sinatra` | Sinatra | Micro-framework |
| `rspec` | RSpec | Testing |
### Java
| Dependency | Framework |
|------------|-----------|
| `spring-boot` | Spring Boot |
| `hibernate` | Hibernate (ORM) |
| `micronaut` | Micronaut |
| `quarkus` | Quarkus |
### .NET
| Package | Framework |
|---------|-----------|
| `Microsoft.AspNetCore` | ASP.NET Core |
| `Microsoft.EntityFrameworkCore` | EF Core |
| `xunit` / `NUnit` | Testing |
---
## Database Detection
| Dependency/Package | Database | Type |
|--------------------|----------|------|
| `pg`, `psycopg2` | PostgreSQL | Relational |
| `mysql2`, `pymysql` | MySQL | Relational |
| `sqlite3` | SQLite | Embedded |
| `mongodb`, `pymongo` | MongoDB | Document |
| `redis`, `ioredis` | Redis | Key-Value |
| `elasticsearch` | Elasticsearch | Search |
**From config:** `DATABASE_URL=postgres://`, `MONGO_URI=mongodb://`, `REDIS_URL=redis://`
---
## Infrastructure Detection
### From Dockerfile
| Base Image | Infers |
|------------|--------|
| `FROM node:` | Node.js runtime |
| `FROM python:` | Python runtime |
| `FROM golang:` | Go runtime |
| `FROM nginx:` | Web server/reverse proxy |
### From CI/CD Files
| File | Platform |
|------|----------|
| `.github/workflows/*.yml` | GitHub Actions |
| `.gitlab-ci.yml` | GitLab CI |
| `Jenkinsfile` | Jenkins |
| `.circleci/config.yml` | CircleCI |
| `azure-pipelines.yml` | Azure DevOps |
---
**End of Tech Stack Detection Guide**

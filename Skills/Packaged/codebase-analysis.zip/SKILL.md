---
name: codebase-analysis
description: Analyze existing codebases to extract structure, tech stack, and patterns
version: "0.53.1"
license: Complete terms in LICENSE.txt
---
# Skill: codebase-analysis
**Purpose:** Analyze existing codebases to extract structure, tech stack, and patterns
**Audience:** Used by /create-prd extract, /charter extraction, and codebase exploration
**Load with:** Anti-Hallucination-Rules-for-PRD-Work.md (for PRD/charter work)
**Critical:** All analysis output must be traceable to code evidence. Never invent details not supported by actual files, tests, or code patterns. Mark all inferences with confidence levels.
---
## When to Use
- `/create-prd extract` - PRD generation
- `/charter` extraction mode - Charter generation
- `/charter refresh` - Charter updates
- General codebase exploration
- **Legacy code analysis** - Understanding and documenting existing systems
- **Onboarding assistance** - Exploring unfamiliar codebases for new team members
---
## Analysis Capabilities
### 1. Tech Stack Detection
**Primary Sources:**
| File Pattern | Detects |
|--------------|---------|
| `package.json` | Node.js, npm deps |
| `requirements.txt`, `pyproject.toml` | Python, pip deps |
| `go.mod` | Go, modules |
| `Gemfile` | Ruby, gems |
| `pom.xml`, `build.gradle` | Java, Maven/Gradle |
| `Cargo.toml` | Rust, crates |
| `.csproj`, `packages.config` | .NET, NuGet |
**Secondary Sources:** `Dockerfile`, `.github/workflows/*.yml`, `docker-compose.yml`, `*.config`/`*.yaml`
### 2. Architecture Inference
| Pattern | Architecture Style |
|---------|-------------------|
| `src/`, `lib/`, `app/` | Monolith |
| `frontend/`, `backend/`, `api/` | Multi-tier |
| `services/*/`, `microservices/` | Microservices |
| `domain/`, `infrastructure/`, `application/` | Clean/Hexagonal |
| `models/`, `views/`, `controllers/` | MVC |
| `components/`, `pages/`, `hooks/` | Frontend component-based |
**Layer Detection:**
| Layer | Indicators |
|-------|------------|
| Presentation | `views/`, `templates/`, `components/`, `pages/` |
| API | `routes/`, `api/`, `endpoints/`, `handlers/` |
| Business Logic | `services/`, `domain/`, `core/`, `usecases/` |
| Data Access | `repositories/`, `models/`, `db/`, `data/` |
| Infrastructure | `config/`, `infrastructure/`, `utils/` |
### 3. Test Parsing
| Framework | File Pattern | Feature Extraction |
|-----------|--------------|-------------------|
| pytest | `test_*.py`, `*_test.py` | Function names, docstrings, parametrize |
| Jest | `*.test.js`, `*.spec.js` | describe/it blocks |
| JUnit | `*Test.java` | @Test, @DisplayName |
| RSpec | `*_spec.rb` | describe/context/it blocks |
| Go testing | `*_test.go` | Test* functions |
| xUnit | `*.Tests.cs` | [Fact], [Theory] methods |
```
Test File -> Test Suite -> Test Case -> Feature Description
                                     -> Expected Behavior
                                     -> Edge Cases
```
### 4. NFR Detection
**Security:** password hashing, JWT/OAuth, CORS, input validation, rate limiting
**Performance:** Redis/Memcached, connection pooling, async/await, CDN, load balancer
**Reliability:** retry/circuit breakers, health checks, structured logging, error handling, transactions
See `resources/nfr-detection-guide.md` for full pattern catalog.
---
## Analysis Commands
| Command | Purpose |
|---------|---------|
| `Analyze-Tech-Stack` | Detect languages, frameworks, dependencies |
| `Analyze-Architecture` | Infer structure, layers, patterns |
| `Analyze-Tests` | Parse tests for features |
| `Analyze-NFRs` | Detect NFRs from patterns |
| `Full-Analysis` | Run all commands |
---
## Confidence Levels
| Level | Meaning | Action |
|-------|---------|--------|
| **High** | Direct code evidence (test file, config value) | Use directly |
| **Medium** | Inferred from patterns (directory structure, naming) | Flag for validation |
| **Low** | Weak signals, assumptions | Require user confirmation |
```markdown
**Feature:** User Registration
**Confidence:** High
**Evidence:**
- test_user_registration.py (15 test cases)
- POST /api/register endpoint
- User model in models/user.py
```
---
## Resources
| Resource | Purpose |
|----------|---------|
| `resources/test-parsing-guide.md` | Detailed test parsing patterns |
| `resources/nfr-detection-guide.md` | NFR detection patterns by category |
| `resources/tech-stack-detection.md` | Tech stack detection patterns |
| `resources/architecture-inference.md` | Architecture inference patterns |
---
## Anti-Hallucination Rules
1. **Only report what exists** - Don't invent features not found in code
2. **Cite evidence** - Every finding must reference specific files/patterns
3. **Use confidence levels** - Be honest about inference certainty
4. **Flag gaps** - Note what's missing or unclear
5. **Validate with user** - Medium/Low confidence items need confirmation
---
**End of Skill Document**

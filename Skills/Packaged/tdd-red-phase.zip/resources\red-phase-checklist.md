# RED Phase Checklist
**Version:** 0.52.0
## Before Writing Test
- [ ] Behavior clearly identified
- [ ] Small and focused (one thing)
- [ ] Feature/behavior does not yet exist
- [ ] Test framework configured
## Writing the Test
- [ ] Name clearly describes behavior
- [ ] Follows AAA structure
- [ ] Minimal, explicit test data
- [ ] Clear, specific assertions
- [ ] Includes imports and setup
- [ ] Complete and syntactically correct
## Executing
- [ ] Runs without syntax errors
- [ ] FAILS (does not pass)
- [ ] No unexpected exceptions
- [ ] Failure message indicates missing implementation
## Verifying Failure
- [ ] Failure reason is correct (feature missing, not test bug)
- [ ] Message is understandable
- [ ] Fails for the RIGHT reason
- [ ] Confident it will pass once implemented
## Before GREEN
- [ ] Failure verified
- [ ] Ready to implement minimum code
- [ ] Proceed autonomously to GREEN phase
## Quick Diagnostics
- **Passes unexpectedly** -> Feature exists OR test invalid; review logic
- **Throws errors** -> Test bugs; fix before proceeding
- **Unclear failure** -> Add descriptive assertion messages; simplify

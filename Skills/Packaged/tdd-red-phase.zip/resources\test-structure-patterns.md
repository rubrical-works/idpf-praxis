# Test Structure Patterns
**Version:** 0.52.0
## Arrange-Act-Assert (AAA)
```python
def test_user_creation():
    # Arrange
    email = "test@example.com"
    name = "Test User"
    # Act
    user = create_user(email, name)
    # Assert
    assert user.email == email
    assert user.name == name
```
**Arrange:** Minimal setup | **Act:** Single action (one line) | **Assert:** Clear verification
## Given-When-Then (GWT)
```python
def test_authenticated_user_can_view_profile():
    # Given
    user = create_authenticated_user()
    # When
    response = view_profile(user)
    # Then
    assert response.status == 200
```
Use for: business behavior, acceptance tests, stakeholder-readable tests
Mapping: Given=Arrange | When=Act | Then=Assert
## Test Naming
**Pattern:** `test_[unit]_[scenario]_[expected]`
```python
test_user_with_invalid_email_raises_error
test_cart_with_items_calculates_total
test_login_with_wrong_password_fails
```
**Alternative:** `should_[expected]_when_[scenario]`
| Do | Don't |
|----|-------|
| Describe behavior | Generic names |
| Include condition | Numbers/abbreviations |
| State expected outcome | "test" in name |
## File Organization
**Per unit:** `test_user.py`, `test_order.py`, `test_payment.py`
**By feature:** `authentication/test_login.py`, `orders/test_create_order.py`
## Quick Reference
| Pattern | Use When |
|---------|----------|
| AAA | Default choice |
| GWT | BDD, business-focused |
| Per unit | Unit tests |
| By feature | Integration/E2E |
**Formulas:** `test_[what]_[condition]_[result]` | `test_[module_or_feature].py`

---
name: tdd-red-phase
description: Guide experienced developers through RED phase of TDD cycle - writing failing tests and verifying expected failures
version: "0.55.0"
license: Complete terms in LICENSE.txt
---
# TDD RED Phase
## When to Use
- Starting implementation of a new feature or behavior
- User triggers `work #N` in IDPF-Agile framework
- Beginning a new TDD iteration
## Prerequisites
- Working development environment with test framework configured
- Clear understanding of the behavior to be tested
- Claude Code available for test execution
## Objective
**Write a test that fails for the right reason.**
**Correct failure:** Feature doesn't exist yet; failure message indicates what's missing
**Incorrect failure:** Syntax error, missing imports, incorrect setup, test passes unexpectedly
## Workflow
### Step 1: Identify Testable Behavior
- One test per behavior, one behavior per test
- Focus on smallest testable behavior
**Good:** `"Function returns sum of two numbers"`, `"GET /users returns 200"`, `"Invalid email shows error"`
**Poor:** `"User management works"` (too broad), `"Fix the bug"` (not a behavior)
### Step 2: Write the Failing Test
**Structure (framework-agnostic):**
```
1. ARRANGE: Set up test data and preconditions
2. ACT: Execute the behavior being tested
3. ASSERT: Verify the expected outcome
```
**ASSISTANT provides in single code block:**
```
TASK: [Brief description of test being written]
STEP 1: [Create or open test file]
STEP 2: [Add necessary imports]
STEP 3: [Write complete test function with proper structure]
STEP 4: [Save file]
STEP 5: [Run test command]
STEP 6: [Verify test FAILS with expected message]
STEP 7: [Report back: Did test fail as expected?]
```
### Step 3: Execute and Verify Failure
- [ ] Test executed without syntax errors
- [ ] Test failed (not passed)
- [ ] Failure message indicates missing implementation
- [ ] Failure message is clear and understandable
### Step 4: Analyze
- **Fails as expected** -> RED complete, proceed autonomously to GREEN
- **Passes unexpectedly** -> Test invalid, ASSISTANT revises, repeat Step 2
- **Errors instead of fails** -> Test has bugs, ASSISTANT fixes, repeat Step 2
## Best Practices
- **Minimal tests:** Single behavior, simplest data, single assertion
- **Clear names:** `test_[feature]_[scenario]_[expected_result]`
- **Descriptive assertions:** Clear comparison, helpful failure messages, test behavior not implementation
## Common Mistakes
| Mistake | Solution |
|---------|----------|
| Test passes immediately | Verify feature doesn't exist; delete impl; re-run |
| Syntax errors | Fix syntax, ensure imports, verify framework |
| Test too broad | Split into one-per-behavior tests |
| Unclear failure message | Add descriptive assertion messages |
## Anti-Patterns
- **Implementation first** -> Write failing test FIRST
- **Skipping failure verification** -> ALWAYS run and verify fails
- **Tolerating test errors** -> Fix test so it fails cleanly
## Integration with IDPF-Agile
TDD executes **autonomously**. Only required user interaction: story completion (In Review -> Done).
## RED Phase Checklist
- [ ] Test code complete and syntactically correct
- [ ] Test executes without errors
- [ ] Test FAILS (does not pass)
- [ ] Failure message clearly indicates missing implementation
- [ ] Test name describes behavior
- [ ] Test focused on single behavior
- [ ] Minimal, clear test data
## Resources
- `resources/red-phase-checklist.md` - Quick reference checklist
- `resources/test-structure-patterns.md` - Common test structure patterns
- `resources/failure-verification-guide.md` - How to verify failures correctly
## Relationship to Other Skills
**Flows to:** `tdd-green-phase`
**Related:** `test-writing-patterns`, `tdd-failure-recovery`
---
**End of TDD RED Phase Skill**

# Failure Verification Guide
**Version:** {{VERSION}}
Tests must fail for the **right reason** in RED phase: confirms test validity, ensures it catches real bugs, validates no false positive.
## Intentional Failure Techniques
### 1: Run Before Implementation
```python
def test_user_can_login():
    result = login("test@example.com", "password123")
    assert result.success == True
# Run BEFORE writing login() -> Expected: NameError/AttributeError
```
### 2: Assert the Opposite
```python
# Temporarily flip assertion to verify test can fail
assert result != expected_value  # Should fail
# Revert to original after confirming
```
### 3: Hardcode Wrong Value
```python
def calculate_total(items):
    return 0  # Intentionally wrong
# Test asserts == 30 -> fails with 0 != 30
```
## Error Message Verification
Good failures show: what was expected, what was received, where it failed
```python
# Basic
assert total == 30
# Better
assert total == 30, f"Cart total should be 30, got {total}"
```
## Boundary Testing
| Boundary | Test Cases |
|----------|------------|
| Empty | `[]`, `""`, `None`, `0` |
| One | Single item |
| Many | Multiple items |
| Limits | Max/min values |
## Common Mistakes
- **Test never fails** (e.g., `assert user is not None`) -> Test behavior, not existence
- **Wrong failure reason** (AttributeError instead of AssertionError) -> Ensure failure at assertion
- **Tautological** (`assert 2+2==4`) -> Test your code, not the language
## Verification Checklist
- [ ] Test fails when run
- [ ] Failure at assertion (not setup/syntax)
- [ ] Message describes expected vs actual
- [ ] Would catch real bug
- [ ] Boundary cases have dedicated tests
## Quick Reference
| Technique | When |
|-----------|------|
| Run before implementation | Always first |
| Assert opposite | Verify existing tests |
| Hardcode wrong | Check assertion logic |
| Read error message | Every failure |
| Boundary tests | Edge cases |

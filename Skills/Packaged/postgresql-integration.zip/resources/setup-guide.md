# PostgreSQL Setup Guide
**Version:** {{VERSION}}
## Environment Setup
### 1. Install Client Library
**Python:** `pip install psycopg2-binary` (or `asyncpg` for async)
**Node.js:** `npm install pg` (or `pg-pool` for pooling)
**Ruby:** `gem install pg`
**Go:** `go get github.com/jackc/pgx/v5`
### 2. Configure Environment Variables
Create `.env` (add to `.gitignore`):
```
DATABASE_URL=postgresql://user:password@localhost:5432/dbname
PGUSER=myuser
PGPASSWORD=mypassword
PGHOST=localhost
PGPORT=5432
PGDATABASE=mydb
```
### 3. Verify Connection
```bash
psql -h localhost -U myuser -d mydb -c "SELECT 1"
```
## Connection Configuration Options
### Basic Parameters

| Parameter | Description | Default |
|-----------|-------------|---------|
| host | Server hostname | localhost |
| port | Server port | 5432 |
| database | Database name | (required) |
| user | Username | (required) |
| password | Password | (required) |

### Advanced Parameters

| Parameter | Description | Recommended |
|-----------|-------------|-------------|
| connect_timeout | Connection timeout (seconds) | 10 |
| application_name | Identifier in pg_stat_activity | Your app name |
| sslmode | SSL mode | require (production) |
## Production Configuration
### SSL Certificate Setup
```
?sslmode=verify-full&sslrootcert=/path/to/ca.crt&sslcert=/path/to/client.crt&sslkey=/path/to/client.key
```
### Connection Pooling Setup
```
min_connections: 2
max_connections: 10
idle_timeout: 30000
connection_timeout: 5000
```
**Calculate max connections:**
```
Available = PostgreSQL max_connections - reserved_connections
Per-instance pool = Available / number_of_app_instances
```
### Health Check Query
```sql
SELECT 1
-- Or more thorough:
SELECT current_database(), current_user, version()
```
## Troubleshooting Connection Issues
### Cannot Connect
1. Check PostgreSQL running: `sudo systemctl status postgresql` (Linux) / `brew services list | grep postgresql` (macOS)
2. Verify pg_hba.conf allows connection
3. Check firewall: `telnet localhost 5432`
### Authentication Failed
1. Verify username and password
2. Check user exists: `\du` in psql
3. Verify database exists: `\l` in psql
4. Check pg_hba.conf authentication method
### Connection Timeout
1. Increase connect_timeout parameter
2. Check network connectivity
3. Verify server not overloaded
4. Check firewall blocking
---
**See SKILL.md for complete integration guidance**

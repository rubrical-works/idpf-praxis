# PostgreSQL Common Errors
**Version:** 0.53.1
## Connection Errors
### ECONNREFUSED
```
Error: connect ECONNREFUSED 127.0.0.1:5432
```
**Causes:** Server not running, wrong host/port, firewall blocking.
**Fix:**
```bash
sudo systemctl start postgresql   # Linux
brew services start postgresql     # macOS
netstat -an | grep 5432            # Verify listening
```
### ETIMEDOUT
**Causes:** Network issue, firewall, server overloaded.
**Fix:** Test connectivity (`ping`/`telnet`), increase `?connect_timeout=30`, check security groups.
### Authentication Failed
```
FATAL: password authentication failed for user "username"
```
**Fix:** Verify credentials (`psql -h host -U user -d database`), check user exists (`SELECT usename FROM pg_user`), review `pg_hba.conf`.
### SSL Required
```
FATAL: no pg_hba.conf entry for host "x.x.x.x", SSL off
```
**Fix:** Add `?sslmode=require` to connection string.
## Query Errors
### Syntax Error
**Fix:** Check SQL syntax, quote reserved keywords with double quotes: `SELECT "order" FROM "table"`.
### Relation Does Not Exist
**Fix:**
```sql
SELECT tablename FROM pg_tables WHERE schemaname = 'public';
SHOW search_path;
SELECT * FROM schema_name.table_name;  -- fully qualified
```
### Column Does Not Exist
**Fix:**
```sql
SELECT column_name FROM information_schema.columns WHERE table_name = 'tablename';
SELECT "ColumnName" FROM table;  -- case-sensitive
```
## Constraint Violations
### Unique Violation
```sql
INSERT INTO users (email, name) VALUES ($1, $2)
ON CONFLICT (email) DO UPDATE SET name = EXCLUDED.name;
```
### Foreign Key Violation
```sql
-- Option 1: CASCADE on delete
FOREIGN KEY (parent_id) REFERENCES parent(id) ON DELETE CASCADE
-- Option 2: Delete children first
DELETE FROM children WHERE parent_id = $1;
DELETE FROM parent WHERE id = $1;
```
### Not Null Violation
Provide value for required column, or set default:
```sql
ALTER TABLE t ALTER COLUMN c SET DEFAULT 'default_value';
```
## Performance Issues
### Query Timeout
```sql
EXPLAIN ANALYZE your_query;
SET statement_timeout = '60s';  -- temporary
```
Add appropriate indexes.
### Too Many Connections
1. Implement connection pooling
2. Ensure connections returned to pool
3. Increase `max_connections` in postgresql.conf
4. Use PgBouncer for connection multiplexing
### Out of Memory
1. Use LIMIT to reduce result size
2. Process in batches
3. Increase `work_mem` carefully: `SET work_mem = '256MB';`
## Transaction Errors
### Serialization Failure
**Cause:** Concurrent transactions modifying same rows with SERIALIZABLE isolation.
**Fix:** Implement retry logic, use lower isolation if acceptable, reduce transaction scope.
### Deadlock Detected
**Fix:**
1. Access tables in consistent order
2. Keep transactions short
3. Implement retry logic
4. Use NOWAIT or SKIP LOCKED when appropriate
---
**See SKILL.md for complete integration guidance**

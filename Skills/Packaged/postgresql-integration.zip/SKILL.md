---
name: postgresql-integration
description: Guide developers through PostgreSQL setup, connection configuration, query patterns, and best practices
version: "0.53.1"
license: Complete terms in LICENSE.txt
---
# PostgreSQL Integration
## When to Use
- Setting up PostgreSQL connection in a new project
- Implementing database queries and operations
- Configuring connection pooling (pgbouncer, etc.)
- Handling transactions
- Troubleshooting common PostgreSQL issues
- Using ORMs with PostgreSQL (Sequelize, Prisma)
## Prerequisites
- PostgreSQL server installed and running
- Database credentials available
- Appropriate client library for your language
## Connection Setup
### Connection String Format
```
postgresql://[user[:password]@][host][:port][/dbname][?param1=value1&...]
```
### Security Best Practices
**NEVER hardcode credentials in source code.**
1. Environment variables
2. Configuration files (not committed to version control)
3. Secret management services

```
DATABASE_URL=postgresql://user:password@localhost:5432/mydb
```
### SSL/TLS Configuration
| Mode | Description |
|------|-------------|
| `disable` | No SSL |
| `allow` | Try SSL, fall back to non-SSL |
| `prefer` | Try SSL first (default) |
| `require` | Require SSL, no verification |
| `verify-ca` | Require SSL with CA verification |
| `verify-full` | Require SSL with full verification |
## Query Patterns
### Parameterized Queries
**ALWAYS use parameterized queries to prevent SQL injection.**
```sql
-- CORRECT - Parameterized
SELECT * FROM users WHERE id = $1

-- WRONG - String interpolation (vulnerable)
SELECT * FROM users WHERE id = {user_id}
```
### Common Operations
```sql
-- SELECT with filtering
SELECT column1, column2 FROM table_name
WHERE condition ORDER BY column1 LIMIT 100;

-- INSERT with returning
INSERT INTO table_name (column1, column2)
VALUES ($1, $2) RETURNING id;

-- UPDATE with conditions
UPDATE table_name SET column1 = $1, updated_at = NOW()
WHERE id = $2 RETURNING *;

-- DELETE with confirmation
DELETE FROM table_name WHERE id = $1 RETURNING id;

-- Batch insert
INSERT INTO table_name (column1, column2)
VALUES ($1, $2), ($3, $4), ($5, $6);

-- Large dataset: use COPY
COPY table_name FROM STDIN WITH (FORMAT csv);
```
## Transaction Handling
```sql
BEGIN;
-- operations
COMMIT;
-- or ROLLBACK; if error
```
### Isolation Levels

| Level | Dirty Read | Non-repeatable Read | Phantom Read |
|-------|------------|---------------------|--------------|
| READ UNCOMMITTED | Possible | Possible | Possible |
| READ COMMITTED | Not possible | Possible | Possible |
| REPEATABLE READ | Not possible | Not possible | Possible |
| SERIALIZABLE | Not possible | Not possible | Not possible |

**PostgreSQL default:** READ COMMITTED
```sql
BEGIN TRANSACTION ISOLATION LEVEL SERIALIZABLE;
```
### Savepoints
```sql
BEGIN;
INSERT INTO table1 ...;
SAVEPOINT my_savepoint;
INSERT INTO table2 ...;  -- might fail
ROLLBACK TO SAVEPOINT my_savepoint;
INSERT INTO table2 ...;  -- retry
COMMIT;
```
### Best Practices
1. **Keep transactions short** - Long transactions block other operations
2. **Handle errors explicitly** - Always have rollback logic
3. **Use appropriate isolation** - Higher isolation = more overhead
4. **Avoid user interaction** - Never wait for user input mid-transaction
## Connection Pooling
### Pool Configuration
- `min_connections` - Minimum connections to maintain
- `max_connections` - Maximum connections allowed
- `connection_timeout` - Time to wait for available connection
- `idle_timeout` - Time before closing idle connection
- `max_lifetime` - Maximum connection lifetime
### Sizing Guidelines
```
max_connections = (core_count * 2) + effective_spindle_count
# SSD-based: max_connections = core_count * 2
```
- Monitor connection usage in production
- Adjust based on actual load patterns
- Account for all application instances
### Pool Health Monitoring
Monitor: active connections, idle connections, wait time, connection errors, pool exhaustion events.
## Error Handling
**Connection:** `ECONNREFUSED` (server not running), `ETIMEDOUT` (network/firewall), `authentication failed` (wrong credentials)
**Query:** `syntax error`, `relation does not exist`, `column does not exist`, `duplicate key`, `foreign key violation`
### Error Handling Pattern
```
try:
    execute query
catch connection_error:
    retry with backoff
catch constraint_violation:
    handle business logic
catch syntax_error:
    log and fix query
finally:
    return connection to pool
```
### Retry Strategy
1. Wait with exponential backoff
2. Maximum retry count (e.g., 3 attempts)
3. Log each retry attempt
4. Fail after max retries
## Performance Tips
### Indexing
```sql
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_orders_user_date ON orders(user_id, created_at);
```
### Query Analysis
```sql
EXPLAIN ANALYZE SELECT * FROM users WHERE email = 'test@example.com';
```
Look for: sequential scans on large tables, high cost estimates, actual vs estimated row counts.
## Resources
- `resources/setup-guide.md` - Detailed setup instructions
- `resources/query-patterns.md` - Additional query examples
- `resources/common-errors.md` - Error troubleshooting guide
## Related Skills
- `sqlite-integration` - Lighter-weight alternative for simpler needs
- `migration-patterns` - Schema versioning and changes
---
**End of PostgreSQL Integration Skill**

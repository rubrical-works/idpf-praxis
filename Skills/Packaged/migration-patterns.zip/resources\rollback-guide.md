# Rollback Guide
**Version:** 0.52.0
## Rollback Philosophy
**Forward-Only (Production Recommended):** Never delete data, fix with new migrations, maintains audit trail.
**Reversible (Development/Staging):** Each migration has up/down, can return to any state, more complex testing.
## Writing Rollback Scripts
### Safe Rollback Template
```sql
-- Rollback: [migration_name]
-- Original: [up_migration_file]
-- WARNING: [any data loss warnings]
DO $$
BEGIN
    -- Verify rollback is safe
END $$;
-- Rollback operations
-- Post-rollback verification
```
### Common Rollback Patterns
**Drop table (only if empty):**
```sql
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM table_name LIMIT 1) THEN
        RAISE EXCEPTION 'Cannot drop table_name: contains data';
    END IF;
END $$;
DROP TABLE table_name;
```
**Remove column (preserve data):**
```sql
CREATE TABLE column_backup AS SELECT id, column_name FROM table_name;
ALTER TABLE table_name DROP COLUMN column_name;
```
**Remove index/constraint:**
```sql
DROP INDEX IF EXISTS index_name;
ALTER TABLE table_name DROP CONSTRAINT IF EXISTS constraint_name;
```
## Rollback Testing
1. Apply migration (up)
2. Verify schema
3. Apply rollback (down)
4. Verify restored
5. Re-apply migration (up)
6. Final verification
### Verification Queries
```sql
-- Table exists
SELECT EXISTS (SELECT FROM information_schema.tables WHERE table_name = 'table_name');
-- Column exists
SELECT EXISTS (SELECT FROM information_schema.columns WHERE table_name = 'table_name' AND column_name = 'column_name');
-- Index exists
SELECT EXISTS (SELECT FROM pg_indexes WHERE indexname = 'index_name');
-- Constraint exists
SELECT EXISTS (SELECT FROM pg_constraint WHERE conname = 'constraint_name');
```
## Rollback Scenarios
| Scenario | Solution |
|----------|----------|
| Migration failed mid-way | Identify applied changes, manually reverse, fix script, re-run |
| Data corruption detected | Stop traffic, restore from backup, fix script, re-run |
| Performance degradation | Create fix migration (don't rollback), apply fix, monitor |
| Application incompatibility | Rollback app deploy, rollback migration if safe, fix code, re-deploy together |
## Production Rollback Checklist
### Before
- [ ] Confirm rollback is necessary
- [ ] Backup current database state
- [ ] Notify team
- [ ] Stop application traffic if needed
### During
- [ ] Execute rollback script
- [ ] Monitor for errors
- [ ] Check database consistency
### After
- [ ] Verify application functionality
- [ ] Run integration tests
- [ ] Resume traffic
- [ ] Document what happened
- [ ] Plan fix for next attempt
## Rollback Limitations
**Cannot rollback:** `DROP TABLE`/`DELETE`/`TRUNCATE`, data type narrowing, precision loss.
**Mitigation:** Never destroy data in migrations, test with production-like data, backup before migration, use expand-contract pattern.
---
**See SKILL.md for complete migration guidance**

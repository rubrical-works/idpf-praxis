# Schema Versioning Strategies
**Version:** 0.52.0
## Strategy Comparison
| Strategy | Team Size | Merge Conflicts | Tooling Support |
|----------|-----------|-----------------|-----------------|
| Sequential | Solo/Small | High | Universal |
| Timestamp | Medium/Large | Low | Most tools |
| Hybrid | Enterprise | Low | Some tools |
| Hash-based | Any | None | Limited |
## Sequential Numbering
```
001_initial_schema.sql
002_add_users.sql
```
```bash
LAST=$(ls migrations/*.sql | tail -1 | grep -o '[0-9]*' | head -1)
NEXT=$(printf "%03d" $((LAST + 1)))
touch "migrations/${NEXT}_description.sql"
```
**Use for:** Solo projects, small teams, infrequent migrations.
**Conflict resolution:** Identify first-merged, renumber conflicting, test in sequence.
## Timestamp-Based
```
20240115120000_initial_schema.sql
20240115143022_add_users.sql
```
```bash
TIMESTAMP=$(date +%Y%m%d%H%M%S)
touch "migrations/${TIMESTAMP}_description.sql"
```
**Use for:** Team projects, CI/CD, frequent migrations, distributed teams.
**Format options:** Full `YYYYMMDDHHmmss`, date-only `YYYYMMDD`, date+seq `YYYYMMDD_N`.
## Hybrid Approach
```
V1.0.0__initial_schema.sql
V1.1.0__add_orders.sql
V2.0.0__major_refactor.sql
```
**Rules:** MAJOR = breaking changes, MINOR = new tables, PATCH = fixes/indexes.
**Use for:** Enterprise, formal release cycles, compliance requirements.
## Hash-Based
```
a1b2c3d4_initial_schema.sql
```
Pros: No conflicts, content integrity. Cons: Hard to understand order, limited tool support.
## Dependency-Based
```yaml
id: add_orders
depends_on: [add_users, add_products]
sql_file: add_orders.sql
```
Requires custom tooling, topological sort, circular dependency detection.
## Migration Tracking Table
```sql
CREATE TABLE schema_migrations (
    id SERIAL PRIMARY KEY,
    version VARCHAR(255) NOT NULL UNIQUE,
    applied_at TIMESTAMP DEFAULT NOW(),
    checksum VARCHAR(64),
    execution_time_ms INTEGER
);
```
## Decision Matrix
| Factor | Sequential | Timestamp | Hybrid |
|--------|------------|-----------|--------|
| Team size 1-2 | Best | Good | Overkill |
| Team size 3-10 | Poor | Best | Good |
| Team size 10+ | Poor | Good | Best |
| CI/CD pipeline | Good | Best | Best |
| Compliance needs | Poor | Good | Best |
| Simplicity | Best | Good | Poor |
---
**See SKILL.md for complete migration guidance**

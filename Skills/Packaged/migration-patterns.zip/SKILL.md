---
name: migration-patterns
description: Guide developers through database migration best practices including versioning, rollbacks, and zero-downtime strategies
version: "0.52.0"
license: Complete terms in LICENSE.txt
---
# Migration Patterns
## When to Use
- Planning database schema changes
- Setting up migration workflow for a new project
- Implementing rollback procedures
- Performing migrations in production
- Dealing with large table migrations
## Prerequisites
- Database server running
- Migration tool installed
- Version control for migration files
- Understanding of current schema
## Schema Versioning Strategies
### Sequential Numbering
```
001_create_users_table.sql
002_add_email_to_users.sql
```
Pros: Simple, clear ordering. Cons: Merge conflicts in teams.
### Timestamp-Based
```
20240115120000_create_users_table.sql
20240115143022_add_email_to_users.sql
```
Pros: Reduces merge conflicts, supports team dev. Cons: Longer filenames.
**When to use:** Solo -> Sequential. Team -> Timestamp. Enterprise -> Hybrid with release versions.
See `resources/versioning-strategies.md` for detailed comparison.
## Migration File Structure
```
migrations/
├── 001_create_users/
│   ├── up.sql
│   └── down.sql
└── 002_add_indexes/
    ├── up.sql
    └── down.sql
```
**Up migration:**
```sql
CREATE TABLE users (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) NOT NULL UNIQUE,
    created_at TIMESTAMP DEFAULT NOW()
);
CREATE INDEX idx_users_email ON users(email);
```
**Down migration:**
```sql
DROP INDEX IF EXISTS idx_users_email;
DROP TABLE IF EXISTS users;
```
## Rollback Procedures
- **Forward-only (production recommended):** Fix issues with new migrations, maintains audit trail
- **Reversible:** Provide down migration for each up, allows rollback to any state
### Safe Rollback Pattern
```sql
DO $$
BEGIN
    IF EXISTS (SELECT 1 FROM users LIMIT 1) THEN
        RAISE EXCEPTION 'Cannot rollback: users table has data';
    END IF;
END $$;
DROP TABLE users;
```
### Data-Preserving Rollback
```sql
ALTER TABLE users RENAME TO users_backup_20240115;
CREATE VIEW users AS SELECT * FROM users_backup_20240115;
```
### Rollback Testing
1. Run up migration -> 2. Verify schema -> 3. Run down -> 4. Verify restored -> 5. Re-run up -> 6. Verify final
See `resources/rollback-guide.md` for comprehensive procedures.
## Zero-Downtime Migrations
### Expand-Contract Pattern
**Phase 1: Expand** - Add new column/table, keep old working
**Phase 2: Migrate** - Copy/transform data (batch if large)
**Phase 3: Contract** - Remove old column/table, clean up
### Example: Renaming a Column
**Phase 1:**
```sql
ALTER TABLE users ADD COLUMN full_name VARCHAR(255);
UPDATE users SET full_name = name;
```
**Phase 2 - Sync trigger:**
```sql
CREATE OR REPLACE FUNCTION sync_name_columns()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.name IS DISTINCT FROM OLD.name THEN
        NEW.full_name = NEW.name;
    ELSIF NEW.full_name IS DISTINCT FROM OLD.full_name THEN
        NEW.name = NEW.full_name;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER trg_sync_name BEFORE INSERT OR UPDATE ON users
FOR EACH ROW EXECUTE FUNCTION sync_name_columns();
```
**Phase 3:**
```sql
DROP TRIGGER trg_sync_name ON users;
DROP FUNCTION sync_name_columns();
ALTER TABLE users DROP COLUMN name;
```
### Adding NOT NULL (zero-downtime)
```sql
-- Step 1: Add check constraint (not validated)
ALTER TABLE users ADD CONSTRAINT users_email_not_null CHECK (email IS NOT NULL) NOT VALID;
-- Step 2: Validate (allows reads)
ALTER TABLE users VALIDATE CONSTRAINT users_email_not_null;
-- Step 3: Convert (instant)
ALTER TABLE users ALTER COLUMN email SET NOT NULL;
ALTER TABLE users DROP CONSTRAINT users_email_not_null;
```
### Adding Index Without Locking
```sql
CREATE INDEX CONCURRENTLY idx_users_email ON users(email);
```
**Note:** Cannot run in a transaction, takes longer.
See `resources/zero-downtime.md` for more patterns.
## Migration Execution
### Pre-Migration Checklist
- [ ] Tested in staging
- [ ] Rollback tested
- [ ] Backup taken
- [ ] Team notified
- [ ] Monitoring in place
### Execution Order
1. Backup -> 2. Run in staging -> 3. Verify -> 4. Run in production -> 5. Verify -> 6. Update docs
### Post-Migration Verification
```sql
\d table_name
SELECT COUNT(*) FROM table_name;
SELECT indexname FROM pg_indexes WHERE tablename = 'table_name';
SELECT conname FROM pg_constraint WHERE conrelid = 'table_name'::regclass;
```
## ORM-Agnostic Guidance
| Action | Raw SQL | ORM Equivalent |
|--------|---------|----------------|
| Create table | CREATE TABLE | create_table |
| Add column | ALTER TABLE ADD | add_column |
| Add index | CREATE INDEX | add_index |
| Remove column | ALTER TABLE DROP | remove_column |
**Tips:** Review generated SQL. Use raw SQL for complex migrations. Keep reversible. Test with production-like data.
## Resources
See `resources/` for:
- `versioning-strategies.md` - Detailed versioning comparison
- `rollback-guide.md` - Comprehensive rollback procedures
- `zero-downtime.md` - Zero-downtime migration patterns
## Relationship to Other Skills
**Complements:** `postgresql-integration`, `sqlite-integration`
## Expected Outcome
- Migration workflow established
- Versioning strategy chosen
- Rollback procedures defined and tested
- Zero-downtime patterns understood
- Migration files organized
---
**End of Migration Patterns Skill**

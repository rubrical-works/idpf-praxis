# Zero-Downtime Migration Patterns
**Version:** {{VERSION}}
**Core Principle:** Never make a change that breaks the current application version. Each migration must be compatible with both current and new application versions.
## Expand-Contract Pattern
```
Phase 1: EXPAND (Add)    -> New structure added, old still works
Phase 2: MIGRATE         -> Data moved/transformed
Phase 3: CONTRACT (Remove) -> Old structure removed
```
### Example: Splitting a Column
**Phase 1 - Expand:**
```sql
ALTER TABLE users ADD COLUMN first_name VARCHAR(100);
ALTER TABLE users ADD COLUMN last_name VARCHAR(100);
UPDATE users SET
    first_name = SPLIT_PART(full_name, ' ', 1),
    last_name = SPLIT_PART(full_name, ' ', 2);
```
**Phase 2 - Sync Trigger:**
```sql
CREATE OR REPLACE FUNCTION sync_name_split()
RETURNS TRIGGER AS $$
BEGIN
    IF NEW.full_name IS DISTINCT FROM OLD.full_name THEN
        NEW.first_name = SPLIT_PART(NEW.full_name, ' ', 1);
        NEW.last_name = SPLIT_PART(NEW.full_name, ' ', 2);
    ELSIF NEW.first_name IS DISTINCT FROM OLD.first_name
       OR NEW.last_name IS DISTINCT FROM OLD.last_name THEN
        NEW.full_name = NEW.first_name || ' ' || NEW.last_name;
    END IF;
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;
CREATE TRIGGER sync_names BEFORE UPDATE ON users
FOR EACH ROW EXECUTE FUNCTION sync_name_split();
```
**Phase 3 - Contract:**
```sql
DROP TRIGGER sync_names ON users;
DROP FUNCTION sync_name_split();
ALTER TABLE users DROP COLUMN full_name;
```
## Adding Non-Nullable Column (Zero-Downtime)
1. **Add nullable:** `ALTER TABLE users ADD COLUMN status VARCHAR(20);`
2. **Backfill in batches:**
```sql
DO $$
DECLARE batch_size INT := 10000; max_id INT; current_id INT := 0;
BEGIN
    SELECT MAX(id) INTO max_id FROM users;
    WHILE current_id < max_id LOOP
        UPDATE users SET status = 'active'
        WHERE id > current_id AND id <= current_id + batch_size AND status IS NULL;
        current_id := current_id + batch_size;
        PERFORM pg_sleep(0.1);
    END LOOP;
END $$;
```
3. **Add constraint (NOT VALID, then validate):**
```sql
ALTER TABLE users ADD CONSTRAINT users_status_not_null CHECK (status IS NOT NULL) NOT VALID;
ALTER TABLE users VALIDATE CONSTRAINT users_status_not_null;
```
4. **Convert:** `ALTER TABLE users ALTER COLUMN status SET NOT NULL;` then drop constraint.
## Adding Constraints (Zero-Downtime)
**Foreign Key:**
```sql
ALTER TABLE orders ADD CONSTRAINT fk_user FOREIGN KEY (user_id) REFERENCES users(id) NOT VALID;
ALTER TABLE orders VALIDATE CONSTRAINT fk_user;
```
**Check Constraint:** Same pattern -- `NOT VALID` first, then `VALIDATE` separately.
## Online Index Creation
```sql
CREATE INDEX CONCURRENTLY idx_users_email ON users(email);
```
Cannot run in transaction. Check for invalid indexes: `SELECT indexrelid::regclass FROM pg_index WHERE NOT indisvalid;`
## Monitoring During Migration
### Watch for Locks
```sql
SELECT pid, usename, query_start, state, wait_event_type, query
FROM pg_stat_activity WHERE state != 'idle' AND pid != pg_backend_pid()
ORDER BY query_start;
```
### Check Table Bloat
```sql
SELECT tablename, pg_size_pretty(pg_total_relation_size(schemaname||'.'||tablename)) AS total_size
FROM pg_tables WHERE schemaname = 'public'
ORDER BY pg_total_relation_size(schemaname||'.'||tablename) DESC LIMIT 10;
```
## Checklist
### Before
- [ ] Tested in staging with production-like data
- [ ] Rollback plan documented
- [ ] Monitoring ready
- [ ] Team notified
### During
- [ ] Watch for lock contention
- [ ] Monitor replication lag
- [ ] Check application errors
- [ ] Verify data integrity
### After
- [ ] All phases complete
- [ ] Temporary objects cleaned up
- [ ] Documentation updated
- [ ] Monitor for 24 hours
---
**See SKILL.md for complete migration guidance**

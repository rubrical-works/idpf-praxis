---
name: sinatra-setup-for-beginners
description: Set up Ruby Sinatra development environment for beginners with step-by-step guidance, Bundler setup, and troubleshooting
version: "0.53.1"
license: Complete terms in LICENSE.txt
---
# Sinatra Setup for Beginners
## When to Use
- User wants to build a Sinatra web application
- User is a beginner and needs Sinatra environment setup
- User asks "How do I set up Sinatra?" or "How do I start a Sinatra project?"
- Building a Ruby web API or Ruby web server
- Sinatra tutorial or learning resources needed
## Instructions for ASSISTANT
**CRITICAL OUTPUT FORMAT:**
Format ALL technical instructions as **Claude Code copy/paste blocks**.
**DO NOT provide manual instructions** (no "Open File Explorer", "Navigate to folder", "Right-click").
**ALWAYS format as:**
```
TASK: Set up Sinatra project
STEP 1: Copy this entire code block
STEP 2: Open Claude Code
STEP 3: Paste into Claude Code
STEP 4: Claude Code will execute and report results
STEP 5: Report back: What did Claude Code say?
---
[Instructions for Claude Code to execute:]
Navigate to project directory:
cd [project-location]
Create project folder:
mkdir [project-name]
cd [project-name]
Verify Ruby installed:
ruby --version
[continue with commands...]
Report:
- What results did you see?
```
## Setup Knowledge
### STEP 1: Create Project and Verify Ruby
```bash
ruby --version
```
**Expected:** `ruby 3.0.0` or higher

**If Ruby is NOT installed:**
- **Windows:** Download RubyInstaller from https://rubyinstaller.org/ - Choose "Ruby+Devkit 3.2.X", check "Add Ruby to PATH"
- **Mac:** `brew install ruby` or use rbenv
- **Linux:** `sudo apt-get update && sudo apt-get install ruby-full`
### STEP 4: Install Bundler
```bash
gem install bundler
```
**Success:** "Successfully installed bundler-X.X.X"
**Verify:** `bundler --version` -> `Bundler version 2.X.X`
**Issues:** "Permission denied" -> `sudo gem install bundler` (Mac/Linux)
### STEP 5: Create Gemfile
Create `Gemfile` (no extension, capital G) in project root:
```ruby
source 'https://rubygems.org'

gem 'sinatra'
```
### STEP 6: Install Sinatra and Dependencies
```bash
bundle install
```
Creates `Gemfile.lock`. Wait 30-90 seconds.
**Issues:**
- "Could not locate Gemfile" -> Check you're in project directory
- "Permission denied" -> `bundle install --path vendor/bundle`
### STEP 7: Create app.rb File
Create `app.rb` in project folder.
**Project structure after setup:**
```
my-project/
├── Gemfile
├── Gemfile.lock
└── app.rb
```
### STEP 8: Verify Installation
```bash
ruby --version            # 3.0.0+
bundle --version          # 2.X.X
bundle list               # Should include sinatra
ruby -e "require 'sinatra'; puts 'Sinatra works!'"
```
## Troubleshooting Quick Reference
See `resources/verification-checklist.md` for detailed troubleshooting.
1. **Ruby not installed** -> Follow Step 1 installation instructions
2. **Gemfile in wrong location** -> Must be in project root
3. **Permission errors** -> `bundle install --path vendor/bundle`
4. **Network/firewall issues** -> Check internet connection
5. **Old Ruby version** -> Update Ruby to 3.0+
## Project Structure (Later)
```
my-project/
├── Gemfile
├── Gemfile.lock
├── app.rb
├── views/            <- Templates (.erb files)
│   └── index.erb
└── public/           <- Static files (CSS, images, JS)
    └── style.css
```
---
**Remember:** Run `bundle exec ruby app.rb` to start your Sinatra app

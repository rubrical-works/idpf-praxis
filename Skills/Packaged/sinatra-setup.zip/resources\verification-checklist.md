# Sinatra Setup Verification Checklist
**Version:** 0.52.0
## Visual Verification
### 1. Project Folder Structure
```
my-project/
├── Gemfile        You created this
├── Gemfile.lock   Bundle created this
└── app.rb         You created this
```
### 2. Gemfile Contents
```ruby
source 'https://rubygems.org'

gem 'sinatra'
```
Must have `source` line, `gem 'sinatra'` line, file named exactly "Gemfile" (no extension).
### 3. Ruby Version Check
```bash
ruby --version     # Expected: 3.0.0+
bundle --version   # Expected: 2.0.0+
```
## Command-by-Command Verification
### Test 1: Ruby Installed
```bash
which ruby    # Mac/Linux
where ruby    # Windows
```
### Test 2: Sinatra Gem Installed
```bash
bundle list | grep sinatra    # Mac/Linux
bundle list | findstr sinatra # Windows
```
**Expected:** `* sinatra (X.X.X)` - If not listed, run `bundle install`
### Test 3: Sinatra Loadable
```bash
ruby -e "require 'sinatra'; puts Sinatra::VERSION"
```
### Test 4: All Gems Installed
```bash
bundle check
```
**Expected:** `The Gemfile's dependencies are satisfied`
## Common Problems and Solutions
### "ruby: command not found"
- **Windows:** Install from https://rubyinstaller.org/, check "Add Ruby to PATH"
- **Mac:** `brew install ruby`
- **Linux:** `sudo apt-get update && sudo apt-get install ruby-full`
### "Could not locate Gemfile"
Check current directory (`pwd`), navigate to project, verify Gemfile exists.
### "Permission denied" during bundle install
**Best:** `bundle install --path vendor/bundle`
**Long-term:** Use rbenv or rvm for Ruby version management.
### Gemfile.lock shows old versions
```bash
rm Gemfile.lock
bundle install
```
### "LoadError: cannot load such file -- sinatra"
```bash
bundle list | grep sinatra   # Verify installed
bundle install               # If not installed
bundle exec ruby app.rb      # Run with bundler
```
### Network/download errors
1. Check internet: browse to https://rubygems.org
2. Configure proxy: `bundle config set http_proxy http://proxy.company.com:port`
3. Try `bundle install --local`
### Old Ruby version (< 3.0)
- **Mac:** `brew install ruby`
- **Windows:** Download latest from rubyinstaller.org
- **Linux:** `rbenv install 3.2.2 && rbenv global 3.2.2`
## Final Verification Checklist
- [ ] `ruby --version` shows 3.0+
- [ ] `bundle --version` shows 2.0+
- [ ] `bundle list` shows sinatra
- [ ] `bundle check` says dependencies satisfied
- [ ] Gemfile exists in project root
- [ ] Gemfile.lock exists
- [ ] app.rb exists in project root
## Quick Start Test
```ruby
# test.rb
require 'sinatra'
get '/' do
  'Sinatra works!'
end
```
```bash
ruby test.rb
```
Open http://localhost:4567 - should see "Sinatra works!"
Stop with Ctrl+C.
## Gemfile Best Practices
```ruby
source 'https://rubygems.org'
gem 'sinatra'
gem 'sinatra-contrib'        # Optional: helpful utilities
gem 'sinatra', '~> 3.0'     # Version pinning
```
After adding gems: `bundle install`. To update: `bundle update`.

---
name: render-project-setup
description: Configure automated preview, staging, and production deployments with Render
version: "0.55.0"
license: Complete terms in LICENSE.txt
---
**Purpose:** Guide developers through setting up Render deployments with GitHub integration
**Audience:** Developers deploying web applications, APIs, and static sites to Render
**Related Skills:** `ci-cd-pipeline-design` -- for broader CI/CD pipeline architecture
## Initial Setup
**Prerequisites:**
- Render account (free tier available)
- GitHub repository connected to Render
- Render CLI (optional): `npm install -g @render-cli/cli`
**Connecting GitHub:**
1. Sign in at https://render.com with GitHub account
2. Grant repository access in Dashboard > Account > GitHub
3. Create new service: Dashboard > New > Web Service
4. Select repository and branch
**Blueprint (Infrastructure as Code):**
```yaml
services:
  - type: web
    name: my-app
    runtime: node
    buildCommand: npm install && npm run build
    startCommand: npm start
```
## Environment Configuration
Configure in Dashboard (Service > Environment tab) or via `render.yaml`:
| Variable | Scope | Description |
|----------|-------|-------------|
| `RENDER_API_KEY` | GitHub Actions | API key for deploy triggers |
| `DATABASE_URL` | Service | Database connection (auto-set for Render databases) |
| `PORT` | Auto-injected | Default: 10000 |
**Environment Groups:**
1. Dashboard > Environment Groups > New
2. Add shared variables
3. Reference in `render.yaml`: `envVarGroups: [{ name: shared-config }]`
See `resources/env-setup.md` for complete guide.
## GitHub Integration
**Auto-Deploy on Push:** Render auto-deploys on configured branch. Enable in Service > Settings > Build & Deploy.
**Preview Environments:**
1. Service > Settings > Preview Environments > Enable
2. Each PR gets unique URL: `https://my-app-pr-{number}.onrender.com`
3. Same build/start commands as production
4. Destroyed when PR is closed
**GitHub Actions Deployment:**
```yaml
- name: Trigger Render Deploy
  run: |
    curl -X POST "https://api.render.com/v1/services/${{ vars.RENDER_SERVICE_ID }}/deploys"
      -H "Authorization: Bearer ${{ secrets.RENDER_API_KEY }}"
```
## Deployment Strategies
**Production:** Auto-deploys from configured branch (`main` -> Production).
**Staging:** Create second service pointing to staging branch (e.g., `develop`).
**Blue-Green Deployments:** Render performs zero-downtime by default -- new version built alongside running version, health check passes, traffic switches, old version terminated.
**Rollback:** Service > Deploys > select previous deploy > Rollback. Or via API.
## Monitoring and Debugging
**Logs:** Dashboard (Service > Logs) or API. Build logs and runtime logs with filtering.
**Metrics:** CPU/memory usage, HTTP request rate/latency, bandwidth.
**Health Checks:**
```yaml
services:
  - type: web
    healthCheckPath: /api/health
```
Render checks health endpoint after deployment and rolls back on failure.
## Common Pitfalls
**Build Issues:**
- **Build timeout**: Default 30 minutes. Optimize build steps or use caching
- **Node.js version**: Set in `engines` in `package.json` or `RENDER_NODE_VERSION` env var
- **Missing native deps**: Use `preDeployCommand` in `render.yaml`
**Deployment Issues:**
- **Port binding**: Expects port 10000 or `PORT` env var. Use `process.env.PORT`
- **Cold starts (free tier)**: Spin down after 15 min inactivity. Upgrade for always-on
- **Static site routing**: For SPAs, set rewrite rules to `index.html`
**Preview Environment Issues:**
- Share production database by default -- use separate databases
- Env vars inherit from main service; override in preview settings
- Each preview is separate instance (cost awareness)
## Resources
- `resources/render.yaml` -- Reference blueprint configuration
- `resources/deploy.yml` -- GitHub Actions workflow
- `resources/env-setup.md` -- Environment variable setup guide

# Render Environment Variable Setup
## Required GitHub Repository Secrets
**RENDER_API_KEY:**
1. Go to https://dashboard.render.com/u/settings
2. Scroll to "API Keys" > "Create API Key"
3. Copy key immediately
**Add to GitHub:** Repository > Settings > Secrets and variables > Actions > New repository secret
## GitHub Actions Variables (non-secret)
Set in Repository > Settings > Secrets and variables > Actions > Variables tab:
| Variable | Description | Example |
|----------|-------------|---------|
| `RENDER_SERVICE_ID` | Service ID for deployment API calls | `srv-xxxxxxxxxxxx` |
| `RENDER_PRODUCTION_URL` | Production URL for health checks | `https://my-app.onrender.com` |
## Render Service Variables
Set in Dashboard (Service > Environment tab):
| Variable | Scope | Description |
|----------|-------|-------------|
| `DATABASE_URL` | Auto-injected | Database connection (for Render databases) |
| `PORT` | Auto-injected | Default: 10000 |
| `RENDER` | Auto-injected | Set to `true` in Render environments |
| `RENDER_EXTERNAL_URL` | Auto-injected | Public URL of the service |
| `IS_PULL_REQUEST` | Preview only | Set to `true` in preview environments |
## Tips
- Use Environment Groups for variables shared across services
- Render auto-restarts services when env vars change
- Preview environments inherit from parent service
- Use `render.yaml` `envVars` for IaC variable management
- Secret files (certificates, keys) stored as Render secret files, not env vars

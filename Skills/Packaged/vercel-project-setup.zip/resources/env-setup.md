# Vercel Environment Variable Setup
## Required GitHub Repository Secrets
**1. VERCEL_TOKEN:**
1. Go to https://vercel.com/account/tokens
2. Click "Create" -- name it, set scope
3. Copy token immediately (shown only once)
**Add to GitHub:** Repository > Settings > Secrets and variables > Actions > New repository secret
**2. VERCEL_ORG_ID** and **3. VERCEL_PROJECT_ID:**
From `.vercel/project.json` after running `vercel link`:
```json
{
  "orgId": "team_xxxxxxxxxxxx",
  "projectId": "prj_xxxxxxxxxxxx"
}
```
## Environment-Specific Variables
Set in Vercel Dashboard (Project > Settings > Environment Variables):
| Variable | Production | Preview | Development | Description |
|----------|:----------:|:-------:|:-----------:|-------------|
| `DATABASE_URL` | Yes | Yes | Yes | Database connection string |
| `API_KEY` | Yes | Yes | No | External API key |
| `NEXT_PUBLIC_API_URL` | Yes | Yes | Yes | Public API endpoint |
| `SENTRY_DSN` | Yes | Yes | No | Error tracking |
## Tips
- Use different database instances for production vs preview
- Prefix client-side variables: `NEXT_PUBLIC_` (Next.js) or `VITE_` (Vite)
- Preview env vars apply to all PR deployments
- Sync variables locally: `vercel env pull .env.local`

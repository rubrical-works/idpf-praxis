---
name: vercel-project-setup
description: Configure automated preview, staging, and production deployments with Vercel
version: "0.55.0"
license: Complete terms in LICENSE.txt
---
**Purpose:** Guide developers through setting up Vercel deployments with GitHub Actions integration
**Audience:** Developers deploying web applications to Vercel
**Related Skills:** `ci-cd-pipeline-design` -- for broader CI/CD pipeline architecture
## Initial Setup
**Prerequisites:**
- Vercel account (free tier available)
- Vercel CLI: `npm install -g vercel`
- GitHub repository with push access
```bash
vercel login
vercel link    # Link existing project
vercel         # Or create new project
```
Creates `.vercel/` directory with `project.json` containing org and project IDs.
## Environment Configuration
**Required Secrets** (GitHub > Settings > Secrets and variables > Actions):
| Secret | Source | Description |
|--------|--------|-------------|
| `VERCEL_TOKEN` | Vercel Dashboard > Settings > Tokens | API authentication token |
| `VERCEL_ORG_ID` | `.vercel/project.json` -> `orgId` | Organization ID |
| `VERCEL_PROJECT_ID` | `.vercel/project.json` -> `projectId` | Project ID |
**Environment Variables** (Project > Settings > Environment Variables):
- **Production**: Production deployments only
- **Preview**: Preview/PR deployments
- **Development**: During `vercel dev`
See `resources/env-setup.md` for complete guide.
## GitHub Integration
**Preview Deployments:**
```yaml
on:
  pull_request:
    types: [opened, synchronize]
steps:
  - uses: amondnet/vercel-action@v25
    with:
      vercel-token: ${{ secrets.VERCEL_TOKEN }}
      vercel-org-id: ${{ secrets.VERCEL_ORG_ID }}
      vercel-project-id: ${{ secrets.VERCEL_PROJECT_ID }}
```
Preview URL automatically commented on PR.
**Production Deployments:**
```yaml
on:
  push:
    branches: [main]
steps:
  - uses: amondnet/vercel-action@v25
    with:
      vercel-token: ${{ secrets.VERCEL_TOKEN }}
      vercel-args: '--prod'
```
## Custom Configuration
**vercel.json** -- build settings, routes, headers, redirects:
```json
{
  "buildCommand": "npm run build",
  "outputDirectory": "dist",
  "framework": "nextjs",
  "routes": [
    { "src": "/api/(.*)", "dest": "/api/$1" }
  ]
}
```
Key areas: build settings, URL rewrites/redirects, serverless function config, scheduled crons.
## Deployment Strategies
**Preview per PR:** URL pattern: `https://{project}-{hash}-{scope}.vercel.app`
**Staging:** Deploy to staging on develop branch push.
**Production with Approval:** Use GitHub environment protection rules.
**Instant Rollback:**
```bash
vercel ls
vercel rollback [deployment-url]
```
## Monitoring and Debugging
```bash
vercel logs [deployment-url]
vercel inspect [deployment-url]
vercel logs [deployment-url] --follow
```
Serverless function logs via Dashboard (Project > Deployments > Functions tab).
**Health Check:**
```yaml
- name: Health Check
  run: |
    DEPLOY_URL="${{ steps.deploy.outputs.preview-url }}"
    STATUS=$(curl -s -o /dev/null -w "%{http_code}" "$DEPLOY_URL/api/health")
    if [ "$STATUS" != "200" ]; then
      echo "Health check failed (status: $STATUS)"
      exit 1
    fi
```
## Common Pitfalls
**Build Failures:**
- **Missing env vars**: Ensure all required vars set in Dashboard for correct environment scope
- **Node.js version mismatch**: Set `engines.node` in `package.json` or configure in project settings
- **Build command not found**: Verify `buildCommand` in `vercel.json` matches `package.json` scripts
**Deployment Issues:**
- **404 on client-side routes**: Add SPA rewrite: `{ "rewrites": [{ "source": "/(.*)", "destination": "/index.html" }] }`
- **API routes not working**: Ensure functions in correct directory (`/api` default)
- **Large deployment**: Use `.vercelignore` to exclude unnecessary files
**CI/CD Issues:**
- **Token expired**: Regenerate in Dashboard > Settings > Tokens
- **Rate limiting**: Use `paths-ignore` to skip documentation changes
- **Concurrent deployments**: Use GitHub concurrency groups to cancel superseded runs
## Resources
- `resources/vercel.json` -- Reference project configuration
- `resources/deploy.yml` -- GitHub Actions workflow
- `resources/env-setup.md` -- Environment variable setup guide

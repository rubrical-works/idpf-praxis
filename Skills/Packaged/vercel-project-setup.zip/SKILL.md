---
name: vercel-project-setup
description: Configure automated preview, staging, and production deployments with Vercel
version: "0.58.0"
license: Complete terms in LICENSE.txt
category: platform
relevantTechStack: [vercel, next, react, node, deployment]
invocationMode: direct-only
---
# Skill: vercel-project-setup
**Purpose:** Guide developers through setting up Vercel deployments with GitHub Actions integration
**Audience:** Developers deploying web applications to Vercel
**Related Skills:** `ci-cd-pipeline-design` — for broader CI/CD pipeline architecture

## Overview
The `vercel-project-setup` skill provides structured guidance for configuring Vercel deployments across preview, staging, and production environments. It covers initial project setup through Vercel CLI, GitHub Actions workflows for automated deployments, environment variable management, and monitoring.

## Initial Setup

### Prerequisites
- Vercel account (free tier available)
- Vercel CLI installed: `npm install -g vercel`
- GitHub repository with push access

### Linking Your Project
```bash
# Login to Vercel
vercel login

# Link existing project (run from project root)
vercel link

# Or create a new project
vercel
```
This creates a `.vercel/` directory with `project.json` containing your org and project IDs.

## Environment Configuration

### Required Secrets
Configure these in your GitHub repository settings (Settings > Secrets and variables > Actions):
| Secret | Source | Description |
|--------|--------|-------------|
| `VERCEL_TOKEN` | Vercel Dashboard > Settings > Tokens | API authentication token |
| `VERCEL_ORG_ID` | `.vercel/project.json` → `orgId` | Your Vercel organization ID |
| `VERCEL_PROJECT_ID` | `.vercel/project.json` → `projectId` | Your Vercel project ID |

### Environment Variables
Set environment-specific variables in the Vercel Dashboard (Project > Settings > Environment Variables):
- **Production**: Variables available only in production deployments
- **Preview**: Variables available in preview/PR deployments
- **Development**: Variables available during `vercel dev`
See `resources/env-setup.md` for a complete environment variable setup guide.

## GitHub Integration

### Automated Preview Deployments
Preview deployments create a unique URL for every pull request, enabling team review before merging.
```yaml
# See resources/deploy.yml for complete workflow
on:
  pull_request:
    types: [opened, synchronize]

steps:
  - uses: amondnet/vercel-action@v25
    with:
      vercel-token: ${{ secrets.VERCEL_TOKEN }}
      vercel-org-id: ${{ secrets.VERCEL_ORG_ID }}
      vercel-project-id: ${{ secrets.VERCEL_PROJECT_ID }}
```
The preview URL is automatically commented on the PR for easy access.

### Production Deployments
Production deployments are triggered when pushing to the main branch or creating a release tag:
```yaml
on:
  push:
    branches: [main]
    # Or use tags for explicit releases:
    # tags: ['v*']

steps:
  - uses: amondnet/vercel-action@v25
    with:
      vercel-token: ${{ secrets.VERCEL_TOKEN }}
      vercel-args: '--prod'
```

## Custom Configuration

### vercel.json
The `vercel.json` file configures build settings, routes, headers, and redirects. See `resources/vercel.json` for a reference configuration.
Key configuration areas:
- **Build settings**: Framework detection, build command, output directory
- **Routes**: URL rewrites, redirects, custom headers
- **Functions**: Serverless function configuration (runtime, memory, timeout)
- **Crons**: Scheduled serverless function invocation
```json
{
  "buildCommand": "npm run build",
  "outputDirectory": "dist",
  "framework": "nextjs",
  "routes": [
    { "src": "/api/(.*)", "dest": "/api/$1" }
  ]
}
```

## Deployment Strategies

### Preview per PR
Every pull request gets its own deployment. The URL follows the pattern:
`https://{project}-{hash}-{scope}.vercel.app`

### Staging Environment
Use Vercel's environment feature or a dedicated branch:
```yaml
# Deploy to staging on develop branch push
on:
  push:
    branches: [develop]
```

### Production with Approval
Use GitHub environment protection rules for production deployments:
```yaml
jobs:
  deploy:
    environment: production  # Requires approval in GitHub settings
```

### Instant Rollback
Vercel maintains deployment history. Rollback via CLI or dashboard:
```bash
# List recent deployments
vercel ls

# Promote a previous deployment to production
vercel rollback [deployment-url]
```

## Monitoring and Debugging

### Deployment Logs
```bash
# View build logs
vercel logs [deployment-url]

# Inspect deployment details
vercel inspect [deployment-url]
```

### Runtime Logs
Access serverless function logs via the Vercel Dashboard (Project > Deployments > Functions tab) or CLI:
```bash
vercel logs [deployment-url] --follow
```

### Health Checks
After deployment, verify the application responds correctly:
```yaml
- name: Health Check
  run: |
    DEPLOY_URL="${{ steps.deploy.outputs.preview-url }}"
    STATUS=$(curl -s -o /dev/null -w "%{http_code}" "$DEPLOY_URL/api/health")
    if [ "$STATUS" != "200" ]; then
      echo "Health check failed (status: $STATUS)"
      exit 1
    fi
```

## Common Pitfalls and Troubleshooting

### Build Failures
- **Missing environment variables**: Ensure all required env vars are set in Vercel Dashboard for the correct environment scope
- **Node.js version mismatch**: Set `engines.node` in `package.json` or configure in Vercel project settings
- **Build command not found**: Verify `buildCommand` in `vercel.json` matches your `package.json` scripts

### Deployment Issues
- **404 on client-side routes**: Add a rewrite rule for SPA routing:
  ```json
  { "rewrites": [{ "source": "/(.*)", "destination": "/index.html" }] }
  ```
- **API routes not working**: Ensure serverless functions are in the correct directory (`/api` by default)
- **Large deployment size**: Check `.vercelignore` to exclude unnecessary files

### CI/CD Issues
- **Token expired**: Vercel tokens can expire. Regenerate in Dashboard > Settings > Tokens
- **Rate limiting**: Avoid deploying on every commit. Use `paths-ignore` to skip documentation changes
- **Concurrent deployments**: Vercel handles concurrent deployments gracefully, but consider using GitHub's concurrency groups to cancel superseded runs

## Related Skills
- **`ci-cd-pipeline-design`** — Architecture patterns for CI/CD pipelines, stage design, and security considerations

## Resources
- `resources/vercel.json` — Reference Vercel project configuration
- `resources/deploy.yml` — GitHub Actions workflow for preview and production deployments
- `resources/env-setup.md` — Environment variable setup guide

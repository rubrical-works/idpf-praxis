# Cookie Compliance Reference
## Cookie Classification
**The Four Categories:**
| Category | Consent Required | Description | Examples |
|----------|:---------------:|-------------|----------|
| **Strictly Necessary** | No | Essential for site function | Session ID, CSRF token, auth token, consent cookie |
| **Functional** | Yes | Enhanced features; site works without them | Language preference, theme, remembered login |
| **Analytics** | Yes | Usage measurement | Google Analytics `_ga`, Hotjar `_hj*`, page view counters |
| **Marketing** | Yes | Advertising, retargeting, cross-site tracking | `_fbp`, `_gcl_*`, retargeting pixels |
**Classification Decision Tree:**
```
Is the cookie essential for the page to function?
+-- YES -> Strictly Necessary (no consent needed)
+-- NO -> Does it enable a feature the user explicitly requested?
    +-- YES -> Functional (consent required)
    +-- NO -> Does it measure site usage for improvement?
        +-- YES -> Analytics (consent required)
        +-- NO -> Marketing (consent required)
```
**Common Classification Mistakes:**
| Cookie | Often Misclassified As | Actually Is | Why |
|--------|----------------------|-------------|-----|
| `_ga` (Google Analytics) | Necessary | Analytics | Site works without analytics |
| Language preference | Necessary | Functional | Site works with default language |
| "Remember me" login | Necessary | Functional | User can re-login manually |
| Consent cookie itself | Analytics | Necessary | Required to remember consent |
| CSRF token | Functional | Necessary | Security requirement |
| Social media login | Necessary | Functional | Alternative login methods exist |
## Cookie Banner Implementation
**Banner Requirements:**
| Requirement | Details |
|-------------|---------|
| **Timing** | Before any non-essential cookies are set |
| **Reject parity** | "Reject All" as prominent as "Accept All" |
| **Non-blocking** | Must not block page content (no cookie walls under GDPR) |
| **Privacy link** | Must link to privacy/cookie policy |
| **Accessible** | ARIA roles, keyboard navigable, screen reader compatible |
| **Persistent choice** | Remember user's choice (don't re-prompt) |
**HTML Structure:**
```html
<div id="cookie-banner" role="dialog" aria-label="Cookie consent" aria-describedby="cookie-description">
  <p id="cookie-description">
    We use cookies to improve your experience. Strictly necessary cookies
    are always active. <a href="/cookie-policy">Cookie Policy</a>
  </p>
  <div class="cookie-actions">
    <button id="cookie-reject" class="cookie-btn cookie-btn-secondary">Reject All</button>
    <button id="cookie-customize" class="cookie-btn cookie-btn-secondary">Customize</button>
    <button id="cookie-accept" class="cookie-btn cookie-btn-primary">Accept All</button>
  </div>
</div>
```
**JavaScript Implementation:**
```javascript
class CookieBanner {
  constructor() {
    this.banner = document.getElementById('cookie-banner');
    this.bindEvents();
  }
  bindEvents() {
    document.getElementById('cookie-accept')
      .addEventListener('click', () => this.setConsent('all'));
    document.getElementById('cookie-reject')
      .addEventListener('click', () => this.setConsent('none'));
    document.getElementById('cookie-customize')
      .addEventListener('click', () => this.showPreferences());
  }
  setConsent(level) {
    const categories = {
      necessary: true,
      functional: level === 'all',
      analytics: level === 'all',
      marketing: level === 'all'
    };
    this.saveConsent(categories);
    this.enforceConsent(categories);
    this.hideBanner();
  }
  saveConsent(categories) {
    const consent = { version: 1, timestamp: new Date().toISOString(), categories };
    document.cookie =
      `privacy-consent=${encodeURIComponent(JSON.stringify(consent))}` +
      '; path=/; max-age=15552000; secure; samesite=lax';
  }
  enforceConsent(categories) {
    document.dispatchEvent(new CustomEvent('consent-updated', { detail: categories }));
  }
  hideBanner() {
    this.banner.setAttribute('aria-hidden', 'true');
    this.banner.style.display = 'none';
  }
  showPreferences() {
    window.location.href = '/privacy-preferences';
  }
}
if (!document.cookie.includes('privacy-consent=')) {
  new CookieBanner();
}
```
## Cookie Auditing
**Audit Process:**
1. **Inventory** -- Open site in incognito with DevTools: Application > Cookies. Record every cookie.
2. **Classify** -- Map each to a category. Create a cookie register:
| Cookie Name | Domain | Category | Purpose | Expiration | Third-Party? |
|-------------|--------|----------|---------|------------|:------------:|
| `session_id` | `.example.com` | Necessary | Session management | Session | No |
| `_ga` | `.example.com` | Analytics | Google Analytics user ID | 2 years | Yes |
| `_fbp` | `.example.com` | Marketing | Facebook pixel | 3 months | Yes |
3. **Verify Enforcement:**
   - Reject all -> only necessary cookies set
   - Accept analytics only -> analytics appear, marketing does not
   - Revoke analytics -> analytics cookies removed
4. **Document** -- Maintain cookie register. Update when scripts/purposes change.
**Cookie Attributes Reference:**
| Attribute | Recommended Setting | Why |
|-----------|-------------------|-----|
| `Secure` | Always set | Prevents HTTP transmission |
| `HttpOnly` | Set for server-read cookies | Prevents XSS access |
| `SameSite` | `Lax` or `Strict` | Prevents CSRF |
| `Path` | `/` or most restrictive | Limits cookie scope |
| `Max-Age` | Shortest practical duration | Data minimization |
| `Domain` | Omit (defaults to exact host) | Prevents subdomain leakage |
## Cookie Policy Requirements
| Section | Content |
|---------|---------|
| What cookies are | Brief explanation for non-technical users |
| Categories used | Four categories with descriptions |
| Cookie register | Table of all cookies (name, purpose, duration, party) |
| How to manage | Link to preference center and browser settings |
| Contact | Data protection officer or privacy contact |
| Last updated | Date of last policy review |

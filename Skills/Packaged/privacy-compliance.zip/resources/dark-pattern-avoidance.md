# Dark Pattern Avoidance Reference
Dark patterns are UI designs that manipulate users into choices they would not make if fully informed. In privacy contexts:
1. Consent obtained through manipulation is not valid under GDPR Article 7
2. Regulators actively enforce against them (CNIL, ICO, EDPB)
3. They erode user trust
## The Six Privacy Dark Patterns
### 1. Reject-All Disparity
Making "Reject" harder to find or use than "Accept."
```html
<!-- COMPLIANT: Equal prominence -->
<button class="btn btn-secondary">Reject All</button>
<button class="btn btn-secondary">Customize</button>
<button class="btn btn-primary">Accept All</button>
```
**Violations:**
| Pattern | Why It's Wrong |
|---------|---------------|
| Accept = button, Reject = text link | Unequal visual weight |
| Accept = bright color, Reject = gray | Color manipulation |
| Reject requires 2+ clicks, Accept requires 1 | Friction asymmetry |
| Reject is in a sub-menu or "advanced" section | Hidden option |
| Only "Accept" and "Learn More" shown | No reject option at first layer |
### 2. Pre-Checked Boxes
Consent checkboxes must default to unchecked. Pre-checked boxes are invalid under GDPR Art. 7.
**Common locations:** Cookie preference centers, registration forms, checkout flows, account settings.
**Rule:** Consent requires affirmative act. Pre-checked box is not affirmative.
### 3. Cookie Walls
Blocking access to content unless user accepts all cookies. Under GDPR, consent is not "freely given" if alternative is losing access (Article 7(4)). CCPA is less restrictive.
### 4. Confirmshaming
Using guilt-inducing language to discourage rejection.
| Dark Pattern | Compliant Alternative |
|-------------|----------------------|
| "No thanks, I hate saving money" | "Decline" |
| "I don't care about my privacy" | "Reject All" |
| "Continue with limited experience" | "Continue without cookies" |
**Rule:** Use neutral, factual language for both acceptance and rejection.
### 5. Nagging
Repeatedly showing consent prompts after rejection.
**Violations:** Re-showing banner on every page, "Are you sure?" confirmations, time-based re-prompting.
**Rule:** Respect the user's choice. Store and honor rejection until user revisits preferences.
### 6. Hidden Withdrawal
Making it difficult to change or withdraw consent.
**Violations:** No preference center link, buried in legal pages, requiring login to change preferences.
**Rule:** Withdrawing consent must be as easy as giving it (GDPR Article 7(3)).
## Audit Checklist
**Banner/Modal:**
- [ ] "Reject All" has equal visual prominence to "Accept All"
- [ ] Both options are buttons (not one button and one link)
- [ ] Both use similar size, color contrast, and positioning
- [ ] Rejecting requires same number of clicks as accepting
- [ ] Banner does not block page content (no cookie wall)
- [ ] Banner can be dismissed without choosing (defaults to reject)
**Language:**
- [ ] No guilt-inducing rejection text (no confirmshaming)
- [ ] Options use neutral, descriptive labels
- [ ] No implied consequences for rejection beyond stated functionality loss
**Checkboxes and Defaults:**
- [ ] All non-essential consent checkboxes default to unchecked
- [ ] Necessary cookies section clearly marked as non-toggleable
- [ ] No bundled consent (each category independently selectable)
**Post-Consent:**
- [ ] No repeated prompts after rejection (no nagging)
- [ ] Preference center accessible from every page
- [ ] Withdrawing consent as easy as giving it
- [ ] Consent changes take effect immediately
**Regulatory Alignment:**
- [ ] Compliant with GDPR Article 7 (freely given, specific, informed, unambiguous)
- [ ] No discrimination against users who reject (CCPA non-discrimination)
- [ ] Privacy policy linked from all consent UI
## Enforcement Examples
| Regulator | Company | Fine | Dark Pattern |
|-----------|---------|------|-------------|
| CNIL (France) | Google | 150M EUR | Reject required more clicks than accept |
| CNIL (France) | Facebook | 60M EUR | No single reject button on first layer |
| ICO (UK) | Guidance | -- | Pre-checked boxes invalidate consent |
| EDPB | Guidelines | -- | Cookie walls generally not compliant |

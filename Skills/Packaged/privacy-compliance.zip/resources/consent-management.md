# Consent Management Reference
**Core Principle: Nothing loads before consent.** Every non-essential script, cookie, pixel, or tracker must wait until the user has made an affirmative choice. Silence or inaction is not consent.
## Consent-Before-Load Patterns
**Script Loading Gate:**
```javascript
function loadScript(src) {
  return new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = src;
    script.onload = resolve;
    script.onerror = reject;
    document.head.appendChild(script);
  });
}
function initAnalytics() {
  const consent = getConsentState();
  if (consent.categories.analytics) {
    loadScript('https://analytics.example.com/tracker.js');
  }
}
document.addEventListener('consent-updated', (e) => {
  if (e.detail.analytics) { initAnalytics(); }
});
```
**Tag Manager Integration (Google Consent Mode):**
```javascript
window.dataLayer = window.dataLayer || [];
function gtag() { dataLayer.push(arguments); }
// Default: deny everything
gtag('consent', 'default', {
  'analytics_storage': 'denied',
  'ad_storage': 'denied',
  'functionality_storage': 'denied',
  'personalization_storage': 'denied',
  'security_storage': 'granted'
});
// After user consent
function updateConsent(categories) {
  gtag('consent', 'update', {
    'analytics_storage': categories.analytics ? 'granted' : 'denied',
    'ad_storage': categories.marketing ? 'granted' : 'denied',
    'functionality_storage': categories.functional ? 'granted' : 'denied',
    'personalization_storage': categories.functional ? 'granted' : 'denied'
  });
}
```
**Server-Side Enforcement (Express.js):**
```javascript
function consentMiddleware(req, res, next) {
  const consentCookie = req.cookies['privacy-consent'];
  if (!consentCookie) {
    res.locals.consent = { necessary: true };
    return next();
  }
  try {
    res.locals.consent = JSON.parse(consentCookie);
  } catch {
    res.locals.consent = { necessary: true };
  }
  next();
}
app.get('/page', consentMiddleware, (req, res) => {
  const includeAnalytics = res.locals.consent.categories?.analytics === true;
  res.render('page', { includeAnalytics });
});
```
## Consent Storage
**Cookie-Based (Recommended):**
```javascript
function saveConsent(categories) {
  const consent = {
    version: 2,
    timestamp: new Date().toISOString(),
    categories: {
      necessary: true,
      functional: categories.functional || false,
      analytics: categories.analytics || false,
      marketing: categories.marketing || false
    }
  };
  document.cookie = `privacy-consent=${encodeURIComponent(JSON.stringify(consent))}` +
    '; path=/' +
    '; max-age=15552000' +   // 180 days
    '; secure' +
    '; samesite=lax';
}
```
**Why Cookies Over localStorage:**
| Factor | Cookie | localStorage |
|--------|--------|-------------|
| Server-side access | Yes | No |
| Expiration control | Built-in | Manual cleanup |
| Cross-subdomain | Yes (with `domain`) | No |
| GDPR compliance | Consent cookie is "strictly necessary" | Allowed but less practical |
**Consent Versioning:**
```javascript
const CURRENT_CONSENT_VERSION = 2;
function isConsentCurrent(consent) {
  return consent.version === CURRENT_CONSENT_VERSION;
}
if (!isConsentCurrent(storedConsent)) {
  showConsentBanner();
}
```
## Preference Centers
**Requirements:**
| Requirement | Details |
|-------------|---------|
| Accessibility | Linked from every page (footer) |
| Current state | Shows user's actual consent, not defaults |
| Immediate effect | Revoking consent stops processing immediately |
| Granularity | Per-category minimum; per-vendor ideal |
| Idempotent | Opening/closing without changes preserves state |
**UI Structure:**
```html
<div class="preference-center" role="dialog" aria-label="Privacy preferences">
  <h2>Privacy Preferences</h2>
  <fieldset>
    <legend>Strictly Necessary</legend>
    <p>Required for the site to function. Cannot be disabled.</p>
    <input type="checkbox" checked disabled aria-label="Strictly necessary cookies">
  </fieldset>
  <fieldset>
    <legend>Functional</legend>
    <p>Remember your preferences like language and theme.</p>
    <input type="checkbox" id="pref-functional" aria-label="Functional cookies">
  </fieldset>
  <fieldset>
    <legend>Analytics</legend>
    <input type="checkbox" id="pref-analytics" aria-label="Analytics cookies">
  </fieldset>
  <fieldset>
    <legend>Marketing</legend>
    <input type="checkbox" id="pref-marketing" aria-label="Marketing cookies">
  </fieldset>
  <button id="save-preferences">Save Preferences</button>
</div>
```
## CMP vs Self-Hosted
| CMP Approach | When to Use |
|--------------|-------------|
| **Use a CMP** | Many third-party integrations, EU audience, compliance reporting needed |
| **Self-host** | Simple sites, few trackers, strong privacy stance, no SaaS budget |
**CMP Selection Criteria:**
| Criterion | Questions |
|-----------|-----------|
| TCF compliance | Supports IAB Transparency & Consent Framework? |
| Regulation coverage | Handles GDPR, CCPA, LGPD, ePrivacy? |
| Integration | Works with your tag manager and analytics? |
| Data residency | Where does it store consent records? |
| Customization | Can match your site branding? |
| Performance | Script size and load impact? |
**Self-Hosted Checklist:**
- [ ] Consent banner UI with accept/reject/customize
- [ ] Preference center with per-category toggles
- [ ] Cookie for storing consent state (first-party, secure, SameSite)
- [ ] Script loading gate (nothing loads before consent)
- [ ] Consent versioning for requirement changes
- [ ] Server-side enforcement middleware
- [ ] Consent audit log (who consented to what, when)
- [ ] Link to privacy policy from all consent UI
- [ ] Accessible and keyboard-navigable
- [ ] Mobile-responsive
## Common Mistakes
| Mistake | Why It's Wrong |
|---------|---------------|
| Loading analytics before consent | Processes data without lawful basis |
| Storing consent in localStorage only | Cannot enforce server-side; no expiration |
| No consent versioning | Cannot re-prompt when requirements change |
| Preference center shows defaults, not actual state | Misleads users |
| "Accept" dismisses banner, "Reject" does nothing | Dark pattern |
| No server-side enforcement | Client-side only consent can be bypassed |

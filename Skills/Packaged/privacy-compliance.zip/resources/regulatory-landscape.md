# Regulatory Landscape Reference
Implementation patterns for developers, not legal interpretation. Consult qualified legal counsel for compliance requirements specific to your organization.
## GDPR (General Data Protection Regulation)
| Field | Detail |
|-------|--------|
| **Jurisdiction** | European Union and EEA |
| **Effective** | May 25, 2018 |
| **Applies when** | Processing personal data of EU/EEA residents, regardless of company location |
| **Enforced by** | National DPAs (CNIL, BfDI, ICO) |
| **Penalties** | Up to 4% global turnover or 20M EUR |
**Lawful Basis (Article 6):**
| Basis | When to Use | Developer Action |
|-------|-------------|-----------------|
| **Consent** | Optional features (analytics, marketing) | Implement consent gate; record proof |
| **Contract** | Fulfilling user agreement | Process only data needed for service |
| **Legitimate interest** | Security logging, fraud prevention | Document interest; offer opt-out |
| **Legal obligation** | Tax records, regulatory reporting | Retain required data; delete the rest |
| **Vital interest** | Emergency situations | Rarely applies to web apps |
| **Public task** | Government functions | Rarely applies to private companies |
**Consent Requirements (Article 7):**
```
Consent must be:
+-- Freely given    -> No penalty for refusing
+-- Specific        -> Per purpose, not blanket
+-- Informed        -> Clear language about what and why
+-- Unambiguous     -> Affirmative action (not pre-checked)
+-- Withdrawable    -> As easy to revoke as to give
```
**Data Subject Rights (Articles 15-22):**
| Right | Implementation Pattern |
|-------|----------------------|
| **Access** (Art. 15) | Export endpoint returning all personal data in machine-readable format |
| **Rectification** (Art. 16) | Profile edit functionality |
| **Erasure** (Art. 17) | Account deletion removing personal data from all systems |
| **Portability** (Art. 20) | Data export in JSON, CSV, or structured format |
| **Objection** (Art. 21) | Opt-out mechanism for legitimate interest processing |
| **Restrict processing** (Art. 18) | Flag to stop processing during dispute |
**Breach Notification (Article 33):** Within 72 hours notify supervisory authority. High risk to individuals: notify data subjects. Document everything.
## CCPA / CPRA (California)
| Field | Detail |
|-------|--------|
| **Jurisdiction** | California, United States |
| **Effective** | CCPA: Jan 1, 2020; CPRA: Jan 1, 2023 |
| **Applies when** | CA customers AND thresholds: >$25M revenue, >100K consumers' data, >50% revenue from selling data |
| **Enforced by** | CPPA; California Attorney General |
| **Penalties** | $2,500/unintentional, $7,500/intentional violation |
**Key Differences from GDPR:**
| Aspect | GDPR | CCPA/CPRA |
|--------|------|-----------|
| Consent model | Opt-in | Opt-out |
| Scope | Any data processor handling EU data | Businesses meeting thresholds |
| "Sale" concept | Not defined | Broad -- includes behavioral ad sharing |
| Cookie consent | Required before setting | Not specifically required |
| Private right of action | Limited | Yes, for data breaches |
**"Do Not Sell or Share":**
```html
<a href="/do-not-sell">Do Not Sell or Share My Personal Information</a>
```
**Global Privacy Control (GPC):**
```javascript
if (navigator.globalPrivacyControl) {
  disableThirdPartyTracking();
  disableBehavioralAds();
}
```
Businesses must honor GPC signal as valid opt-out under CPRA.
**Non-Discrimination:** No price increases, degraded service, or denial for exercising privacy rights.
## LGPD (Brazil)
| Field | Detail |
|-------|--------|
| **Jurisdiction** | Brazil |
| **Effective** | September 18, 2020 |
| **Applies when** | Processing personal data of individuals in Brazil |
| **Enforced by** | ANPD |
| **Penalties** | Up to 2% BR revenue, capped at 50M BRL |
**10 Lawful Bases (Article 7):**
1. Consent
2. Legal obligation
3. Public administration
4. Research (anonymized when possible)
5. Contract performance
6. Exercise of rights in judicial/administrative proceedings
7. Life or physical safety protection
8. Health protection
9. Legitimate interest
10. **Credit protection** (unique to LGPD)
**Consent:** Written or demonstrable, separate clause, controller bears burden of proof, revocable via free/easy procedure.
**International Data Transfers:** Permitted when destination provides adequate protection, controller offers guarantees (SCCs, BCRs), or data subject gives specific informed consent.
## ePrivacy Directive (2002/58/EC)
| Field | Detail |
|-------|--------|
| **Jurisdiction** | EU (supplements GDPR) |
| **Effective** | 2002 (amended 2009) |
| **Applies when** | Using cookies, email marketing, or electronic communications in EU |
| **Enforced by** | National regulators |
| **Status** | ePrivacy Regulation replacement in draft since 2017 |
**Cookie Consent (Article 5(3)):**
```
Storing information on user's device:
+-- Strictly necessary for service -> No consent needed
+-- All other purposes -> Prior, informed consent required
```
**What counts as "storing information":** HTTP cookies, localStorage, sessionStorage, IndexedDB, device fingerprinting, tracking pixels.
**Email Marketing (Article 13):**
| Scenario | Consent Required? |
|----------|:----------------:|
| Marketing to new contacts | Yes (opt-in) |
| Existing customers (related products) | No (soft opt-in, must offer opt-out) |
| B2B marketing | Varies by national implementation |
Every marketing email must include: clear identification, sender identity, unsubscribe mechanism.
## Comparison Matrix
| Requirement | GDPR | CCPA/CPRA | LGPD | ePrivacy |
|-------------|:----:|:---------:|:----:|:--------:|
| Consent model | Opt-in | Opt-out | Opt-in | Opt-in |
| Cookie consent | Via ePrivacy | Not specifically | Yes | Yes (primary) |
| Right to delete | Yes | Yes | Yes | -- |
| Right to access | Yes | Yes | Yes | -- |
| Data portability | Yes | Yes (limited) | Yes | -- |
| Breach notification | 72 hours | -- | Reasonable time | -- |
| DPO required | Sometimes | No | Sometimes | -- |
| Private right of action | Limited | Yes (breaches) | Yes | Varies |
| Extraterritorial | Yes | Yes (threshold) | Yes | Yes |
| Max penalty | 4% global turnover | $7,500/violation | 2% BR revenue | Varies |
## Developer Quick Reference
**Minimum Viable Compliance Checklist:**
- [ ] Know what personal data you collect and why
- [ ] Get consent before non-essential data processing
- [ ] Let users access, export, and delete their data
- [ ] Only collect data you actually need
- [ ] Secure personal data in transit and at rest
- [ ] Document your data processing activities
- [ ] Have a breach response plan
- [ ] Keep a privacy policy that is accurate and current
**Determining Which Regulations Apply:**
```
Where are your users?
+-- EU/EEA -> GDPR + ePrivacy
+-- California -> CCPA/CPRA (if thresholds met)
+-- Brazil -> LGPD
+-- UK -> UK GDPR (similar to EU GDPR)
+-- Multiple -> Apply the strictest regulation as baseline
```
**Practical approach:** If serving global audience, implement GDPR-level compliance as baseline.

---
name: privacy-compliance
description: Provide structured privacy compliance guidance for web and mobile projects covering consent management, cookie compliance, dark pattern avoidance, and regulatory landscape
version: "0.55.0"
license: Complete terms in LICENSE.txt
---
**Purpose:** Guide developers through implementing privacy compliance patterns during development rather than retrofitting during audits.
**Audience:** Developers building web or mobile applications that collect, process, or store user data.
**Related Skills:** `seo-optimization` -- for meta tag and structured data guidance that may overlap with consent metadata
## When to Use This Skill
- Adding analytics, tracking, or third-party scripts
- Implementing cookie consent banners or preference centers
- Designing forms that collect personal data
- Integrating with advertising or marketing platforms
- Building user account features (registration, profile management)
- Auditing existing site for privacy compliance gaps
- Working with data storage (cookies, localStorage, IndexedDB) containing personal data
## Core Areas
1. **Consent Management** -- Collecting, storing, and enforcing user consent before loading scripts or setting cookies
2. **Cookie Compliance** -- Cookie classification, banner implementation, and auditing
3. **Dark Pattern Avoidance** -- UI patterns that violate regulations or erode trust
4. **Regulatory Landscape** -- GDPR, CCPA/CPRA, LGPD, and ePrivacy implementation patterns (not legal advice)
**Not Covered (v1):** Privacy-by-design, data subject rights, third-party script auditing, framework-specific guidance. See `Docs/02-Advanced/Skill-Guide-Privacy-Compliance.md`.
## Consent Management Essentials
**Core Rule: Nothing loads before consent.** No analytics, advertising pixels, social media widgets, or non-essential cookies until the user makes an informed, affirmative choice.
**Consent-Before-Load Pattern:**
```html
<!-- GOOD: Scripts only load after consent -->
<script>
  if (hasConsent('analytics')) {
    loadScript('https://analytics.example.com/tracker.js');
  }
</script>
```
**Consent Storage** -- first-party cookie:
```javascript
{
  "version": 2,
  "timestamp": "2026-01-15T10:30:00Z",
  "categories": {
    "necessary": true,
    "functional": true,
    "analytics": false,
    "marketing": false
  },
  "granular": {
    "google-analytics": false,
    "hotjar": false
  }
}
```
**Rules:**
- Store as first-party cookie (not localStorage -- cookies travel with requests for server-side enforcement)
- Include schema version for migration and timestamp for audit trail
- Default all non-essential categories to `false`
- Never pre-select non-essential categories
**Preference Centers:**
- Accessible from every page (typically footer)
- Shows current consent state (not defaults)
- Changes take effect immediately (revoke = stop processing)
- Granular control per category or per vendor
**CMP vs Self-Hosted:**
| Approach | Pros | Cons |
|----------|------|------|
| CMP | Auto-updated for regulation changes, vendor integrations, compliance reporting | Third-party dependency, cost, data leaves your domain |
| Self-hosted | Full control, no data egress, no cost | Must track regulation changes, build UI, maintain compliance |
## Cookie Compliance Essentials
**Cookie Classification:**
| Category | Description | Consent Required | Examples |
|----------|-------------|:---------------:|----------|
| **Strictly Necessary** | Essential for site function | No | Session ID, CSRF token, consent cookie |
| **Functional** | Enhanced features, not essential | Yes | Language preference, theme, remembered login |
| **Analytics** | Usage measurement | Yes | Google Analytics, Hotjar, page view counters |
| **Marketing** | Advertising and cross-site tracking | Yes | Ad network cookies, retargeting pixels |
**Cookie Banner:**
```html
<div id="cookie-banner" role="dialog" aria-label="Cookie consent">
  <p>We use cookies to improve your experience.
     <a href="/privacy-policy">Learn more</a>.</p>
  <div class="cookie-actions">
    <button id="reject-all">Reject All</button>
    <button id="customize">Customize</button>
    <button id="accept-all">Accept All</button>
  </div>
</div>
```
**Rules:**
- Banner appears before any non-essential cookies are set
- "Reject All" as easy to find/use as "Accept All"
- Must not block content entirely (no cookie walls under GDPR)
- Must link to privacy policy, be accessible (ARIA roles, keyboard navigable)
**Cookie Auditing:**
| Check | How | Why |
|-------|-----|-----|
| Inventory all cookies | Browser DevTools > Application > Cookies | Know what you're setting |
| Classify each cookie | Map to category | Required for banner |
| Check third-party cookies | Filter by domain in DevTools | Need explicit consent |
| Verify consent enforcement | Reject all > check no non-essential cookies set | Prove compliance |
| Check cookie attributes | `Secure`, `HttpOnly`, `SameSite`, `Path`, expiration | Security and scope |
## Dark Pattern Avoidance Essentials
Dark patterns are UI designs that trick users into choices they wouldn't make if fully informed. Consent obtained through manipulation is not valid under GDPR.
**1. Reject-All Parity** -- "Reject All" must be as easy to find/use as "Accept All."
```html
<!-- GOOD: Equal prominence -->
<button class="btn-secondary">Reject All</button>
<button class="btn-secondary">Customize</button>
<button class="btn-primary">Accept All</button>
```
**2. No Pre-Checked Boxes** -- Consent checkboxes must default to unchecked (GDPR Article 7).
**3. No Cookie Walls** -- Blocking content unless user accepts all cookies is generally not valid under GDPR.
**4. No Confirmshaming** -- Use neutral language ("Reject All" not "I don't care about my experience").
**Dark Pattern Checklist:**
- [ ] "Reject All" and "Accept All" have equal visual weight
- [ ] No pre-checked consent boxes
- [ ] Content accessible without accepting cookies
- [ ] No guilt-inducing language for rejection
- [ ] Withdrawing consent is as easy as giving it
- [ ] No repeated consent prompts after rejection (nagging)
- [ ] Consent modal can be closed without choosing (defaults to reject)
## Regulatory Landscape Overview
> **Disclaimer:** Implementation patterns for developers, not legal advice. Consult qualified legal counsel.
**GDPR** (EU/EEA):
- Consent must be freely given, specific, informed, unambiguous, and easy to withdraw
- Data minimization, right to be forgotten, data portability
- 72-hour breach notification
- Penalties: Up to 4% global turnover or 20M EUR
**CCPA/CPRA** (California):
- Opt-out model (not opt-in); must honor "Do Not Sell or Share"
- Right to know, right to delete, non-discrimination
- Penalties: $2,500/unintentional, $7,500/intentional violation
**LGPD** (Brazil):
- 10 lawful bases (includes credit protection, health protection)
- Consent specific, informed, freely given; revocable at any time
- Penalties: Up to 2% BR revenue, capped at 50M BRL
**ePrivacy Directive** (EU, supplements GDPR):
- Prior consent required for non-essential cookies
- Opt-in for marketing emails (soft opt-in for existing customers)
**Comparison Matrix:**
| Requirement | GDPR | CCPA/CPRA | LGPD | ePrivacy |
|-------------|------|-----------|------|----------|
| Consent model | Opt-in | Opt-out | Opt-in | Opt-in |
| Cookie consent | Via ePrivacy | Not specifically | Yes | Yes (primary) |
| Right to delete | Yes | Yes | Yes | -- |
| Data portability | Yes | Yes (limited) | Yes | -- |
| Breach notification | 72 hours | -- | Reasonable time | -- |
| DPO required | Sometimes | No | Sometimes | -- |
| Extraterritorial | Yes | Yes (threshold) | Yes | Yes |
## Quick Reference Checklist
**Consent Management:**
- [ ] No scripts load before consent is given
- [ ] Consent stored in first-party cookie with categories
- [ ] Preference center accessible from every page
- [ ] Consent withdrawal stops processing immediately
- [ ] Default state is "all non-essential declined"
**Cookie Compliance:**
- [ ] All cookies classified (necessary, functional, analytics, marketing)
- [ ] Banner appears before non-essential cookies are set
- [ ] "Reject All" has equal prominence to "Accept All"
- [ ] Cookie audit performed and documented
- [ ] Third-party cookies identified and consented
**Dark Pattern Avoidance:**
- [ ] No pre-checked consent boxes
- [ ] No cookie walls blocking content
- [ ] No confirmshaming language
- [ ] Rejection is one click (not multi-step)
- [ ] No repeated prompts after rejection
**Regulatory:**
- [ ] Privacy policy linked and current
- [ ] Correct consent model for target jurisdictions (opt-in vs opt-out)
- [ ] Data collection serves a stated purpose
- [ ] Breach notification process documented

---
name: playwright-setup
description: Installation verification and troubleshooting for Playwright browser automation framework
version: "0.55.0"
license: Complete terms in LICENSE.txt
---
# Playwright Setup
## When to Use
- Setting up Playwright in a new project
- Debugging "browser not found" or installation errors
- Configuring Playwright for CI/CD pipelines
- Troubleshooting tests that pass locally but fail in CI
## Prerequisites
- Node.js 18+
- npm or yarn
- For Linux CI: System dependencies or Docker with Playwright image
---
## Installation Checklist
Complete setup requires **three steps**, not just `npm install`:

| Step | Command | What It Does |
|------|---------|--------------|
| 1. Install package | `npm install -D @playwright/test` | Adds Playwright to devDependencies |
| 2. Download browsers | `npx playwright install` | Downloads Chromium, Firefox, WebKit (~500MB) |
| 3. System deps (Linux) | `npx playwright install-deps` | Installs system libraries (requires sudo) |

**Common Mistake:** Stopping after step 1 results in "Executable doesn't exist" errors.
---
## Verification Steps
### Quick Check
```bash
npm ls @playwright/test
npx playwright install --dry-run
npx playwright test --list
```
### Browser Launch Test
```javascript
// verify-playwright.js
const { chromium, firefox, webkit } = require('playwright');

async function verify() {
  for (const browserType of [chromium, firefox, webkit]) {
    try {
      const browser = await browserType.launch();
      console.log(`${browserType.name()}: OK`);
      await browser.close();
    } catch (error) {
      console.log(`${browserType.name()}: FAILED - ${error.message}`);
    }
  }
}
verify();
```
---
## Common Errors

| Error Message | Cause | Fix |
|---------------|-------|-----|
| "Executable doesn't exist at ..." | Browsers not downloaded | `npx playwright install` |
| "Host system is missing dependencies" | Linux system libs missing | `npx playwright install-deps` |
| "browserType.launch: Browser closed unexpectedly" | Corrupted browser install | `npx playwright install --force` |
| "Cannot find module '@playwright/test'" | Package not installed | `npm install -D @playwright/test` |
| Tests hang in CI | Missing display server (Linux) | Use headless mode or `xvfb-run` |
| "Target page, context or browser has been closed" | Race condition | Add explicit waits |
| "Browser closed. Most likely the page has been closed" | Navigation timeout | Increase timeout or check network |

See: [common-errors.md](resources/common-errors.md) for detailed solutions.
---
## CI Configuration
### GitHub Actions
```yaml
name: Playwright Tests
on: [push, pull_request]
jobs:
  test:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-node@v4
        with:
          node-version: 20
          cache: 'npm'
      - name: Install dependencies
        run: npm ci
      - name: Install Playwright browsers
        run: npx playwright install --with-deps
      - name: Run tests
        run: npx playwright test
      - uses: actions/upload-artifact@v4
        if: always()
        with:
          name: playwright-report
          path: playwright-report/
          retention-days: 30
```
- `--with-deps` combines browser download and system deps
- `if: always()` uploads report even on test failure

See: [ci-patterns.md](resources/ci-patterns.md) for GitLab CI and other configurations.
---
## Platform Notes
### Windows
- Browsers install to `%USERPROFILE%\AppData\Local\ms-playwright`
- No system dependencies needed
### macOS
- Browsers install to `~/Library/Caches/ms-playwright`
- Rosetta 2 required for Apple Silicon (automatic)
### Linux
- Browsers install to `~/.cache/ms-playwright`
- System dependencies **required** - run `npx playwright install-deps`
- Docker alternative: `mcr.microsoft.com/playwright` image

| Environment | Browser Location | Notes |
|-------------|------------------|-------|
| GitHub Actions | Runner-local | Use `--with-deps` flag |
| GitLab CI | Docker image | Use official Playwright image |
| Jenkins | Agent-local | Pre-install browsers on agents |
| CircleCI | Docker image | Use orb or Playwright image |
---
## Headless vs Headed Mode
```javascript
const browser = await chromium.launch();                          // Headless (default, for CI)
const browser = await chromium.launch({ headless: false });       // Headed (debugging)
const browser = await chromium.launch({ headless: false, slowMo: 100 }); // Slow motion (demos)
```
**CI Requirement:** Always use headless mode unless using Xvfb.
---
## Browser Selection
```javascript
// playwright.config.js
export default {
  projects: [
    { name: 'chromium', use: { browserName: 'chromium' } },
    { name: 'firefox', use: { browserName: 'firefox' } },
    { name: 'webkit', use: { browserName: 'webkit' } },
  ],
};
```
```bash
npx playwright install chromium              # Install only Chromium (faster CI)
npx playwright install chromium --with-deps  # With system deps
```
---
## Troubleshooting Matrix

| Symptom | Check | Solution |
|---------|-------|----------|
| Works locally, fails in CI | Browser binaries | Add `npx playwright install` to CI |
| Works in CI, fails locally | Version mismatch | `npx playwright install --force` |
| Timeout on launch | Headless mode | Ensure `headless: true` in CI |
| Random failures | Race conditions | Add explicit `waitFor*` calls |
| Memory issues | Browser leaks | Ensure `browser.close()` in `afterAll` |
| Screenshot blank | Page not loaded | Wait for network idle |
---
## Resources

| Resource | Description |
|----------|-------------|
| [ci-patterns.md](resources/ci-patterns.md) | GitHub Actions, GitLab CI, Jenkins configs |
| [common-errors.md](resources/common-errors.md) | Detailed error -> fix reference |
---
## Related Skills
- **electron-development** - For Playwright with Electron apps (fuse configuration, packaged app testing)
---
**End of Playwright Setup Skill**

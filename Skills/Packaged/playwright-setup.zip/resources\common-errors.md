# Common Playwright Errors and Solutions
**Version:** 0.52.0
---
## Installation Errors
### "Executable doesn't exist"
```
Error: Executable doesn't exist at /home/user/.cache/ms-playwright/chromium-1234/chrome-linux/chrome
```
**Cause:** Browsers not downloaded after npm install.
**Fix:** `npx playwright install` (or `npx playwright install chromium` for specific browser)
---
### "Host system is missing dependencies"
**Cause:** Linux missing required shared libraries.
**Fix:** `npx playwright install-deps` or `npx playwright install --with-deps`
**CI:** Use `mcr.microsoft.com/playwright:v1.40.0-jammy` Docker image.
---
### "Cannot find module '@playwright/test'"
**Fix:** `npm install -D @playwright/test`
**Verify:** `npm ls @playwright/test`
---
### "Browser closed unexpectedly" During Install
**Cause:** Corrupted browser download.
**Fix:**
```bash
npx playwright install --force
# Or clear cache and reinstall:
rm -rf ~/.cache/ms-playwright    # Linux/macOS
npx playwright install
```
---
## Runtime Errors
### "browserType.launch: Timeout exceeded"
1. Increase launch timeout: `{ timeout: 60000 }`
2. Ensure headless mode in CI: `{ headless: true }`
3. Check available resources on CI runner
---
### "Target page, context or browser has been closed"
**Cause:** Accessing page/browser after close (navigation, race condition).
```javascript
// Good: expect navigation
await Promise.all([
  page.waitForNavigation({ waitUntil: 'load' }),
  page.click('a[href="/logout"]')
]);
```
---
### "Timeout exceeded while waiting for selector"
1. Debug with screenshot: `await page.screenshot({ path: 'debug.png' });`
2. Increase timeout: `{ timeout: 60000 }`
3. Wait for network: `await page.goto(url, { waitUntil: 'networkidle' });`
4. Wait for visibility: `await page.waitForSelector('#el', { state: 'visible' });`
---
### "Navigation timeout exceeded"
1. Increase: `await page.goto(url, { timeout: 60000 });`
2. Less strict wait: `{ waitUntil: 'domcontentloaded' }`
3. Global config:
```javascript
export default {
  timeout: 60000,
  use: { navigationTimeout: 60000 },
};
```
---
### Tests Hang Indefinitely
**Dialog not handled:**
```javascript
page.on('dialog', dialog => dialog.accept());
await page.click('#trigger-alert');
```
**Download not handled:**
```javascript
const [download] = await Promise.all([
  page.waitForEvent('download'),
  page.click('#download-button')
]);
```
**Popup not handled:**
```javascript
const [popup] = await Promise.all([
  page.waitForEvent('popup'),
  page.click('a[target="_blank"]')
]);
await popup.waitForLoadState();
```
---
### "net::ERR_CONNECTION_REFUSED"
**Cause:** Application server not running.
```javascript
// playwright.config.js
export default {
  webServer: {
    command: 'npm run start',
    url: 'http://localhost:3000',
    reuseExistingServer: !process.env.CI,
  },
};
```
---
## CI-Specific Errors
### Tests Pass Locally, Fail in CI

| Cause | Solution |
|-------|----------|
| Different browser versions | Pin Playwright version, use Docker |
| Timing differences | Add explicit waits, increase timeouts |
| Missing environment variables | Check CI env configuration |
| Different screen resolution | Set viewport explicitly |

Debug:
```javascript
test.beforeEach(async ({ page }) => {
  page.on('console', msg => console.log(msg.text()));
  page.on('pageerror', err => console.log(err.message));
});
```
---
### "Failed to launch browser" in Docker
Use official Playwright image:
```dockerfile
FROM mcr.microsoft.com/playwright:v1.40.0-jammy
WORKDIR /app
COPY package*.json ./
RUN npm ci
COPY . .
CMD ["npx", "playwright", "test"]
```
---
## Memory and Performance Errors
### "Out of Memory" / OOM Killed
1. Reduce workers: `{ workers: 2 }`
2. Close contexts: `test.afterEach(async ({ context }) => { await context.close(); });`
3. Docker fix: `args: ['--disable-dev-shm-usage']`
### Tests Slow in CI
```javascript
export default {
  use: {
    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
    trace: 'retain-on-failure',
  },
};
```
---
## Quick Reference

| Error Contains | Likely Fix |
|----------------|------------|
| "Executable doesn't exist" | `npx playwright install` |
| "missing dependencies" | `npx playwright install-deps` |
| "Cannot find module" | `npm install -D @playwright/test` |
| "Timeout" | Increase timeout or add waits |
| "closed unexpectedly" | `npx playwright install --force` |
| "net::ERR_" | Check server is running |
| "Target closed" | Fix race conditions |
---
**End of Common Errors**

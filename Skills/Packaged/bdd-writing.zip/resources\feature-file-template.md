# Feature File Template
**Version:** 0.52.0
Use this template as a starting point for new feature files.
---
## Basic Template
```gherkin
@tag1 @tag2
Feature: [Feature Name]
  [Brief description of what this feature does]

  As a [role/persona]
  I want [goal/desire]
  So that [benefit/value]

  Background:
    Given [shared precondition for all scenarios]

  @scenario-tag
  Scenario: [Descriptive scenario name - happy path]
    Given [precondition]
    And [additional precondition]
    When [action]
    Then [expected outcome]
    And [additional verification]

  Scenario: [Descriptive scenario name - error case]
    Given [precondition leading to error]
    When [action that triggers error]
    Then [error handling behavior]
```
---
## Example: E-commerce Cart
```gherkin
@cart @shopping
Feature: Shopping Cart Management
  Allows customers to manage items before checkout

  As an online shopper
  I want to add, remove, and update items in my cart
  So that I can purchase exactly what I need

  Background:
    Given I am logged in as a customer

  @smoke @happy-path
  Scenario: Add single item to empty cart
    Given my shopping cart is empty
    When I add "Blue T-Shirt" to my cart
    Then my cart contains 1 item
    And the cart total is $29.99

  @edge-case
  Scenario: Add out-of-stock item
    Given "Red Sneakers" is out of stock
    When I try to add "Red Sneakers" to my cart
    Then I see an error "This item is currently unavailable"

  Scenario Outline: Apply discount codes
    Given my cart total is $100.00
    When I apply discount code "<code>"
    Then the new total is "<total>"

    Examples:
      | code      | total   |
      | SAVE10    | $90.00  |
      | PERCENT20 | $80.00  |
      | INVALID   | $100.00 |
```
---
## Example: API Feature
```gherkin
@api @orders
Feature: Order API
  RESTful API for order management

  Background:
    Given I am authenticated with a valid API key

  @smoke
  Scenario: Create a new order
    When I POST to "/api/orders" with:
      """json
      {
        "customerId": "cust-123",
        "items": [{"productId": "prod-456", "quantity": 2}]
      }
      """
    Then the response status is 201
    And the order status is "pending"

  Scenario: Order not found
    When I GET "/api/orders/nonexistent"
    Then the response status is 404
    And the response contains error "Order not found"
```
---
## File Naming Conventions
| Pattern | Example |
|---------|---------|
| `[feature-name].feature` | `shopping-cart.feature` |
| `[domain]/[feature].feature` | `orders/create-order.feature` |
---
## Directory Structure
```
features/
├── authentication/
│   ├── login.feature
│   └── password-reset.feature
├── orders/
│   ├── create-order.feature
│   └── order-history.feature
└── api/
    └── orders-api.feature
```
---
**End of Feature File Template**

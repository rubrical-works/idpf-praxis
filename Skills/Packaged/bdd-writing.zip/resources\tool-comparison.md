# BDD Tool Comparison
**Version:** 0.52.0
Comparison of popular BDD frameworks across languages.
---
## Quick Reference
| Tool | Language | Gherkin | Best For |
|------|----------|---------|----------|
| Cucumber.js | JavaScript/TypeScript | Native | JS/TS projects, Playwright/Puppeteer |
| pytest-bdd | Python | Native | Python projects, pytest ecosystem |
| Behave | Python | Native | Python projects, standalone |
| Cucumber-JVM | Java/Kotlin | Native | Java projects, Spring Boot |
| SpecFlow | C#/.NET | Native | .NET projects |
| RSpec | Ruby | BDD-style | Ruby projects |
| Karate | Java | Modified | API testing |
---
## Cucumber.js
**Install:** `npm install --save-dev @cucumber/cucumber`
**Run:** `npx cucumber-js`, `npx cucumber-js --tags "@smoke"`
**Strengths:** Native Gherkin, large community, Playwright/Puppeteer integration, TypeScript support, parallel execution
---
## pytest-bdd
**Install:** `pip install pytest-bdd`
**Run:** `pytest`, `pytest -m "smoke"`
**Strengths:** pytest ecosystem integration, pytest fixtures, IDE support (PyCharm), parametrized scenarios
---
## Behave
**Install:** `pip install behave`
**Run:** `behave`, `behave --tags=@smoke`
**Strengths:** Standalone, simple setup, good documentation
**Best for:** Python projects not using pytest
---
## Cucumber-JVM
**Install:** Maven dependency `io.cucumber:cucumber-java`
**Run:** `mvn test`, `mvn test -Dcucumber.filter.tags="@smoke"`
**Strengths:** Spring Boot integration, JUnit 5 support, dependency injection
---
## SpecFlow
**Install:** `dotnet add package SpecFlow`
**Run:** `dotnet test`
**Strengths:** .NET ecosystem, Visual Studio extension, living documentation
---
## Karate
API testing focused with built-in assertions. No code step definitions needed.
```gherkin
Scenario: Get user by ID
  Given url 'https://api.example.com/users'
  And path '123'
  When method get
  Then status 200
  And match response.name == 'Alice'
```
---
## Selection Guide
```
Python? -> pytest-bdd (with pytest) or Behave (without)
JavaScript/TypeScript? -> Cucumber.js
Java/Kotlin? -> Karate (API) or Cucumber-JVM (general)
.NET? -> SpecFlow
Ruby? -> Cucumber-Ruby (Gherkin) or RSpec (native)
```
### By Use Case
| Use Case | Recommended Tool |
|----------|------------------|
| Web UI testing (JS) | Cucumber.js + Playwright |
| Web UI testing (Python) | pytest-bdd + Selenium/Playwright |
| Web UI testing (Java) | Cucumber-JVM + Selenium |
| API testing (any) | Karate or language-native |
| Enterprise Java | Cucumber-JVM |
| Enterprise .NET | SpecFlow |
### Feature Comparison
| Feature | Cucumber.js | pytest-bdd | Behave | Cucumber-JVM | SpecFlow |
|---------|-------------|------------|--------|--------------|----------|
| Gherkin | Full | Full | Full | Full | Full |
| Parallel | Yes | Yes (pytest) | Limited | Yes | Yes |
| IDE Support | Good | Excellent | Good | Excellent | Excellent |
| Learning Curve | Low | Low | Low | Medium | Medium |
---
## Migration Notes
- **Feature files** are usually portable (Gherkin is standard)
- **Step definitions** must be rewritten in target language
- **Configuration** is tool-specific, needs recreation
---
**End of Tool Comparison**

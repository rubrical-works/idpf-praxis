# Step Definition Patterns
**Version:** {{VERSION}}
Examples of step definitions across different BDD frameworks.
---
## JavaScript (Cucumber.js)
### Basic Steps
```javascript
const { Given, When, Then } = require('@cucumber/cucumber');

Given('a user exists with email {string} and password {string}', async function(email, password) {
  await this.userService.createUser({ email, password });
});
When('I enter email {string}', async function(email) {
  await this.page.fill('#email', email);
});
Then('I am redirected to the dashboard', async function() {
  await expect(this.page).toHaveURL('/dashboard');
});
Then('the cart contains {int} item(s)', async function(count) {
  const cartCount = await this.page.locator('.cart-count');
  await expect(cartCount).toHaveText(String(count));
});
```
### Data Tables
```javascript
Given('the following users exist:', async function(dataTable) {
  const users = dataTable.hashes();
  for (const user of users) {
    await this.userService.createUser(user);
  }
});
```
### Hooks
```javascript
const { Before, After, BeforeAll, AfterAll } = require('@cucumber/cucumber');
Before(async function() { await this.database.clear(); });
Before({ tags: '@authenticated' }, async function() {
  await this.authService.login('testuser@example.com');
});
After(async function(scenario) {
  if (scenario.result.status === 'FAILED') {
    await this.page.screenshot({ path: `screenshots/${scenario.pickle.name}.png` });
  }
});
```
---
## Python (pytest-bdd)
### Basic Steps
```python
from pytest_bdd import given, when, then, parsers

@given(parsers.parse('a user exists with email "{email}" and password "{password}"'))
def create_user(user_service, email, password):
    user_service.create_user(email=email, password=password)

@when(parsers.parse('I enter email "{email}"'))
def enter_email(browser, email):
    browser.find_element('#email').send_keys(email)

@then('I am redirected to the dashboard')
def verify_dashboard(browser):
    assert '/dashboard' in browser.current_url
```
### Fixtures
```python
@pytest.fixture
def browser():
    driver = webdriver.Chrome()
    yield driver
    driver.quit()
```
---
## Java (Cucumber-JVM)
### Basic Steps
```java
public class LoginSteps {
    @Given("a user exists with email {string} and password {string}")
    public void aUserExistsWithEmailAndPassword(String email, String password) {
        userService.createUser(email, password);
    }
    @When("I enter email {string}")
    public void iEnterEmail(String email) {
        driver.findElement(By.id("email")).sendKeys(email);
    }
    @Then("I am redirected to the dashboard")
    public void iAmRedirectedToTheDashboard() {
        assertTrue(driver.getCurrentUrl().contains("/dashboard"));
    }
}
```
### Data Tables
```java
@Given("the following users exist:")
public void theFollowingUsersExist(DataTable dataTable) {
    List<Map<String, String>> users = dataTable.asMaps();
    for (Map<String, String> user : users) {
        userService.createUser(user.get("username"), user.get("email"), user.get("role"));
    }
}
```
---
## Common Patterns
### Reusable Steps
```javascript
Given('a user {string} exists', async function(username) {
  await this.userService.createUser({ username });
});
Given('a user {string} with role {string} exists', async function(username, role) {
  await this.userService.createUser({ username, role });
});
```
### State Sharing Between Steps
```javascript
// Cucumber.js - World object
Given('I create an order', async function() { this.order = await this.orderService.create(); });
Then('the order status is {string}', async function(status) { expect(this.order.status).toBe(status); });
```
```python
# pytest - fixtures
@pytest.fixture
def context(): return {}

@given('I create an order')
def create_order(context, order_service):
    context['order'] = order_service.create()
```
---
**End of Step Definition Patterns**

# Gherkin Syntax Reference
**Version:** 0.52.0
Complete reference for Gherkin syntax used in BDD feature files.
---
## Keywords
### Primary Keywords
| Keyword | Purpose | Required |
|---------|---------|----------|
| `Feature` | Describe the feature being tested | Yes (once per file) |
| `Scenario` | Define a single test case | Yes (at least one) |
| `Given` | Set up preconditions | Optional |
| `When` | Describe the action | Recommended |
| `Then` | Define expected outcomes | Recommended |
### Secondary Keywords
| Keyword | Purpose |
|---------|---------|
| `And` | Continue the previous step type |
| `But` | Negative continuation of previous step type |
| `Background` | Steps run before each scenario |
| `Scenario Outline` | Template for parameterized scenarios |
| `Examples` | Data table for Scenario Outline |
| `Rule` | Group scenarios under a business rule (Gherkin 6+) |
### Supplementary Keywords
| Keyword | Purpose |
|---------|---------|
| `@tag` | Tag features or scenarios for filtering |
| `#` | Comments |
| `"""` | Doc strings (multi-line text) |
| `\|` | Data table delimiter |
---
## Feature
```gherkin
Feature: [Feature Name]
  As a [role]
  I want [goal]
  So that [benefit]
```
---
## Scenario
```gherkin
Scenario: Add single item to empty cart
  Given the shopping cart is empty
  When I add "Blue T-Shirt" to the cart
  Then the cart contains 1 item
  And the cart total is $19.99
```
---
## Steps: Given, When, Then, And, But
```gherkin
Given the user is logged in
And the user has admin privileges
But the user has not verified their email
When the user submits the form
Then the record is created
And an audit log entry is added
But no notification is sent
```
---
## Background
Steps that run before each scenario.
```gherkin
Background:
  Given the user is logged in
  And the user is on the account settings page
```
**Note:** Background runs before EACH scenario, not once per feature.
---
## Scenario Outline
```gherkin
Scenario Outline: Validate login credentials
  Given a user with username "<username>" and password "<password>"
  When the user attempts to login
  Then the result is "<result>"

  Examples:
    | username | password | result  |
    | alice    | correct  | success |
    | alice    | wrong    | failure |
```
### Multiple Example Tables
```gherkin
  Examples: Domestic
    | weight | destination | cost  |
    | 1      | NYC         | 5.00  |

  Examples: International
    | weight | destination | cost   |
    | 1      | London      | 25.00  |
```
---
## Data Tables
```gherkin
Given the following users exist:
  | username | email              | role  |
  | alice    | alice@example.com  | admin |
  | bob      | bob@example.com    | user  |
```
**Single column:** List of values
**Key-value:** Two columns, first is key
---
## Doc Strings
```gherkin
When I send the following JSON:
  """json
  {
    "name": "Test Product",
    "price": 19.99
  }
  """
```
---
## Tags
```gherkin
@smoke @authentication
Feature: User Login

  @critical
  Scenario: Successful login
```
**Running tagged scenarios:**
```bash
cucumber-js --tags "@smoke"
cucumber-js --tags "@smoke and not @wip"
pytest -m "smoke"
```
### Common Tag Patterns
| Tag | Purpose |
|-----|---------|
| `@smoke` | Quick sanity tests |
| `@regression` | Full regression suite |
| `@wip` | Work in progress (skip) |
| `@critical` | Critical path tests |
---
## Rule (Gherkin 6+)
```gherkin
Feature: Account Overdraft

  Rule: Overdraft is allowed up to $500
    Scenario: Withdraw within overdraft limit
      Given my balance is $100
      When I withdraw $500
      Then the transaction succeeds
```
---
## Language Support
```gherkin
# language: fr
Fonctionnalite: Panier d'achat
```
---
## Best Practices
1. **One feature per file**
2. **Descriptive scenario names** - self-documenting
3. **3-7 steps per scenario**
4. **Use Background sparingly** - only for true shared setup
5. **Prefer Scenario Outline** for data-driven tests
6. **Use tags consistently**
---
**End of Gherkin Syntax Reference**

---
name: bdd-writing
description: Guide developers on writing BDD specifications using Gherkin syntax, feature files, and step definitions
version: "0.55.0"
license: Complete terms in LICENSE.txt
---
# BDD Writing
## When to Use
- Writing acceptance criteria as executable specifications
- Creating feature files for new functionality
- Defining step definitions for scenarios
- Organizing BDD test suites
- Integrating BDD with TDD workflow
- Gherkin syntax questions
- Tool selection guidance (Cucumber, pytest-bdd, etc.)
---
## Gherkin Syntax
### Core Keywords
| Keyword | Purpose | Example |
|---------|---------|---------|
| **Feature** | Groups related scenarios | `Feature: User Authentication` |
| **Scenario** | Single test case | `Scenario: Successful login` |
| **Given** | Preconditions/context | `Given a registered user exists` |
| **When** | Action/event | `When the user submits credentials` |
| **Then** | Expected outcome | `Then they see the dashboard` |
| **And** | Continue previous step type | `And they see a welcome message` |
| **But** | Negative continuation | `But they don't see admin menu` |
| **Background** | Shared setup for all scenarios | Runs before each scenario |
| **Scenario Outline** | Parameterized scenarios | Data-driven tests |
| **Examples** | Data table for outlines | Test data variations |
### Basic Feature File
```gherkin
Feature: User Authentication
  As a registered user
  I want to log into the system
  So that I can access my account

  Background:
    Given the login page is displayed

  Scenario: Successful login with valid credentials
    Given a user "alice" exists with password "secret123"
    When the user enters username "alice"
    And the user enters password "secret123"
    And the user clicks the login button
    Then the user sees the dashboard

  Scenario: Failed login with wrong password
    Given a user "alice" exists with password "secret123"
    When the user enters username "alice"
    And the user enters password "wrongpassword"
    And the user clicks the login button
    Then the user sees an error message "Invalid credentials"
    But the user remains on the login page
```
### Scenario Outline (Parameterized)
```gherkin
Scenario Outline: Login with various credentials
  Given a user "<username>" exists with password "<password>"
  When the user attempts to login with "<input_user>" and "<input_pass>"
  Then the result is "<outcome>"

  Examples:
    | username | password  | input_user | input_pass | outcome |
    | alice    | secret123 | alice      | secret123  | success |
    | alice    | secret123 | alice      | wrong      | failure |
```
### Data Tables
```gherkin
Scenario: Create multiple users
  Given the following users exist:
    | username | email            | role  |
    | alice    | alice@example.com| admin |
    | bob      | bob@example.com  | user  |
  When I view the user list
  Then I see 2 users
```
### Doc Strings
```gherkin
When I create a post with content:
  """
  # Welcome to My Blog
  This is my first post.
  """
```
---
## Step Definitions
### JavaScript (Cucumber.js)
```javascript
const { Given, When, Then } = require('@cucumber/cucumber');
Given('a user {string} exists with password {string}', async (username, password) => {
  await createUser(username, password);
});
When('the user enters username {string}', async (username) => {
  await enterUsername(username);
});
Then('the user sees the dashboard', async () => {
  await expect(page).toHaveURL('/dashboard');
});
```
See `resources/step-definition-patterns.md` for Python and Java examples.
### Best Practices
1. **Keep steps reusable** - parameterize instead of duplicating
2. **Use parameters** - single definition handles multiple cases
3. **Declarative over imperative** - `Given the user is logged in` not individual UI steps
---
## Writing Good Scenarios
| Do | Don't |
|----|-------|
| One behavior per scenario | Multiple behaviors per scenario |
| Use business language | Use technical jargon |
| Keep scenarios short (3-7 steps) | Write long scenarios (10+ steps) |
| Make scenarios independent | Create dependencies between scenarios |
| Focus on behavior | Focus on UI mechanics |
---
## Anti-Patterns to Avoid
1. **UI-Focused Steps** - Test behavior, not `click button with id "submit-btn"`
2. **Too Many Steps** - Split into focused scenarios
3. **Coupled Steps** - Self-contained: `When the user "alice" logs in`
4. **Inconsistent Language** - Use same term throughout (user, not customer/client)
---
## BDD + TDD Integration (Double Loop)
```
┌─────────────────────────────────────────────────────────┐
│  OUTER LOOP: BDD (Acceptance Tests)                     │
│                                                         │
│  1. Write failing acceptance scenario                   │
│                                                         │
│  ┌─────────────────────────────────────────────────┐    │
│  │  INNER LOOP: TDD (Unit Tests)                   │    │
│  │                                                 │    │
│  │  2. RED: Write failing unit test                │    │
│  │  3. GREEN: Write minimal code to pass           │    │
│  │  4. REFACTOR: Improve code quality              │    │
│  │  5. Repeat until feature complete               │    │
│  │                                                 │    │
│  └─────────────────────────────────────────────────┘    │
│                                                         │
│  6. Acceptance scenario passes                          │
│  7. Move to next scenario                               │
│                                                         │
└─────────────────────────────────────────────────────────┘
```
---
## Tool Selection Guide
| Tool | Language | Best For |
|------|----------|----------|
| **Cucumber** | JS, Java, Ruby | Most popular, multi-language |
| **pytest-bdd** | Python | Python projects, pytest integration |
| **SpecFlow** | C#/.NET | .NET ecosystem |
| **Behave** | Python | Python alternative to pytest-bdd |
| **RSpec** | Ruby | Ruby with BDD-style syntax |
| **Karate** | Java | API testing with BDD |
### Quick Selection
```
Python project?
├── Using pytest? -> pytest-bdd
└── Not using pytest? -> Behave
JavaScript project? -> Cucumber.js
Java project?
├── API testing focus? -> Karate
└── General BDD? -> Cucumber-JVM
.NET project? -> SpecFlow
Ruby project? -> Cucumber or RSpec
```
---
## Feature Organization
```
features/
├── authentication/
│   ├── login.feature
│   └── password_reset.feature
├── orders/
│   ├── create_order.feature
│   └── order_history.feature
└── support/
    ├── step_definitions/
    │   └── auth_steps.js
    └── hooks.js
```
---
## Resources
- [Gherkin Syntax](resources/gherkin-syntax.md)
- [Feature File Template](resources/feature-file-template.md)
- [Step Definition Patterns](resources/step-definition-patterns.md)
- [Tool Comparison](resources/tool-comparison.md)
## Related
- `test-writing-patterns` - BDD is an alternative test structure (Given-When-Then vs AAA)
- `tdd-red-phase` - BDD scenarios drive the outer TDD loop
- `beginner-testing` - BDD is accessible to beginners
- IDPF-Agile - BDD for user story validation and acceptance criteria verification
---
**End of BDD Writing Skill**

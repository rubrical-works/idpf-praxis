# Framework Examples
**Version:** 0.52.0
## Python - mutmut
```bash
pip install mutmut
mutmut run          # Run mutation testing
mutmut results      # View results
mutmut show 42      # View specific mutant
mutmut html         # Generate HTML report
```
### Configuration
```toml
# pyproject.toml
[tool.mutmut]
paths_to_mutate = "src/"
tests_dir = "tests/"
runner = "pytest"
```
### CI Integration
```yaml
- name: Run mutation tests
  run: |
    pip install mutmut
    mutmut run --CI
    mutmut results
```
## JavaScript - Stryker
```bash
npm install --save-dev @stryker-mutator/core @stryker-mutator/jest-runner
npx stryker init    # Interactive setup
npx stryker run     # Run
```
### Configuration
```json
{
  "testRunner": "jest",
  "coverageAnalysis": "perTest",
  "mutate": ["src/**/*.js", "!src/**/*.test.js"]
}
```
### CI Integration
```yaml
- run: npm ci
- run: npx stryker run
- uses: actions/upload-artifact@v3
  with: { name: mutation-report, path: reports/mutation/ }
```
## Java - PIT (Pitest)
### Maven
```xml
<plugin>
    <groupId>org.pitest</groupId>
    <artifactId>pitest-maven</artifactId>
    <version>1.15.0</version>
    <configuration>
        <targetClasses><param>com.example.*</param></targetClasses>
        <targetTests><param>com.example.*Test</param></targetTests>
        <mutationThreshold>75</mutationThreshold>
    </configuration>
</plugin>
```
### Gradle
```groovy
plugins { id 'info.solidsoft.pitest' version '1.15.0' }
pitest {
    targetClasses = ['com.example.*']
    mutationThreshold = 75
    outputFormats = ['HTML', 'XML']
}
```
```bash
mvn org.pitest:pitest-maven:mutationCoverage   # Maven
./gradlew pitest                                 # Gradle
```
## C# - Stryker.NET
```bash
dotnet tool install -g dotnet-stryker
dotnet stryker
```
```json
{ "stryker-config": {
    "solution": "MySolution.sln", "project": "MyProject.csproj",
    "threshold-high": 80, "threshold-low": 60, "threshold-break": 50
} }
```
## Ruby - mutant
```bash
gem install mutant mutant-rspec
bundle exec mutant run --include lib --require my_gem --use rspec MyGem*
```
## Framework Comparison
| Feature | mutmut | Stryker (JS) | PIT | Stryker.NET | mutant |
|---------|--------|--------------|-----|-------------|--------|
| Language | Python | JS/TS | Java | C# | Ruby |
| Setup | Easy | Easy | Medium | Easy | Medium |
| Speed | Medium | Fast | Fast | Medium | Slow |
| Reporting | Basic | Excellent | Good | Excellent | Good |
| CI Support | Good | Excellent | Excellent | Excellent | Good |
## Common Configuration Patterns
### Excluding Files
```javascript
// Stryker
{ "mutate": ["src/**/*.js", "!src/**/*.test.js", "!src/generated/**"] }
```
```xml
<!-- PIT -->
<excludedClasses><param>com.example.generated.*</param></excludedClasses>
```
### Setting Thresholds
```javascript
{ "thresholds": { "high": 80, "low": 60, "break": 50 } }
```
---
**See SKILL.md for complete mutation testing guidance**

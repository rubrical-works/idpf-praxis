---
name: mutation-testing
description: Guide developers through mutation testing to assess and improve test suite quality
version: "0.52.0"
license: Complete terms in LICENSE.txt
---
# Mutation Testing
## When to Use
- Assessing test suite quality beyond code coverage
- Identifying weak spots in test coverage
- Evaluating whether tests are meaningful
- Improving test effectiveness
## Key Terms
- **Mutant:** Modified version of code with one small change
- **Killed Mutant:** Detected by at least one failing test
- **Survived Mutant:** Not detected (tests still pass)
- **Equivalent Mutant:** Behaves identically to original (cannot be killed)
- **Mutation Score:** `killed / (total - equivalent) * 100%`
## Why Mutation Testing?
```python
# 100% coverage but weak test
def calculate_discount(price, is_member):
    if is_member: return price * 0.9
    return price

def test_discount():
    assert calculate_discount(100, True) is not None  # Weak!
# Mutation: 0.9 -> 0.8 still passes -> reveals test doesn't check value
```
## Mutation Operators
### Arithmetic
| Original | Mutated |
|----------|---------|
| `+` | `-` |
| `*` | `/` |
### Relational
| Original | Mutated |
|----------|---------|
| `<` | `<=` |
| `>` | `>=` |
| `==` | `!=` |
### Logical/Constant/Statement
| Type | Example |
|------|---------|
| `and` -> `or` | Logical replacement |
| `0` -> `1`, `true` -> `false` | Constant replacement |
| Statement deletion | Remove `x = x + 1` |
| Return value change | `return x` -> `return 0` |
See `resources/operator-guide.md` for comprehensive reference.
## Understanding Mutation Score
| Score | Interpretation |
|-------|----------------|
| 90-100% | Excellent |
| 75-89% | Good |
| 60-74% | Acceptable, room for improvement |
| Below 60% | Weak, needs attention |
**Score targets by risk:** High-risk (payment, auth): 90%+. Standard (business logic): 75%+. Low-risk (logging): 60%+.
See `resources/score-interpretation.md` for detailed analysis.
## Analyzing Survived Mutants
1. **Review:** What changed? (e.g., `>` to `>=`)
2. **Understand:** What behavior changes? Is this case tested?
3. **Decide:** Add test, mark as equivalent, or accept risk
**Common patterns:** Missing boundary tests, missing error case tests, missing assertions on return values.
## Equivalent Mutants
```python
def max(a, b):
    if a >= b:  # EQUIVALENT when a == b - same behavior as a > b
        return a
    return b
```
**Handling:** Mark in tool, configure skip patterns, accept score impact.
## Integration Workflow
**CI:** On PRs (subset/changed files), nightly full runs, before releases.
**Local:** Specific modules, before feature complete.
**Optimization:** Limit scope, parallel execution, incremental analysis, sampling.
```yaml
mutation:
  target: src/
  tests: tests/
  timeout_factor: 2.0
  parallel: 4
  skip_patterns: ["**/generated/**", "**/migrations/**"]
```
## Framework Quick Reference
| Language | Tool | Install |
|----------|------|---------|
| Python | mutmut | `pip install mutmut` then `mutmut run` |
| JavaScript | Stryker | `npm install @stryker-mutator/core` then `npx stryker run` |
| Java | PIT | Maven plugin, `mvn org.pitest:pitest-maven:mutationCoverage` |
| C# | Stryker.NET | `dotnet tool install -g dotnet-stryker` |
| Ruby | mutant | `gem install mutant` |
See `resources/framework-examples.md` for detailed setup and CI integration.
## Best Practices
1. **Start small:** Critical modules first, expand gradually
2. **Realistic goals:** Baseline first, incremental +5% targets
3. **Systematic survivors:** Equivalent? Mark. Test missing? Add. Acceptable risk? Document.
4. **CI integration:** Run on PRs (limited), block on regression
5. **Balance cost/value:** Prioritize critical code, use sampling
## Common Pitfalls
| Pitfall | Solution |
|---------|----------|
| Running on everything | Target specific modules, incremental |
| Ignoring equivalents | Review survivors, mark properly |
| Tests just to kill mutants | Understand behavior change, test that |
| Over-testing edge cases | Focus on meaningful mutations |
## Resources
See `resources/` for:
- `operator-guide.md` - Mutation operator reference
- `score-interpretation.md` - Understanding and improving scores
- `framework-examples.md` - Framework-specific setup
## Relationship to Other Skills
**Complements:** `property-based-testing`, `test-writing-patterns`, `tdd-refactor-phase`
## Expected Outcome
- Mutation testing configured
- Initial score established
- Survived mutants analyzed
- Tests improved for meaningful mutants
- CI integration planned
---
**End of Mutation Testing Skill**

# Mutation Operator Guide
**Version:** 0.52.0
## Operator Categories
### 1. Arithmetic Operator Replacement (AOR)
| Original | Mutations |
|----------|-----------|
| `+` | `-`, `*`, `/`, `%` |
| `-` | `+`, `*`, `/`, `%` |
| `*` | `+`, `-`, `/`, `%` |
| `/` | `+`, `-`, `*`, `%` |
| `%` | `+`, `-`, `*`, `/` |
### 2. Relational Operator Replacement (ROR)
| Original | Mutations |
|----------|-----------|
| `<` | `<=`, `>`, `>=`, `==`, `!=` |
| `<=` | `<`, `>`, `>=`, `==`, `!=` |
| `>` | `<`, `<=`, `>=`, `==`, `!=` |
| `>=` | `<`, `<=`, `>`, `==`, `!=` |
| `==` | `!=`, `<`, `<=`, `>`, `>=` |
| `!=` | `==`, `<`, `<=`, `>`, `>=` |
### 3. Logical Operator Replacement (LOR)
| Original | Mutation |
|----------|----------|
| `and` / `&&` | `or` / `\|\|` |
| `or` / `\|\|` | `and` / `&&` |
### 4. Logical Negation Insertion (LNI)
`x` -> `not x`, `not x` -> `x`
### 5. Conditional Operator Replacement (COR)
`condition ? a : b` -> `true ? a : b`, `false ? a : b`, `condition ? b : a`
### 6. Statement Deletion (SDL)
Remove: assignments, method calls, return statements.
### 7. Constant Replacement (CR)
| Original | Mutations |
|----------|-----------|
| `0` | `1`, `-1` |
| `1` | `0`, `2`, `-1` |
| `true` | `false` |
| `""` | `"mutant"` |
| `null` | Non-null value |
### 8. Increment/Decrement Replacement (IDR)
`++x` -> `--x` or `x`, `x++` -> `x--` or `x`
### 9. Return Value Replacement (RVR)
| Return Type | Mutations |
|-------------|-----------|
| `int` | `0`, `1`, `-1` |
| `boolean` | `true`, `false`, `!original` |
| `object` | `null` |
| `string` | `""`, `"mutant"` |
### 10. Void Method Call Removal (VMC)
Remove calls to void methods (logging, validation, notification).
## Language-Specific Operators
### Python
| Operator | Example |
|----------|---------|
| Decorator removal | `@cache` -> removed |
| Exception handling | `except ValueError` -> `except Exception` |
| Comprehension | `[x for x in items]` -> `[x for x in items if False]` |
### JavaScript
| Operator | Example |
|----------|---------|
| `===` to `==` | Strict to loose equality |
| Optional chaining | `obj?.prop` -> `obj.prop` |
| Nullish coalescing | `a ?? b` -> `a \|\| b` |
### Java
| Operator | Example |
|----------|---------|
| Access modifier | `private` -> `public` |
| Static removal | `static method` -> `method` |
| Final removal | `final x` -> `x` |
## Operator Selection Strategy
1. **Start with:** Relational, logical, constant replacement (highest bug-finding)
2. **Add gradually:** Arithmetic, statement deletion, return value
3. **Use sparingly:** Increment/decrement, void method removal (many equivalents)
## Operator Effectiveness
| Operator | Effectiveness | Common Finding |
|----------|---------------|----------------|
| ROR | Very High | Missing boundary tests |
| LOR | High | Logic errors |
| CR | High | Off-by-one errors |
| AOR | Medium | Arithmetic bugs |
| SDL | Medium | Missing assertions |
| RVR | Medium | Return value testing |
## Reducing Equivalent Mutants
Operators prone to equivalents: statement deletion (logging), increment/decrement in loops, return value in dead code.
```yaml
operators: [relational, logical, conditional]
exclude_operators: [increment_decrement]
```
---
**See SKILL.md for complete mutation testing guidance**

# Mutation Score Interpretation
**Version:** 0.52.0
## Score Formula
```
Mutation Score = Killed / (Total - Equivalent) * 100%
```
## Score Benchmarks
| Score Range | Quality | Action |
|-------------|---------|--------|
| 90-100% | Excellent | Maintain |
| 80-89% | Very Good | Minor improvements |
| 70-79% | Good | Review survivors |
| 60-69% | Acceptable | Targeted improvements |
| 50-59% | Weak | Significant gaps |
| Below 50% | Poor | Major issues |
### Target by Risk Level
- **Critical** (auth, payment, security): 90%+
- **Core business logic** (domain, API, rules): 80%+
- **Standard** (CRUD, config): 70%+
- **Low-risk** (logging, debug): 60%+
## Categories of Survived Mutants
| Category | Example | Action |
|----------|---------|--------|
| Missing test case | `>` to `>=`, no test for boundary | Add boundary test |
| Weak assertion | Test checks `is not None` instead of value | Assert on actual value |
| Equivalent mutant | Commutative swap, same behavior | Mark as equivalent |
| Dead code | Unreachable statement changed | Remove dead code |
| Acceptable risk | Log message changed | Document as acceptable |
### Prioritizing Survivors
- **High:** Critical code paths, missing assertions, frequently changed code
- **Medium:** Business logic, boundary tests, error handling
- **Low:** Logging/debug, equivalents, acceptable risk areas
## Improving Your Score
### Strategy 1: Strengthen Assertions
```python
# Weak: assert result is not None
# Strong: assert result == 90
```
### Strategy 2: Add Boundary Tests
```python
# Before: test 25 (well over) and 10 (well under)
# After: also test 18 (exactly at boundary) and 17 (just under)
```
### Strategy 3: Test Error Paths
```python
# Before: assert divide(10, 2) == 5
# After: also test pytest.raises(ValueError) for divide(10, 0)
```
## Score Trends
| Metric | Good Trend | Warning Sign |
|--------|------------|--------------|
| Score | Stable or increasing | Decreasing |
| New survivors | Few per release | Many per release |
| Time to kill | Stable | Increasing |
### CI Integration
```yaml
mutation_testing:
  threshold: 75
  fail_on_regression: true
  allow_decrease: 2%
```
## Common Score Issues
| Issue | Causes | Solutions |
|-------|--------|----------|
| Won't rise above 80% | Many equivalents, testing implementation not behavior | Mark equivalents, behavior-driven tests, integration tests |
| Drops after refactoring | Tests coupled to implementation | Update tests for behavior, add tests for new code |
| High score but bugs found | Missing integration, operator gaps | Add integration tests, property-based testing |
## Setting Score Goals
**New projects:** Establish baseline -> +5%/month -> reach target (75%) -> maintain.
**Legacy projects:** Baseline -> critical paths (60%) -> business logic (70%) -> comprehensive (80%) -> maintain.
---
**See SKILL.md for complete mutation testing guidance**

# JavaScript Anti-Patterns
**Version:** 0.52.0
Common anti-patterns specific to JavaScript and TypeScript development.
---
## Callback Hell
Deeply nested callbacks. **Refactoring:** async/await
```javascript
async function processUserOrder(userId) {
    try {
        const user = await getUser(userId);
        const orders = await getOrders(user.id);
        const details = await getOrderDetails(orders[0].id);
        return await updateInventory(details);
    } catch (err) { handleError(err); }
}
```
**Severity:** High
---
## Implicit Type Coercion Reliance
Using `==` instead of `===`, truthy/falsy edge cases.
**Refactoring:** Strict equality, explicit type checks, nullish coalescing (`??`)
```javascript
function getItems(items) { return items ?? []; }
```
**Severity:** Medium
---
## Polluting Global Scope
Variables without `let`/`const`, name collisions between files.
**Refactoring:** Always declare variables, use modules, enable strict mode.
**Severity:** High
---
## Memory Leaks
Event listeners not removed, closures holding references, growing arrays.
**Refactoring:**
- Clean up event listeners in destroy()
- Don't capture unnecessary data in closures
- Use WeakMap/WeakSet for object caches
- Set references to null after DOM removal
**Severity:** High
---
## Blocking the Event Loop
Synchronous operations blocking the main thread.
**Refactoring:** Async file ops (`fs.promises`), chunk processing with yields, Web Workers, async requests
**Severity:** High
---
## Promise Anti-Patterns
Wrapping existing promises, nesting instead of chaining, forgetting `await`, no `.catch()`, sequential when parallel possible.
**Refactoring:**
```javascript
// Don't wrap existing promises
function getUser(id) { return fetchUser(id); }
// Parallel execution
const [user, settings] = await Promise.all([getUser(id), getSettings(id)]);
```
**Severity:** High
---
## this Binding Issues
Losing `this` context in callbacks and event handlers.
**Refactoring:** Arrow function in class field (recommended), bind in constructor, or arrow wrapper at call site
```javascript
class Counter {
    count = 0;
    increment = () => { this.count++; };
}
```
**Severity:** Medium
---
## Mutation of Shared State
Modifying objects passed around or shared.
**Refactoring:** Create new objects with spread, `Object.freeze`, Immer
```javascript
function addDefaults(config) {
    return { timeout: 5000, retries: 3, ...config };
}
```
**Severity:** High
---
## Inefficient DOM Operations
Multiple DOM updates causing reflows, layout thrashing.
**Refactoring:** DocumentFragment for batching, batch reads then writes, build HTML string then set once.
**Severity:** Medium
---
## typeof null Trap
`typeof null === 'object'` causes null pointer exceptions.
**Refactoring:** `if (typeof value === 'object' && value !== null)` or optional chaining `value?.property`
**Severity:** Medium
---
## Detection Checklist
- [ ] Deeply nested callbacks (>3 levels)
- [ ] `==` instead of `===` comparisons
- [ ] Variables without `let`/`const`/`var` declaration
- [ ] Event listeners never removed
- [ ] Synchronous operations blocking main thread
- [ ] Promises without `.catch()` or try/catch
- [ ] Methods used as callbacks without binding
- [ ] Objects/arrays mutated instead of cloned
- [ ] DOM operations inside loops
- [ ] Type checks not accounting for `null`
---
**End of JavaScript Anti-Patterns**

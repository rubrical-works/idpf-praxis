# Code Review Checklist
**Version:** 0.53.1
Structured checklist for systematic anti-pattern detection during code reviews.
---
## How to Use
1. **Before Review**: Identify change type (feature, bugfix, refactor)
2. **During Review**: Work through relevant sections
3. **Document Findings**: Note severity and location
4. **Suggest Fixes**: Provide specific refactoring guidance
---
## Quick Scan (All Reviews)
### Critical Issues (Block Merge)
- [ ] No hardcoded secrets, API keys, or credentials
- [ ] No SQL string concatenation (injection risk)
- [ ] No unvalidated user input used directly
- [ ] No obvious N+1 query patterns in loops
- [ ] Tests are not flaky (deterministic)
### High Priority (Should Fix)
- [ ] No God objects (>500 lines or >10 public methods)
- [ ] No circular dependencies introduced
- [ ] No copy-pasted code blocks (>10 lines duplicated)
- [ ] Transactions used for multi-step database operations
- [ ] Tests are independent (can run in any order)
### Medium Priority (Create Issue)
- [ ] No methods >30 lines
- [ ] No nesting >3 levels deep
- [ ] No magic numbers (use named constants)
- [ ] No commented-out code
- [ ] Error cases handled, not just happy path
---
## Design Review Checklist
### Single Responsibility
- [ ] Each class has one reason to change
- [ ] Methods do one thing
- [ ] No "Manager" or "Handler" classes doing everything
### Dependencies
- [ ] No circular dependencies between modules
- [ ] Dependencies flow in one direction
- [ ] External dependencies isolated (can mock/swap)
### Coupling & Cohesion
- [ ] Related code is grouped together
- [ ] Changes don't require shotgun surgery
- [ ] Public interfaces are minimal
---
## Code Quality Checklist
### Readability
- [ ] Names clearly express intent
- [ ] No overly generic names (data, info, temp, result)
- [ ] Comments explain "why" not "what"
### Complexity
- [ ] Methods are <30 lines
- [ ] Nesting is <4 levels
- [ ] Guard clauses used instead of deep nesting
### Duplication
- [ ] No copy-pasted code blocks
- [ ] DRY principle followed (but not over-abstracted)
### Error Handling
- [ ] No swallowed exceptions
- [ ] Error messages are helpful (not stack traces to users)
---
## Database Checklist
- [ ] No SELECT * in production code
- [ ] No N+1 queries (check loops with DB calls)
- [ ] Indexes exist for WHERE/JOIN/ORDER BY columns
- [ ] Transactions wrap multi-step operations
- [ ] Parameterized queries used (no string concat)
- [ ] Pagination used for large result sets
---
## Testing Checklist
- [ ] Tests are deterministic
- [ ] Tests are independent (no order dependency)
- [ ] Tests have clear arrange/act/assert structure
- [ ] Happy path and error/edge cases tested
- [ ] Not over-mocked (testing real behavior)
- [ ] Test pyramid followed (more unit, fewer E2E)
---
## Security Checklist
- [ ] All user input validated at system boundary
- [ ] Auth required on all endpoints that need it
- [ ] Sensitive data not logged
- [ ] Secrets managed properly (not in code)
- [ ] No stack traces exposed to users
---
## Review Severity Guide
| Severity | Examples | Action |
|----------|----------|--------|
| **Critical** | Security vulnerability, data loss risk | Block merge, fix immediately |
| **High** | N+1 queries, God object, missing transactions | Should fix before merge |
| **Medium** | Long method, magic numbers, missing edge case tests | Create follow-up issue |
| **Low** | Naming improvement, minor optimization | Optional |
---
## Review Comment Templates
### Requesting Change
```
**Issue:** [Brief description]
**Location:** [file:line]
**Severity:** [Critical/High/Medium/Low]
**Suggestion:** [How to fix]
```
### Non-blocking Suggestion
```
**Suggestion (optional):** [Description]
This would improve [readability/performance/maintainability] but isn't blocking.
```
---
**End of Code Review Checklist**

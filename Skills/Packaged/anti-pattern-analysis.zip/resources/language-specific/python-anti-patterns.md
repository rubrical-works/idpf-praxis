# Python Anti-Patterns
**Version:** {{VERSION}}
Common anti-patterns specific to Python development.
---
## Mutable Default Arguments
Using mutable objects (list, dict) as default function arguments. Accumulates values across calls.
**Refactoring:**
```python
def add_item(item, items=None):
    if items is None:
        items = []
    items.append(item)
    return items
```
**Severity:** High
---
## Bare Except Clause
Catching all exceptions without specifying type. Swallows KeyboardInterrupt, SystemExit.
**Refactoring:** Catch specific exceptions, log and re-raise if broad catch needed
```python
except ValueError as e:
    logger.error(f"Invalid value: {e}")
    result = default_value
```
**Severity:** High
---
## Not Using Context Managers
Manual resource management. Resources not closed on exceptions.
**Refactoring:**
```python
with open('data.txt', 'r') as f:
    data = f.read()
```
**Severity:** High
---
## Type Checking with type()
Using `type()` instead of `isinstance()`. Doesn't work with inheritance.
**Refactoring:** `isinstance(value, dict)` or duck typing with try/except
**Severity:** Medium
---
## String Concatenation in Loops
O(n^2) performance building strings with `+` in loops.
**Refactoring:** `", ".join(str(item) for item in large_list)`
**Severity:** Medium
---
## Using range(len()) for Iteration
**Refactoring:**
- `for item in items:` (direct)
- `for i, item in enumerate(items):` (with index)
- `for a, b in zip(list1, list2):` (parallel)

**Severity:** Low
---
## Not Using Comprehensions
Verbose loops for simple transformations.
**Refactoring:** `squares = [x ** 2 for x in range(10)]`, dict/set comprehensions, generator expressions
**Severity:** Low
---
## Circular Imports
Modules importing each other causing `ImportError`.
**Refactoring:** Import inside function, restructure dependencies, or `TYPE_CHECKING` for type hints only
**Severity:** High
---
## Using *args/**kwargs Incorrectly
Unclear function signatures, no IDE autocomplete.
**Refactoring:** Explicit parameters with type hints. Document when kwargs necessary.
**Severity:** Medium
---
## Global Variables
Functions depending on external state. Hard to test, race conditions.
**Refactoring:** Dependency injection
```python
class UserRepository:
    def __init__(self, db_connection):
        self.db = db_connection
```
**Severity:** High
---
## Not Using Dataclasses
Writing boilerplate `__init__`, `__repr__`, `__eq__` for data containers.
**Refactoring:** `@dataclass` decorator auto-generates these methods
**Severity:** Low
---
## Print Statement Debugging
**Refactoring:** Use `logging` module with proper levels, `breakpoint()` for debugging
**Severity:** Low
---
## Detection Checklist
- [ ] Default arguments that are mutable (list, dict, set)
- [ ] Bare `except:` or `except Exception:`
- [ ] `open()` without `with` statement
- [ ] `type(x) == SomeType` instead of `isinstance()`
- [ ] String concatenation with `+` in loops
- [ ] `for i in range(len(items))` patterns
- [ ] Loops that could be comprehensions
- [ ] Circular import errors
- [ ] Functions accepting `**kwargs` with unclear valid keys
- [ ] Global variables for configuration/state
- [ ] Data classes with manual `__init__`, `__repr__`, `__eq__`
- [ ] Print statements instead of logging
---
**End of Python Anti-Patterns**

# Database Anti-Patterns
**Version:** 0.53.1
SQL, ORM, and data access issues affecting performance and maintainability.
---
## N+1 Query Problem
Executing N additional queries for N results.
**Symptoms:** Slow page loads, query count grows with data, "works in dev, slow in production"
**Refactoring:**
```python
# Django - prefetch
users = User.objects.prefetch_related('orders').all()
# Or annotation
users = User.objects.annotate(order_count=Count('orders'))
# SQLAlchemy - eager loading
users = session.query(User).options(joinedload(User.orders)).all()
```
**Severity:** Critical
---
## SELECT * Anti-Pattern
Fetching all columns when only some needed.
**Refactoring:** `SELECT id, name, email FROM users WHERE status = 'active';`
ORM: `.only('id', 'name', 'email')`
**Severity:** Medium
---
## Implicit Column Insert
INSERT without explicit column list. Breaks on schema changes.
**Refactoring:** Always specify columns.
**Severity:** Medium
---
## Missing Indexes
Frequently queried columns without indexes.
**Detection:** `EXPLAIN ANALYZE` - look for "Seq Scan" on large tables
**Refactoring:**
```sql
CREATE INDEX idx_users_email ON users(email);
CREATE INDEX idx_orders_user_status ON orders(user_id, status);
```
**Severity:** High
---
## Entity-Attribute-Value (EAV)
Storing attributes as rows instead of columns.
**Refactoring:** Proper relational design. For truly dynamic attributes, use JSONB.
**When acceptable:** User-defined custom fields, product variants, survey responses
**Severity:** High
---
## Soft Deletes Everywhere
Every query needs `WHERE deleted_at IS NULL`.
**Refactoring:** Custom manager with default filter, archive table, or soft delete only where required (compliance)
**Severity:** Medium
---
## God Table
50+ columns, many NULLs, different entity types in one table.
**Refactoring:** Separate tables per entity type.
**Severity:** High
---
## String Concatenation for SQL
SQL injection vulnerability.
**Refactoring:** Parameterized queries or ORM
```python
query = "SELECT * FROM users WHERE email = %s"
db.execute(query, (email,))
```
**Severity:** Critical
---
## No Transaction Management
Multiple operations without transaction boundaries.
**Refactoring:**
```python
with transaction.atomic():
    from_account.balance -= amount
    from_account.save()
    to_account.balance += amount
    to_account.save()
```
**Severity:** High
---
## Storing Lists as Comma-Separated Values
Can't query individually, no referential integrity.
**Refactoring:** Many-to-many relationship table.
**Severity:** High
---
## Over-Normalization
5+ JOINs for simple queries.
**Refactoring:** Denormalize where appropriate.
**Severity:** Medium
---
## Database as Message Queue
Polling tables for jobs causes lock contention.
**Refactoring:** Use proper message queue (Redis, RabbitMQ, SQS).
**Severity:** Medium
---
## Detection Checklist
- [ ] Query count grows with data size (N+1)
- [ ] SELECT * in production queries
- [ ] INSERTs without column lists
- [ ] Full table scans on large tables (Missing Indexes)
- [ ] Pivot queries to extract attributes (EAV)
- [ ] `deleted_at IS NULL` in every query (Soft Deletes)
- [ ] Tables with 30+ columns (God Table)
- [ ] String concatenation building SQL (Injection Risk)
- [ ] Multiple DB operations without transaction
- [ ] Comma-separated values in columns
- [ ] 5+ JOINs for simple data (Over-Normalization)
- [ ] Polling tables for job queues
---
**End of Database Anti-Patterns**

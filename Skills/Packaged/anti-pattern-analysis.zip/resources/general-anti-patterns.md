# General Anti-Patterns
**Version:** 0.53.1
Design and code smell patterns that apply across languages and frameworks.
---
## Design Anti-Patterns
### God Object / God Class
**Symptoms:** >500 lines, >10 public methods, dependencies on many classes, names ending with "Manager"/"Handler"/"Util", unrelated methods
**Refactoring:** Split by responsibility into UserService, AuthService, NotificationService, BillingService
**Severity:** High
---
### Singleton Abuse
**Symptoms:** `getInstance()` scattered throughout, difficult to test, hidden dependencies
**Refactoring:** Dependency injection
```java
public class UserRepository {
    private final DatabaseConnection db;
    public UserRepository(DatabaseConnection db) { this.db = db; }
}
```
**Severity:** Medium
---
### Anemic Domain Model
**Symptoms:** Classes with only getters/setters, all logic in service classes
**Refactoring:** Rich domain model - move behavior into domain objects
```python
class Order:
    @property
    def total(self):
        return sum(item.price for item in self.items)
    def can_ship(self):
        return self.status == "paid" and self.total > 0
```
**Severity:** Medium
---
### Circular Dependency
**Symptoms:** Import errors at runtime, difficult data flow, hard to test
**Refactoring:** Introduce abstraction layer or restructure into separate service module
**Severity:** High
---
### Golden Hammer
**Symptoms:** Same solution for all problems, ignoring better-suited alternatives
**Examples:** Microservices for simple CRUD, NoSQL for relational data, React for static page
**Severity:** Medium
---
## Code Smell Patterns
### Long Method
**Symptoms:** >20-30 lines, multiple abstraction levels, comments separating sections
**Refactoring:** Extract methods
```javascript
function processOrder(order) {
    validateOrder(order);
    const totals = calculateTotals(order);
    const finalTotal = applyDiscounts(totals, order.coupon);
    sendNotification(order, createInvoice(order, finalTotal));
    updateInventory(order.items);
}
```
**Severity:** Medium
---
### Deep Nesting
**Symptoms:** >3 levels of indentation, arrow-shaped code
**Refactoring:** Guard clauses
```python
def process_user(user):
    if not user: return None
    if not user.is_active: return None
    if not user.has_permission('edit'): return None
    return do_something(user)
```
**Severity:** Medium
---
### Magic Numbers/Strings
**Refactoring:** Named constants
```javascript
const ROLE_ADMIN = 2;
const ONE_DAY_MS = 24 * 60 * 60 * 1000;
```
**Severity:** Low
---
### Primitive Obsession
**Refactoring:** Value objects encapsulating validation
```python
class Email:
    def __init__(self, value: str):
        if '@' not in value: raise ValueError('Invalid email')
        self.value = value
```
**Severity:** Medium
---
### Feature Envy
Method accesses many properties of another object, chained property access.
**Refactoring:** Move method to the class it envies.
**Severity:** Medium
---
### Shotgun Surgery
Adding a field requires changes in 5+ files.
**Refactoring:** Consolidate related logic, use code generation, apply DRY.
**Severity:** High
---
### Data Clumps
Same 3+ parameters passed together to multiple methods.
**Refactoring:** Extract a class (e.g., Address for street/city/state/zip).
**Severity:** Medium
---
## Detection Checklist
- [ ] Classes with >500 lines or >10 public methods
- [ ] Singleton pattern used for non-infrastructure concerns
- [ ] Domain classes with only getters/setters
- [ ] Circular imports/dependencies
- [ ] Same tool/pattern used regardless of fit
- [ ] Methods >20-30 lines
- [ ] Nesting >3 levels deep
- [ ] Unexplained literal values
- [ ] Primitives used for domain concepts (email, money, phone)
- [ ] Methods primarily using another class's data
- [ ] Changes requiring edits in many files
- [ ] Same data parameters grouped together repeatedly
---
**End of General Anti-Patterns**

# Testing Anti-Patterns
**Version:** 0.53.1
Issues in test code that reduce effectiveness and maintainability.
---
## Flaky Tests
Pass or fail inconsistently without code changes.
**Causes:** Race conditions, time-dependent logic, external deps, shared state, order dependency
**Refactoring:** Freeze time, deterministic waits, isolate external deps
```python
def test_user_created_recently(frozen_time):
    with frozen_time('2024-01-15 10:00:00'):
        user = create_user()
        assert user.created_at == datetime(2024, 1, 15, 10, 0, 0)
```
**Severity:** Critical
---
## Test Interdependence
Tests depend on other tests running first.
**Refactoring:** Use setup/teardown, each test creates its own data
**Severity:** High
---
## Over-Mocking
Mocking so much the test doesn't test anything real.
**Refactoring:** Use real DB (test instance), real validators. Mock only external services.
**Severity:** High
---
## Testing Implementation Details
Tests break when implementation changes, even if behavior is correct.
**Refactoring:** Test behavior, not implementation
```javascript
// Bad: expect(service._cache.has('John')).toBe(true);
// Good: expect(service.getUser(user.id).name).toBe('John');
```
**Severity:** Medium
---
## Slow Test Suite
**Causes:** Too many E2E tests, real DB for every test, no parallelization, unnecessary waits
**Refactoring:** Follow test pyramid, in-memory DB, parallelize, mock external services
**Severity:** Medium
---
## Test Pollution
Tests leave behind state affecting other tests.
**Refactoring:** Fixtures with autouse cleanup
```python
@pytest.fixture(autouse=True)
def clean_database():
    yield
    User.delete_all()
```
**Severity:** High
---
## Happy Path Only
Only success scenarios tested.
**Refactoring:** Add error cases, edge cases, boundary conditions
**Severity:** Medium
---
## Ice Cream Cone
Inverted test pyramid - more E2E than unit tests.
**Correct Test Pyramid:**
```
        /\
       /  \         E2E (few, slow, expensive)
      /----\
     /      \       Integration (some)
    /--------\
   /          \     Unit (many, fast, cheap)
  /------------\
```
**Severity:** Medium
---
## Excessive Setup
50 lines setup, 2 lines assertion.
**Refactoring:** Fixtures and factories
```python
def test_user_can_checkout(cart_with_items):
    result = checkout(cart_with_items)
    assert result.success
```
**Severity:** Medium
---
## Testing Trivial Code
Tests for getters/setters, simple constructors, framework functionality.
**Refactoring:** Focus on business logic, complex calculations, edge cases.
**Severity:** Low
---
## Detection Checklist
- [ ] Tests fail randomly (Flaky)
- [ ] Tests must run in specific order (Interdependence)
- [ ] More mocks than real code (Over-Mocking)
- [ ] Refactoring breaks tests (Testing Implementation)
- [ ] Test suite takes >10 minutes (Slow)
- [ ] Different results on re-run (Pollution)
- [ ] Only success cases tested (Happy Path Only)
- [ ] More E2E than unit tests (Ice Cream Cone)
- [ ] Setup longer than assertions (Excessive Setup)
- [ ] Tests for getters/setters (Trivial Code)
---
**End of Testing Anti-Patterns**

# Architecture Anti-Patterns
**Version:** 0.53.1
System design and structural issues that affect the overall codebase.
---
## Big Ball of Mud
No discernible architecture. Code grows organically without structure.
**Symptoms:** No module boundaries, everything depends on everything, no separation of concerns
**Refactoring:** Identify natural boundaries, create explicit modules, define clear interfaces, migrate incrementally
**Severity:** Critical
---
## Distributed Monolith
Microservices tightly coupled, requiring coordinated deployments.
**Symptoms:** Shared databases, synchronous cross-service calls, can't deploy independently
```
OrderService --sync--> InventoryService --sync--> PaymentService
                    Shared Database
```
**Refactoring:** Each service owns its data, use async messaging, define clear API contracts
**Severity:** High
---
## Lava Flow
Dead code nobody dares remove.
**Refactoring:** Use code coverage to find dead code, search for usages, git history preserves deleted code
**Severity:** Medium
---
## Boat Anchor
Code kept "just in case." YAGNI - delete unused code, add when needed.
**Severity:** Low
---
## Copy-Paste Programming
Duplicated code blocks instead of shared abstractions.
**Refactoring:** Extract shared function
```javascript
async function findById(table, id, entityName) {
    const result = await db.query(`SELECT * FROM ${table} WHERE id = ?`, [id]);
    if (!result) throw new NotFoundError(`${entityName} not found`);
    return result;
}
const getUser = (id) => findById('users', id, 'User');
```
**Severity:** High
---
## Spaghetti Code
Tangled control flow that's difficult to follow.
**Refactoring:** Extract methods, strategy pattern, state machines, guard clauses
**Severity:** High
---
## Lasagna Code
Too many layers of abstraction. Simple operations pass through 5+ layers.
**Refactoring:** Remove unnecessary layers. Simple CRUD: Controller -> Repository -> Database
**Severity:** Medium
---
## Swiss Army Knife
One interface doing everything (20+ methods).
**Refactoring:** Interface segregation
```java
interface Reader { void read(); }
interface Writer { void write(); }
interface SecureDataProcessor extends Reader, Writer, Encryptor {}
```
**Severity:** Medium
---
## Vendor Lock-in Architecture
System tightly coupled to specific vendor. No abstraction over cloud services.
**Refactoring:** Abstract via interfaces (Database, FileStorage, EventBus)
**Severity:** Medium
---
## Accidental Architecture
Architecture emerged without planning.
**Refactoring:** Document current state (ADRs), define target, incrementally align
**Severity:** Medium
---
## Detection Checklist
- [ ] No clear module boundaries (Big Ball of Mud)
- [ ] Microservices requiring coordinated deploys (Distributed Monolith)
- [ ] Dead code nobody dares remove (Lava Flow)
- [ ] Unused features kept "just in case" (Boat Anchor)
- [ ] Same code blocks copied across codebase (Copy-Paste)
- [ ] Control flow impossible to follow (Spaghetti)
- [ ] Too many layers for simple operations (Lasagna)
- [ ] One interface doing everything (Swiss Army Knife)
- [ ] Vendor SDKs used directly in business logic (Vendor Lock-in)
- [ ] Architecture evolved without deliberate decisions (Accidental)
---
**End of Architecture Anti-Patterns**

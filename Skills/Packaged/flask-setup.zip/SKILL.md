---
name: flask-setup-for-beginners
description: Set up Python Flask development environment for beginners with step-by-step guidance, virtual environment creation, and troubleshooting
version: "0.55.0"
license: Complete terms in LICENSE.txt
---
# Flask Setup for Beginners
## When to Use
- User wants to build a Flask web application
- User is a beginner and needs Flask environment setup
- User asks "How do I set up Flask?" or "How do I start a Flask project?"
- Building a Python web API or Python web server
- Flask tutorial or learning resources needed
## Instructions for ASSISTANT
**CRITICAL:** Format ALL technical instructions as **Claude Code copy/paste blocks**.
**DO NOT** provide manual instructions ("Open File Explorer", "Navigate to folder", "Right-click", "Type in terminal").
**Format as:**
```
TASK: Set up Flask project
STEP 1: Copy this entire code block
STEP 2: Open Claude Code
STEP 3: Paste into Claude Code
STEP 4: Claude Code will execute and report results
STEP 5: Report back: What did Claude Code say?
---
[Instructions for Claude Code to execute:]
cd [project-location]
mkdir [project-name] && cd [project-name]
python --version
python -m venv venv
[continue with commands...]
Report:
- What results did you see?
```
## Setup Steps
### STEP 3: Create Virtual Environment
```bash
python -m venv venv
```
**Wait:** 10-30 seconds. **Verify:** New `venv` folder in project directory.
**Issues:** "python: command not found" -> Install from python.org, check "Add Python to PATH". Try `python3 -m venv venv`.
### STEP 4: Activate Virtual Environment
- **Windows PowerShell:** `venv\Scripts\Activate.ps1`
- **Windows CMD:** `venv\Scripts\activate.bat`
- **Mac/Linux:** `source venv/bin/activate`
**Success:** `(venv)` appears at start of prompt.
**Issues:** "Execution policy error" (Windows): `Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser`
### STEP 5: Install Flask
```bash
pip install flask
```
**Wait:** 30-60 seconds. **Verify:** "Successfully installed flask-X.X.X"
**Issues:** "pip: command not found" -> venv not activated. Permission errors -> activate venv first.
### STEP 6: Create app.py
```
my-project/
├── venv/           <- Virtual environment folder
└── app.py          <- Your main Flask file (create this)
```
**Don't create app.py inside the venv folder!**
### STEP 7: Verify Installation
```bash
python --version                                    # 3.8+ expected
pip list                                            # Should show Flask
python -c "import flask; print(flask.__version__)"  # Should print version
```
## Troubleshooting
See `resources/verification-checklist.md` for detailed troubleshooting.
**Most common issues:**
1. Forgot to activate virtual environment -> Step 4
2. Python not in PATH -> Reinstall with "Add to PATH" checked
3. Wrong directory -> `cd` to project folder
4. Permission errors -> venv not activated
---
**Remember:** Keep the terminal window with `(venv)` open while developing!

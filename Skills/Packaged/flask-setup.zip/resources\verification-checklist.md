# Flask Setup Verification Checklist
**Version:** 0.52.0
## Visual Verification
### 1. Terminal Shows (venv)
```
Correct:   (venv) C:\Projects\my-app>
Wrong:     C:\Projects\my-app>
```
If missing, activate: Windows `venv\Scripts\activate`, Mac/Linux `source venv/bin/activate`
### 2. Project Folder Structure
```
my-project/
├── venv/              <- This folder exists
└── app.py             <- Your code (NOT inside venv/)
```
### 3. Python Version Check
```bash
python --version
```
**Expected:** Python 3.8.0 or higher. If wrong: system Python active, activate venv.
### 4. Flask Installation Check
```bash
pip show flask
```
**Expected:** `Name: Flask`, `Location: .../venv/lib/...`. If "Package not found": run `pip install flask`.
## Command-by-Command Verification
### Test 1: Virtual Environment Active
```bash
which python    # Mac/Linux
where python    # Windows
```
Path should point to `my-project/venv/Scripts/python.exe`, NOT system Python.
### Test 2: Flask Importable
```bash
python -c "import flask; print('Flask works!')"
```
### Test 3: Pip Points to Venv
```bash
pip --version
```
Path should show venv location.
## Common Problems and Solutions
| Problem | Cause | Solution |
|---------|-------|----------|
| `python: command not found` | Not installed or not in PATH | Install from python.org, check "Add to PATH", restart terminal |
| `(venv)` doesn't appear | Venv not activated | Activate per OS (see above) |
| `pip install flask` uses system Python | Venv not activated | Activate venv first |
| ExecutionPolicy error (Windows) | PowerShell execution disabled | `Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser` |
| `ModuleNotFoundError: flask` | Not installed or wrong Python | Activate venv, then `pip install flask` |
| Files in wrong location | app.py inside venv/ | Move app.py to project root (same level as venv/) |
## Final Verification Checklist
- [ ] Terminal shows `(venv)` in prompt
- [ ] `python --version` shows 3.8 or higher
- [ ] `pip list` shows Flask
- [ ] `python -c "import flask"` runs without error
- [ ] `app.py` exists in project root (not in venv folder)
## If Something Doesn't Work
Report to ASSISTANT with:
1. Which step failed
2. Exact error message
3. Output of: `python --version`, `pip --version`, `pip list`

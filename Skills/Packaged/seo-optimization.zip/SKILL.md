---
name: seo-optimization
description: Provide structured SEO guidance for web projects covering technical foundations and content optimization
version: "0.55.0"
license: Complete terms in LICENSE.txt
---
**Purpose:** Guide developers through implementing SEO best practices during development rather than retrofitting after launch.
**Audience:** Developers building web-facing applications who need discoverability.
**Related Skills:** `ci-cd-pipeline-design` -- for deployment automation that preserves SEO settings
## When to Use This Skill
- Setting up a new web project needing search engine visibility
- Adding meta tags, structured data, or social sharing metadata
- Auditing existing site for SEO gaps
- Configuring sitemaps, robots.txt, or canonical URLs
- Structuring content with proper heading hierarchy and semantic HTML
- Optimizing internal linking for crawlability
## Core Areas
1. **Technical SEO** -- Meta tags, structured data, sitemaps, robots.txt, canonical URLs, Open Graph/Twitter Cards
2. **Content Optimization** -- Heading hierarchy, semantic HTML, content structure, internal linking
**Not Covered (v1):** Keyword research, Core Web Vitals deep-dive, framework-specific guidance, accessibility-SEO overlap. See `Docs/02-Advanced/Skill-Guide-SEO.md`.
## Technical SEO Essentials
**Meta Tags:**
```html
<head>
  <title>Page Title -- Site Name</title>
  <meta name="description" content="150-160 character summary of page content.">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta charset="UTF-8">
  <link rel="canonical" href="https://example.com/current-page">
</head>
```
- `<title>` -- 50-60 chars, unique per page, primary keyword near front
- `meta description` -- 150-160 chars, compelling summary, unique per page
- `canonical` -- Always set to prevent duplicate content issues
**Structured Data (JSON-LD):**
```html
<script type="application/ld+json">
{
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "How to Implement SEO",
  "author": { "@type": "Person", "name": "Developer Name" },
  "datePublished": "2026-01-15",
  "description": "A guide to implementing SEO best practices."
}
</script>
```
Common types: `Article`, `Product`, `Organization`, `BreadcrumbList`, `FAQPage`, `HowTo`, `WebSite`, `LocalBusiness`
Validate: [Google Rich Results Test](https://search.google.com/test/rich-results) or [Schema.org Validator](https://validator.schema.org/)
**Sitemaps:**
```xml
<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://example.com/</loc>
    <lastmod>2026-01-15</lastmod>
    <changefreq>weekly</changefreq>
    <priority>1.0</priority>
  </url>
</urlset>
```
- Place at `/sitemap.xml`, reference from `robots.txt`
- Regenerate on content changes (automate in CI/CD)
- Max 50,000 URLs per sitemap; use sitemap index for larger sites
**robots.txt:**
```
User-agent: *
Allow: /
Disallow: /admin/
Disallow: /api/
Disallow: /private/
Sitemap: https://example.com/sitemap.xml
```
- Place at site root; never block CSS/JS files
- Use `Disallow` for admin panels, API endpoints, duplicate pages
**Canonical URLs** -- prevent duplicate content penalties:
```html
<link rel="canonical" href="https://example.com/page">
```
Use for: http/https variations, www/non-www, URL parameters, paginated content, syndicated content.
**Open Graph and Twitter Cards:**
```html
<meta property="og:title" content="Page Title">
<meta property="og:description" content="Page description for social sharing.">
<meta property="og:image" content="https://example.com/image.jpg">
<meta property="og:url" content="https://example.com/page">
<meta property="og:type" content="article">
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="Page Title">
<meta name="twitter:description" content="Page description for Twitter.">
<meta name="twitter:image" content="https://example.com/image.jpg">
```
- `og:image` min 1200x630px; `twitter:card` use `summary_large_image` for articles
- Set on every shareable page
## Content Optimization Essentials
**Heading Hierarchy:**
```html
<h1>Main Page Title</h1>
  <h2>Major Section</h2>
    <h3>Subsection</h3>
  <h2>Another Major Section</h2>
```
- Exactly one `<h1>` per page; never skip levels
- Headings should read as logical outline; include keywords naturally
**Semantic HTML:**
| Element | SEO Purpose |
|---------|-------------|
| `<main>` | Primary content (one per page) |
| `<article>` | Self-contained content (blog post, news) |
| `<section>` | Thematic grouping of content |
| `<nav>` | Navigation blocks (site nav, breadcrumbs) |
| `<header>` | Introductory content for page or section |
| `<footer>` | Footer content (copyright, links) |
| `<aside>` | Tangentially related content (sidebars) |
| `<time>` | Machine-readable dates (use `datetime` attribute) |
**Content Structure:**
- Front-load key information (inverted pyramid)
- Use lists for scannable information (may appear as featured snippets)
- Short paragraphs (2-3 sentences)
- Descriptive link text ("read the SEO guide" not "click here")
- Image alt text for accessibility and image search
**Internal Linking:**
- **Hub-and-spoke model**: Topic hub pages linking to detail pages
- **Contextual links**: Within content where relevant, not just navigation
- **Descriptive anchor text**: Keyword-rich, descriptive
- **Reasonable depth**: Every page reachable within 3 clicks from homepage
- **Fix broken links**: Audit for 404s; use redirects for moved content
## Quick Reference Checklist
**Technical SEO:**
- [ ] `<title>` tag set (50-60 chars, unique)
- [ ] `meta description` set (150-160 chars, unique)
- [ ] Canonical URL set
- [ ] Open Graph tags set (`og:title`, `og:description`, `og:image`, `og:url`)
- [ ] Twitter Card tags set
- [ ] Structured data (JSON-LD) present where applicable
- [ ] Page included in sitemap
- [ ] Not blocked by robots.txt
**Content Optimization:**
- [ ] Single `<h1>` per page
- [ ] Heading hierarchy follows logical order (no skipped levels)
- [ ] Semantic HTML elements used (`<main>`, `<article>`, `<nav>`, `<section>`)
- [ ] Descriptive link text (no "click here")
- [ ] Images have `alt` attributes
- [ ] Internal links to related content
- [ ] Content is front-loaded (key information first)

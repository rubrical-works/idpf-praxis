# Technical SEO Reference
## Meta Tags
**Essential Tags:**
```html
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Primary Keyword -- Brand Name</title>
  <meta name="description" content="Compelling 150-160 character summary with target keywords.">
  <link rel="canonical" href="https://example.com/this-page">
</head>
```
**Title Tag Rules:**
| Rule | Guideline |
|------|-----------|
| Length | 50-60 characters |
| Uniqueness | Every page unique |
| Keywords | Primary keyword near front |
| Branding | Brand name at end: `Page Title -- Brand` |
| Separators | ` -- `, ` | `, or ` - ` |
**Meta Description Rules:**
| Rule | Guideline |
|------|-----------|
| Length | 150-160 characters |
| Uniqueness | Every page unique |
| Content | Summarize value; include call-to-action |
| Keywords | Include primary keyword naturally |
| No duplicates | Google may ignore duplicates |
**Additional Meta Tags:**
```html
<!-- Prevent indexing -->
<meta name="robots" content="noindex, nofollow">
<!-- Language -->
<html lang="en">
<!-- Alternate languages -->
<link rel="alternate" hreflang="es" href="https://example.com/es/page">
<link rel="alternate" hreflang="en" href="https://example.com/en/page">
```
## Structured Data (JSON-LD)
Search engines use structured data for rich results (stars, prices, FAQs, breadcrumbs), content understanding, and knowledge graph. JSON-LD is recommended over Microdata or RDFa.
**Article:**
```json
{
  "@context": "https://schema.org",
  "@type": "Article",
  "headline": "How to Implement Technical SEO",
  "author": { "@type": "Person", "name": "Author Name" },
  "datePublished": "2026-01-15",
  "dateModified": "2026-02-01",
  "publisher": {
    "@type": "Organization",
    "name": "Company Name",
    "logo": { "@type": "ImageObject", "url": "https://example.com/logo.png" }
  },
  "description": "A comprehensive guide to technical SEO implementation.",
  "image": "https://example.com/article-image.jpg"
}
```
**Breadcrumbs:**
```json
{
  "@context": "https://schema.org",
  "@type": "BreadcrumbList",
  "itemListElement": [
    { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://example.com/" },
    { "@type": "ListItem", "position": 2, "name": "Guides", "item": "https://example.com/guides/" },
    { "@type": "ListItem", "position": 3, "name": "Technical SEO" }
  ]
}
```
**FAQ Page:**
```json
{
  "@context": "https://schema.org",
  "@type": "FAQPage",
  "mainEntity": [
    {
      "@type": "Question",
      "name": "What is a canonical URL?",
      "acceptedAnswer": {
        "@type": "Answer",
        "text": "A canonical URL tells search engines which version of a page is the original."
      }
    }
  ]
}
```
**Organization:**
```json
{
  "@context": "https://schema.org",
  "@type": "Organization",
  "name": "Company Name",
  "url": "https://example.com",
  "logo": "https://example.com/logo.png",
  "sameAs": ["https://twitter.com/company", "https://github.com/company"]
}
```
**Validation:**
- Google Rich Results Test: `https://search.google.com/test/rich-results`
- Schema.org Validator: `https://validator.schema.org/`
## Sitemaps
**XML Sitemap:**
```xml
<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <url>
    <loc>https://example.com/</loc>
    <lastmod>2026-01-15</lastmod>
    <changefreq>weekly</changefreq>
    <priority>1.0</priority>
  </url>
</urlset>
```
**Sitemap Index (large sites):**
```xml
<?xml version="1.0" encoding="UTF-8"?>
<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
  <sitemap>
    <loc>https://example.com/sitemap-pages.xml</loc>
    <lastmod>2026-01-15</lastmod>
  </sitemap>
</sitemapindex>
```
**Rules:**
| Rule | Guideline |
|------|-----------|
| Location | `/sitemap.xml` at site root |
| Size limit | Max 50,000 URLs or 50MB per file |
| Large sites | Use sitemap index |
| Reference | Add `Sitemap:` to `robots.txt` |
| Freshness | Regenerate on content changes |
| Exclude | Admin pages, API endpoints, duplicates |
## robots.txt
**Template:**
```
User-agent: *
Allow: /
Disallow: /admin/
Disallow: /api/
Disallow: /private/
Disallow: /_next/
Sitemap: https://example.com/sitemap.xml
```
**Common Mistakes:**
| Mistake | Why It Hurts |
|---------|-------------|
| Blocking CSS/JS | Search engines cannot render page |
| Blocking images | Removes image search traffic |
| Using `Disallow: /` | Blocks entire site |
| Missing `Sitemap:` | Crawlers may not find sitemap |
| Forgetting trailing `/` | `Disallow: /admin` blocks `/administrator` too |
## Canonical URLs
**When to Set:**
| Scenario | Canonical Points To |
|----------|-------------------|
| HTTP vs HTTPS | HTTPS version |
| www vs non-www | Preferred version |
| URL parameters | Base URL without parameters |
| Pagination | First page (or self-referencing) |
| Syndicated content | Original source URL |
| Mobile vs desktop | Desktop URL (with `rel="alternate"`) |
**Implementation:**
```html
<link rel="canonical" href="https://example.com/current-page">
<!-- HTTP header alternative (non-HTML resources) -->
Link: <https://example.com/page>; rel="canonical"
```
## Open Graph and Twitter Cards
**Open Graph:**
```html
<meta property="og:title" content="Page Title">
<meta property="og:description" content="Compelling description for social sharing.">
<meta property="og:image" content="https://example.com/og-image.jpg">
<meta property="og:url" content="https://example.com/page">
<meta property="og:type" content="article">
<meta property="og:site_name" content="Site Name">
```
| Property | Requirements |
|----------|-------------|
| `og:image` | Min 1200x630px, max 8MB, JPG/PNG |
| `og:title` | 60-90 characters |
| `og:description` | 2-4 sentences |
| `og:type` | `website`, `article`, `product` |
**Twitter Cards:**
```html
<meta name="twitter:card" content="summary_large_image">
<meta name="twitter:title" content="Page Title">
<meta name="twitter:description" content="Description for Twitter preview.">
<meta name="twitter:image" content="https://example.com/twitter-image.jpg">
<meta name="twitter:site" content="@handle">
```
| Card Type | Use Case |
|-----------|----------|
| `summary` | Default; small image + text |
| `summary_large_image` | Large image above text (articles) |
| `player` | Video/audio content |
| `app` | Mobile app promotion |

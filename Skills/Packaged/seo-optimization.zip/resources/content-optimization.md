# Content Optimization Reference
## Heading Hierarchy
**Rules:**
1. Exactly one `<h1>` per page -- represents primary topic
2. Never skip levels -- `<h1>` -> `<h2>` -> `<h3>`, never `<h1>` -> `<h3>`
3. Headings form an outline -- reading only headings conveys page structure
4. Keywords are natural -- include relevant terms without stuffing
**Example:**
```html
<h1>Complete Guide to Web Performance</h1>
  <h2>Why Performance Matters</h2>
    <h3>User Experience Impact</h3>
    <h3>SEO Ranking Factor</h3>
  <h2>Measuring Performance</h2>
    <h3>Core Web Vitals</h3>
    <h3>Lighthouse Audits</h3>
  <h2>Optimization Techniques</h2>
    <h3>Image Optimization</h3>
    <h3>Code Splitting</h3>
```
**Common Mistakes:**
| Mistake | Why It Hurts |
|---------|-------------|
| Multiple `<h1>` tags | Confuses search engines about primary topic |
| Skipping levels (`<h1>` -> `<h3>`) | Breaks logical outline |
| Using headings for styling | Use CSS; headings convey meaning, not appearance |
| Empty headings | Crawlers index as meaningless content |
| Keyword stuffing in headings | Search engines penalize unnatural density |
## Semantic HTML
Semantic elements tell search engines what role each piece of content plays.
**Element Reference:**
| Element | SEO Role | Usage |
|---------|----------|-------|
| `<main>` | Primary content (one per page) | Wrap main content |
| `<article>` | Self-contained content | Blog posts, news, forum posts |
| `<section>` | Thematic grouping with heading | Chapters, topic groups |
| `<nav>` | Navigation block | Site nav, breadcrumbs, TOC |
| `<header>` | Introductory content | Page/article header |
| `<footer>` | Footer content | Copyright, related links |
| `<aside>` | Tangentially related | Sidebars, pull quotes |
| `<figure>` / `<figcaption>` | Illustrations with captions | Images, charts, code samples |
| `<time>` | Machine-readable date/time | Publication dates, events |
| `<address>` | Contact information | Author contact, business address |
**Anti-Pattern:**
```html
<!-- BAD: div soup -->
<div class="header"><div class="nav">...</div></div>
<div class="content"><div class="article">...</div></div>
<!-- GOOD: semantic -->
<header><nav>...</nav></header>
<main><article>...</article></main>
```
## Content Structure
**Inverted Pyramid:** Front-load most important information. Users scan; search engines weight content near page top.
**Best Practices:**
| Practice | Guideline |
|----------|-----------|
| Paragraph length | 2-3 sentences |
| Lists | Use `<ul>` / `<ol>` for scannable info |
| Descriptive link text | "Read the deployment guide" not "click here" |
| Image alt text | Describe every `<img>` |
| Bold key phrases | Use `<strong>` (not `<b>`) |
| Table of contents | Add for long-form content (>1500 words) |
**Link Text Rules:**
```html
<!-- GOOD -->
<a href="/guide">Read the complete SEO implementation guide</a>
<!-- BAD -->
<a href="/guide">Click here</a>
```
**Image Optimization:**
```html
<figure>
  <img src="/images/diagram.webp"
    alt="System architecture showing three microservices connected via message queue"
    width="800" height="600" loading="lazy">
  <figcaption>Figure 1: Microservice architecture overview</figcaption>
</figure>
```
| Attribute | SEO Purpose |
|-----------|-------------|
| `alt` | Describes image for search engines and screen readers |
| `width` / `height` | Prevents layout shift (CLS) |
| `loading="lazy"` | Defers off-screen images; improves load speed |
| `<figcaption>` | Additional context for search engines |
## Internal Linking
**Why it matters:**
1. **Crawlability** -- Helps bots discover pages
2. **Link equity** -- Passes ranking authority between pages
3. **User navigation** -- Guides users to related content
**Hub-and-Spoke Model:** Topic hub pages link to related detail pages. Hub ranks for broad terms; spokes rank for specific terms.
**Checklist:**
- [ ] Every page reachable within 3 clicks from homepage
- [ ] No orphan pages (0 internal links pointing to them)
- [ ] Anchor text is descriptive and relevant
- [ ] Links are contextual (within content, not just nav)
- [ ] No excessive links per page (aim for under 100)
- [ ] Broken internal links audited regularly
- [ ] Important pages have the most internal links
**Breadcrumbs:**
```html
<nav aria-label="Breadcrumb">
  <ol>
    <li><a href="/">Home</a></li>
    <li><a href="/guides">Guides</a></li>
    <li aria-current="page">Technical SEO</li>
  </ol>
</nav>
```
Add BreadcrumbList structured data (JSON-LD) alongside HTML for rich results.

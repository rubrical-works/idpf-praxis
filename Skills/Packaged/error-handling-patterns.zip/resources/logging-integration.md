# Logging Integration
**Version:** {{VERSION}}
## Structured Logging
### Log Format
```json
{
  "timestamp": "2024-01-15T10:30:45.123Z", "level": "error", "logger": "api.handlers",
  "message": "Request failed",
  "error": { "type": "ValidationError", "code": "VALIDATION_ERROR", "message": "Invalid email format" },
  "request": { "id": "req-abc-123", "method": "POST", "path": "/api/users", "duration_ms": 45 },
  "user": { "id": "user-456" },
  "trace_id": "trace-xyz-789"
}
```
### Python Implementation
```python
class StructuredLogger:
    def __init__(self, name):
        self.logger = logging.getLogger(name)

    def _format_log(self, level, message, **kwargs):
        return json.dumps({'timestamp': datetime.utcnow().isoformat() + 'Z',
            'level': level, 'logger': self.logger.name, 'message': message, **kwargs})

    def error(self, message, error=None, request=None, **kwargs):
        log_data = {}
        if error:
            log_data['error'] = {'type': type(error).__name__,
                'code': getattr(error, 'code', 'UNKNOWN'), 'message': str(error)}
        if request:
            log_data['request'] = {'id': getattr(request, 'id', None),
                'method': request.method, 'path': request.path}
        self.logger.error(self._format_log('error', message, **log_data, **kwargs))
```
## Log Levels by Error Type
| Error Type | Log Level | Alert? |
|------------|-----------|--------|
| ValidationError | warn | No |
| NotFoundError | info | No |
| AuthenticationError | warn | Monitor rate |
| AuthorizationError | warn | Monitor rate |
| ExternalServiceError | error | Yes |
| InternalError | error | Yes |
| CriticalError | critical | Immediate |
```python
def get_log_level(error):
    if isinstance(error, (ValidationError, NotFoundError)): return 'warning'
    if isinstance(error, (AuthenticationError, BusinessError)): return 'warning'
    if isinstance(error, CriticalError): return 'critical'
    return 'error'

def should_alert(error):
    return isinstance(error, (ExternalServiceError, CriticalError, DataCorruptionError))
```
## Sensitive Data Handling
```python
SENSITIVE_FIELDS = {'password', 'token', 'api_key', 'secret',
    'credit_card', 'ssn', 'auth_header', 'authorization', 'cookie'}

def redact_sensitive(data, fields=SENSITIVE_FIELDS):
    if isinstance(data, dict):
        return {k: '[REDACTED]' if k.lower() in fields else redact_sensitive(v)
            for k, v in data.items()}
    if isinstance(data, list):
        return [redact_sensitive(item) for item in data]
    return data
```
## Correlation IDs
```python
class RequestMiddleware:
    def __call__(self, environ, start_response):
        request_id = environ.get('HTTP_X_REQUEST_ID') or str(uuid.uuid4())
        trace_id = environ.get('HTTP_X_TRACE_ID') or str(uuid.uuid4())
        environ['REQUEST_ID'] = request_id
        environ['TRACE_ID'] = trace_id
        return self.app(environ, start_response)
```
Propagate in: log messages, error responses, outgoing requests (via `X-Request-ID`, `X-Trace-ID` headers).
## Monitoring Integration
### Metrics to Track
```python
from prometheus_client import Counter, Histogram
error_counter = Counter('app_errors_total', 'Total errors', ['error_type', 'error_code', 'endpoint'])
error_latency = Histogram('app_error_latency_seconds', 'Time to error', ['error_type'])
```
### Alert Rules
```yaml
groups:
  - name: error_alerts
    rules:
      - alert: HighErrorRate
        expr: rate(app_errors_total[5m]) > 10
        for: 5m
      - alert: CriticalError
        expr: increase(app_errors_total{error_type="CriticalError"}[1m]) > 0
```
## Error Aggregation
```python
def get_error_fingerprint(error, request=None):
    components = [type(error).__name__, getattr(error, 'code', 'UNKNOWN')]
    if request: components.extend([request.method, request.path])
    return hash(tuple(components))
```
## Log Retention
| Log Type | Retention | Storage |
|----------|-----------|---------|
| Debug | 1 day | Hot |
| Info | 7 days | Hot |
| Warning | 30 days | Warm |
| Error | 90 days | Warm |
| Critical | 1 year | Cold |
---
**See SKILL.md for complete error handling guidance**

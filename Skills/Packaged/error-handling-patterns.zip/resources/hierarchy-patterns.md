# Error Hierarchy Patterns
**Version:** {{VERSION}}
## Pattern 1: Domain-Based Hierarchy
```
AppError
├── UserError
│   ├── UserNotFoundError
│   ├── DuplicateUserError
│   └── InvalidUserDataError
├── OrderError
│   ├── OrderNotFoundError
│   ├── OrderExpiredError
│   └── InsufficientInventoryError
├── PaymentError
│   ├── PaymentDeclinedError
│   └── PaymentTimeoutError
└── SystemError
    ├── DatabaseError
    └── ExternalServiceError
```
**When to use:** Large apps with distinct domains, microservices, DDD projects.
```python
class UserError(AppError):
    pass

class UserNotFoundError(UserError):
    def __init__(self, user_id):
        super().__init__(message=f'User {user_id} not found',
            code='USER_NOT_FOUND', details={'user_id': user_id})
```
## Pattern 2: HTTP-Based Hierarchy
```
AppError
├── ClientError (4xx)
│   ├── BadRequestError (400)
│   ├── UnauthorizedError (401)
│   ├── ForbiddenError (403)
│   ├── NotFoundError (404)
│   └── ConflictError (409)
├── ServerError (5xx)
│   ├── InternalError (500)
│   ├── BadGatewayError (502)
│   └── ServiceUnavailableError (503)
```
**When to use:** API-first, RESTful services, simple CRUD.
```python
class ClientError(AppError):
    status_code = 400

class NotFoundError(ClientError):
    status_code = 404
    def __init__(self, resource_type, resource_id):
        super().__init__(message=f'{resource_type} not found',
            code='NOT_FOUND', details={'resource_type': resource_type, 'resource_id': resource_id})
```
## Pattern 3: Layer-Based Hierarchy
```
AppError
├── PresentationError
├── ApplicationError (ValidationError, AuthorizationError, BusinessRuleError)
├── DomainError (EntityNotFoundError, InvariantViolationError)
└── InfrastructureError (DatabaseError, CacheError, ExternalAPIError)
```
**When to use:** Clean/hexagonal architecture, enterprise apps.
## Pattern 4: Severity-Based Hierarchy
```
AppError
├── RecoverableError
│   ├── RetryableError (TransientError, RateLimitError)
│   └── UserCorrectableError (ValidationError, AuthenticationError)
└── NonRecoverableError (ConfigurationError, CriticalError, DataCorruptionError)
```
**When to use:** Systems with retry logic, error recovery automation.
```python
class RetryableError(RecoverableError):
    retryable = True
    max_retries = 3
    retry_delay = 1.0
```
## Mixing Patterns
```python
class PaymentDeclinedError(PaymentError, UserCorrectableError):
    def __init__(self, reason):
        super().__init__(message=f'Payment declined: {reason}',
            code='PAYMENT_DECLINED', details={'reason': reason})
```
## Error Metadata
```python
class AppError(Exception):
    code: str
    message: str
    severity: str = 'error'       # debug, info, warning, error, critical
    retryable: bool = False
    recoverable: bool = True
    should_alert: bool = False
    user_message: str = None
    status_code: int = 500
    documentation_url: str = None
```
## Anti-Patterns
1. **Flat hierarchy** - No relationship between errors, can't catch by category
2. **Too deep** - More than 3-4 levels (e.g., `UserEmailFormatValidationError`)
3. **Catching base Exception** - Use `except AppError` not `except Exception`
---
**See SKILL.md for complete error handling guidance**

---
name: error-handling-patterns
description: Guide developers through consistent error handling including error hierarchies, API responses, and logging integration
version: "0.52.0"
license: Complete terms in LICENSE.txt
---
# Error Handling Patterns
## When to Use
- Designing error handling strategy for a new project
- Standardizing error responses in an API
- Implementing error logging and monitoring
- Creating user-facing error messages
- Refactoring inconsistent error handling
## Core Principles
1. **Fail fast:** Detect and report errors early
2. **Fail safely:** Errors must not corrupt data or leave invalid states
3. **Be informative:** Messages should help diagnose the problem
4. **Be actionable:** Tell users/developers what they can do
5. **Be consistent:** Same patterns throughout the application
## Error Audiences
- **End users:** Clear, non-technical explanation + what they can do
- **Developers (API consumers):** Error code, technical description, how to fix
- **Operations (your team):** Stack traces, request context, system state
## Error Hierarchy Design
### Base Error Class
```python
class AppError(Exception):
    def __init__(self, message, code=None, details=None):
        super().__init__(message)
        self.message = message
        self.code = code or 'UNKNOWN_ERROR'
        self.details = details or {}

    def to_dict(self):
        return {
            'error': {
                'code': self.code,
                'message': self.message,
                'details': self.details
            }
        }
```
### Error Categories
```python
class ValidationError(AppError):
    def __init__(self, message, field=None, constraint=None):
        super().__init__(message, code='VALIDATION_ERROR',
            details={'field': field, 'constraint': constraint})

class NotFoundError(AppError):
    def __init__(self, resource_type, resource_id):
        super().__init__(f'{resource_type} with id {resource_id} not found',
            code='NOT_FOUND',
            details={'resource_type': resource_type, 'resource_id': resource_id})

class AuthorizationError(AppError):
    def __init__(self, action, resource=None):
        super().__init__(f'Not authorized to {action}',
            code='UNAUTHORIZED', details={'action': action, 'resource': resource})

class BusinessError(AppError):
    def __init__(self, message, rule=None):
        super().__init__(message, code='BUSINESS_RULE_VIOLATION',
            details={'rule': rule})

class ExternalServiceError(AppError):
    def __init__(self, service, original_error=None):
        super().__init__(f'External service {service} failed',
            code='EXTERNAL_SERVICE_ERROR',
            details={'service': service, 'original': str(original_error)})
```
### Error Hierarchy Structure
```
AppError
├── ValidationError
│   ├── InvalidFormatError
│   ├── MissingFieldError
│   └── OutOfRangeError
├── NotFoundError
│   ├── UserNotFoundError
│   └── ResourceNotFoundError
├── AuthorizationError
│   ├── AuthenticationError
│   └── PermissionDeniedError
├── BusinessError
│   ├── InsufficientFundsError
│   └── DuplicateEntryError
└── ExternalServiceError
    ├── DatabaseError
    └── ThirdPartyAPIError
```
## API Error Responses
### Standard Error Format
```json
{
  "error": {
    "code": "VALIDATION_ERROR",
    "message": "Invalid request data",
    "details": { "field": "email", "constraint": "must be a valid email address" },
    "request_id": "abc-123",
    "documentation_url": "https://api.example.com/docs/errors#VALIDATION_ERROR"
  }
}
```
### HTTP Status Code Mapping
| Error Type | HTTP Status | When to Use |
|------------|-------------|-------------|
| ValidationError | 400 Bad Request | Invalid input format |
| AuthenticationError | 401 Unauthorized | Invalid/missing credentials |
| AuthorizationError | 403 Forbidden | Valid credentials, no permission |
| NotFoundError | 404 Not Found | Resource doesn't exist |
| BusinessError | 409 Conflict | Business rule violation |
| RateLimitError | 429 Too Many Requests | Rate limit exceeded |
| InternalError | 500 Internal Server Error | Unexpected server error |
| ExternalServiceError | 502/503 | Downstream service failure |
### Error Handler (Flask)
```python
@app.errorhandler(AppError)
def handle_app_error(error):
    response = jsonify(error.to_dict())
    response.status_code = get_status_code(error)
    return response

@app.errorhandler(Exception)
def handle_unexpected_error(error):
    app.logger.exception('Unexpected error')
    return jsonify({'error': {'code': 'INTERNAL_ERROR',
        'message': 'An unexpected error occurred',
        'request_id': request.id}}), 500
```
## User-Facing vs Developer-Facing
- **User-facing:** Non-technical, actionable, no sensitive info, localized
- **Developer-facing:** Technical, error codes, documentation refs, request context
```
GOOD: "We couldn't process your payment. Please check your card details and try again."
BAD:  "PaymentGateway threw InvalidCardException at line 234"
```
### Message Strategy
```python
class UserFacingError(AppError):
    def __init__(self, user_message, technical_message, code, details=None):
        super().__init__(technical_message, code, details)
        self.user_message = user_message

    def to_user_dict(self):
        return {'error': {'message': self.user_message}}

    def to_developer_dict(self):
        return {'error': {'code': self.code, 'message': self.message, 'details': self.details}}
```
## Logging Integration
**Always log:** Error type/code, timestamp, request/correlation ID, user ID, message, stack trace (unexpected)
**Context:** Request method/path, sanitized body, response status, duration
**Never log:** Passwords, API keys/tokens, credit card numbers, SSNs, PII without consent
```python
class ErrorLogger:
    def __init__(self, logger):
        self.logger = logger

    def log_error(self, error, request=None):
        log_data = {
            'error_type': type(error).__name__,
            'error_code': getattr(error, 'code', 'UNKNOWN'),
            'error_message': str(error),
            'timestamp': datetime.utcnow().isoformat()
        }
        if request:
            log_data['request'] = {
                'method': request.method, 'path': request.path,
                'request_id': request.id, 'user_id': getattr(request, 'user_id', None)
            }
        if isinstance(error, AppError):
            self.logger.warning(json.dumps(log_data))
        else:
            log_data['stack_trace'] = traceback.format_exc()
            self.logger.error(json.dumps(log_data))
```
## Error Recovery Patterns
### Retry with Exponential Backoff
```python
def with_retry(func, max_attempts=3, backoff_factor=2):
    attempt = 0
    while attempt < max_attempts:
        try:
            return func()
        except ExternalServiceError:
            attempt += 1
            if attempt >= max_attempts: raise
            time.sleep(backoff_factor ** attempt)
```
### Circuit Breaker
```python
class CircuitBreaker:
    def __init__(self, failure_threshold=5, recovery_timeout=60):
        self.failure_count = 0
        self.failure_threshold = failure_threshold
        self.recovery_timeout = recovery_timeout
        self.state = 'closed'  # closed, open, half-open
        self.last_failure_time = None

    def call(self, func):
        if self.state == 'open':
            if self._should_attempt_reset(): self.state = 'half-open'
            else: raise CircuitOpenError('Circuit breaker is open')
        try:
            result = func()
            self._on_success()
            return result
        except Exception:
            self._on_failure()
            raise
```
### Fallback
```python
def get_user_with_fallback(user_id):
    try:
        return user_service.get_user(user_id)
    except ExternalServiceError:
        cached_user = cache.get(f'user:{user_id}')
        if cached_user: return cached_user
        raise UserNotFoundError(user_id)
```
## Testing Error Handling
```python
def test_validation_error_format():
    error = ValidationError('Invalid email', field='email')
    result = error.to_dict()
    assert result['error']['code'] == 'VALIDATION_ERROR'
    assert result['error']['details']['field'] == 'email'

def test_error_handler_returns_correct_status():
    with app.test_client() as client:
        response = client.get('/users/nonexistent')
        assert response.status_code == 404
        assert response.json['error']['code'] == 'NOT_FOUND'
```
## Resources
See `resources/` for:
- `hierarchy-patterns.md` - Error hierarchy design patterns
- `api-errors.md` - API error response patterns
- `logging-integration.md` - Logging setup and integration
## Relationship to Other Skills
**Complements:** `api-versioning`, `common-errors`
## Expected Outcome
- Error hierarchy established
- Consistent API error responses
- Proper logging integration
- User-facing and developer-facing messages separated
- Error recovery patterns implemented
---
**End of Error Handling Patterns Skill**

# API Error Patterns
**Version:** 0.52.0
## Standard Error Response Format
### JSON:API Style
```json
{
  "errors": [{
    "id": "error-123", "status": "400", "code": "VALIDATION_ERROR",
    "title": "Validation Error",
    "detail": "The 'email' field must be a valid email address",
    "source": { "pointer": "/data/attributes/email", "parameter": "email" },
    "meta": { "received_value": "not-an-email" }
  }]
}
```
### Problem Details (RFC 7807)
```json
{
  "type": "https://api.example.com/problems/validation-error",
  "title": "Validation Error", "status": 400,
  "detail": "The email field contains an invalid email address",
  "instance": "/api/users/123",
  "errors": [{ "field": "email", "message": "must be a valid email address" }]
}
```
### Custom Format (Simple)
```json
{
  "error": {
    "code": "VALIDATION_ERROR", "message": "Validation failed",
    "details": { "errors": [{"field": "email", "message": "Invalid format"}] },
    "request_id": "abc-123"
  }
}
```
## HTTP Status Codes
### 4xx Client Errors
| Code | Name | When to Use |
|------|------|-------------|
| 400 | Bad Request | Malformed request, validation error |
| 401 | Unauthorized | Missing or invalid authentication |
| 403 | Forbidden | Authenticated but not authorized |
| 404 | Not Found | Resource doesn't exist |
| 405 | Method Not Allowed | HTTP method not supported |
| 409 | Conflict | Resource conflict (duplicate, state conflict) |
| 422 | Unprocessable Entity | Semantic validation failure |
| 429 | Too Many Requests | Rate limit exceeded |
### 5xx Server Errors
| Code | Name | When to Use |
|------|------|-------------|
| 500 | Internal Server Error | Unexpected error |
| 502 | Bad Gateway | Upstream service error |
| 503 | Service Unavailable | Service temporarily unavailable |
| 504 | Gateway Timeout | Upstream service timeout |
### Choosing Between Similar Codes
- **400 vs 422:** 400 = syntactically invalid (malformed JSON). 422 = semantically invalid (business rule).
- **401 vs 403:** 401 = "Who are you?" (authentication). 403 = "You can't do this" (authorization).
- **404 vs 403:** Use 404 to hide existence for security-sensitive resources.
## Error Code Design
### Naming Convention
```
PREFIX_CATEGORY_SPECIFIC
Examples: AUTH_TOKEN_EXPIRED, VALIDATION_FIELD_REQUIRED, RESOURCE_NOT_FOUND
```
### Code Hierarchy
```
General → Specific (2 levels max)
NOT_FOUND → USER_NOT_FOUND (good)
NOT_FOUND → USER_PROFILE_NOT_FOUND (too specific - avoid)
```
### Code Documentation
```yaml
codes:
  - code: AUTH_TOKEN_EXPIRED
    status: 401
    title: Authentication Token Expired
    resolution: Request a new token using the refresh token or re-authenticate
```
## Validation Error Patterns
### Multiple Field Errors
```json
{
  "error": {
    "code": "VALIDATION_ERROR", "message": "Request validation failed",
    "errors": [
      { "field": "email", "code": "FORMAT_INVALID", "message": "Must be a valid email address" },
      { "field": "age", "code": "OUT_OF_RANGE", "message": "Must be between 0 and 150", "received": -5 }
    ]
  }
}
```
### Nested Object Errors
Use dot-path notation: `"path": "address.zipCode"`, `"path": "contacts[0].email"`
## Error Headers
```
X-Request-ID: abc-123           # Correlation ID
X-RateLimit-Limit: 100          # Rate limit ceiling
X-RateLimit-Remaining: 0        # Remaining requests
X-RateLimit-Reset: 1640000000   # Reset timestamp
Retry-After: 60                 # Seconds to wait (429, 503)
```
## Common Error Response Templates
### Rate Limiting
```json
{ "error": { "code": "RATE_LIMIT_EXCEEDED", "message": "Too many requests",
    "details": { "limit": 100, "remaining": 0, "reset_at": "2024-01-15T12:00:00Z", "retry_after_seconds": 60 } } }
```
### Authentication
- **Invalid credentials:** Don't reveal which field is wrong for security.
- **Token expired:** Include `expired_at` in details.
### State Transition
```json
{ "error": { "code": "INVALID_STATE_TRANSITION", "message": "Order cannot be cancelled",
    "details": { "current_state": "shipped", "requested_state": "cancelled", "allowed_transitions": ["delivered", "returned"] } } }
```
### Internal Server Error
**Never expose internal details.** Return generic message with `request_id` for correlation.
## Error Localization
Include `localized_message` field based on `Accept-Language` header alongside default `message`.
---
**See SKILL.md for complete error handling guidance**

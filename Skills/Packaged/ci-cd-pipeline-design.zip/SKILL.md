---
name: ci-cd-pipeline-design
description: Guide developers through CI/CD pipeline design including architecture patterns, stage design, and security considerations
version: "0.55.0"
license: Complete terms in LICENSE.txt
---
# CI/CD Pipeline Design
Guides through designing CI/CD pipelines: architecture, stage design, environment promotion, and security.
## When to Use
- Setting up CI/CD for a new project
- Optimizing existing pipeline performance
- Adding security scanning to pipelines
- Designing multi-environment deployment
- Choosing between CI/CD platforms
## Pipeline Architecture
### Linear Pipeline
```
┌───────┐    ┌──────┐    ┌──────────┐    ┌────────┐
│ Build │ →  │ Test │ →  │ Security │ →  │ Deploy │
└───────┘    └──────┘    └──────────┘    └────────┘
```
Best for: Simple projects, single deployment target.
### Parallel Pipeline
```
              ┌─────────────┐
          ┌───│ Unit Tests  │───┐
          │   └─────────────┘   │
┌───────┐ │   ┌─────────────┐   │   ┌────────┐
│ Build │─┼───│ Lint/Format │───┼───│ Deploy │
└───────┘ │   └─────────────┘   │   └────────┘
          │   ┌─────────────┐   │
          └───│ SAST Scan   │───┘
              └─────────────┘
```
Best for: Faster feedback, independent quality gates.
### Fan-out/Fan-in
```
              ┌──────────┐
          ┌───│ Test DB1 │───┐
          │   └──────────┘   │
┌───────┐ │   ┌──────────┐   │   ┌─────────────┐
│ Build │─┼───│ Test DB2 │───┼───│ Integration │
└───────┘ │   └──────────┘   │   └─────────────┘
          │   ┌──────────┐   │
          └───│ Test DB3 │───┘
              └──────────┘
```
Best for: Matrix testing, multi-platform builds.
### Multi-Environment Pipeline
```
┌───────┐    ┌──────┐    ┌─────────┐    ┌─────────┐    ┌────────────┐
│ Build │ →  │ Test │ →  │ Staging │ →  │ Approval│ →  │ Production │
└───────┘    └──────┘    └─────────┘    └─────────┘    └────────────┘
```
Best for: Production deployments, compliance requirements.
## Stage Design
### Build Stage
Create deployable artifacts: checkout → install deps → compile → create artifacts.
- Cache dependencies, use multi-stage builds, version artifacts, store metadata
### Test Stage
Test pyramid: Many fast unit tests → some integration tests → few E2E tests.
```
        /\
       /E2E\      Few, slow, expensive
      /─────\
     / Int   \    Some, medium speed
    /─────────\
   /   Unit    \  Many, fast, cheap
  /─────────────\
```
### Security Stage
Run in parallel: SAST, dependency scanning, secrets scanning, container scanning.
**Tools:** SonarQube/Semgrep/CodeQL (SAST), Dependabot/Snyk (deps), GitLeaks/TruffleHog (secrets), Trivy/Clair (containers).
### Deploy Stage
Staging: automatic deploy + smoke tests. Production: manual approval → canary (10%) → monitor → gradual rollout.
## Environment Promotion
| Strategy | How It Works | Best For |
|----------|-------------|----------|
| Sequential | Dev → QA → Staging → Production | Standard workflow |
| Blue-Green | Deploy to idle env, switch traffic | Zero-downtime |
| Canary | Route % of traffic to new version | Risk mitigation |
| Rolling | Update instances one at a time | Gradual rollout |
### Blue-Green Deployment
```
┌─────────────────────────┐
│    Load Balancer        │
└───────────┬─────────────┘
            │
     ┌──────┴──────┐
     │             │
┌────▼────┐  ┌─────▼───┐
│  Blue   │  │  Green  │
│(current)│  │  (new)  │
└─────────┘  └─────────┘
```
Deploy to Green → test → switch traffic → keep Blue for rollback.
### Canary Deployment
```
Traffic: 100% ──────────────▶
              │ 90%
              └───▶ Stable (v1)
              │ 10%
              └───▶ Canary (v2)
```
Deploy to subset → monitor errors/performance → gradually increase → full rollout or rollback.
## Platform-Specific: GitHub Actions
```yaml
name: CI/CD Pipeline
on:
  push:
    branches: [main]
  pull_request:
    branches: [main]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: npm ci && npm run build
      - uses: actions/upload-artifact@v4
        with:
          name: build
          path: dist/
  test:
    needs: build
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - run: npm ci && npm test
  security:
    needs: build
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: github/codeql-action/analyze@v2
  deploy-staging:
    needs: [test, security]
    runs-on: ubuntu-latest
    environment: staging
    steps:
      - run: ./deploy.sh staging
  deploy-production:
    needs: deploy-staging
    runs-on: ubuntu-latest
    environment: production
    steps:
      - run: ./deploy.sh production
```
See `resources/platform-examples.md` for GitLab CI and Jenkins configurations.
## Security Considerations
- **Secrets:** Use env vars/secret management, never hardcode, rotate regularly
- **SAST:** Integrate early, fail on high/critical findings
- **Supply chain:** `npm audit`, Snyk, generate SBOMs
- **Containers:** Scan images (Trivy), sign images (cosign)
- **Workflows:** Prevent recursive triggers, limit concurrency, use fine-scoped PATs
## GitHub API Best Practices
- Use durable auth (fine-scoped PATs or GitHub Apps), reuse tokens across runs
- Implement exponential backoff with jitter for API retries
- Monitor `X-RateLimit-Remaining` headers, cache responses
- Stagger concurrent API calls, add delays between bulk operations
- Use `concurrency` groups to prevent workflow cascades
```yaml
concurrency:
  group: ${{ github.workflow }}-${{ github.ref }}
  cancel-in-progress: true
```
## Best Practices
1. **Fast feedback** — CI under 10 min, fast tests first, parallelize, cache deps
2. **Reliable** — Reproducible builds, pinned versions, consistent envs, retry logic
3. **Visible** — Clear naming, meaningful errors, failure notifications
4. **Secure** — Scan early, block on failures, minimal permissions, audit changes
5. **Parity** — Same config patterns, IaC, consistent deployment, production-like testing
## Resources
See `resources/` for: architecture-patterns, stage-design, platform-examples, security-checklist.
## Related Skills
- `api-versioning` — API deployment strategies
- `migration-patterns` — Database deployment considerations
---
**End of CI/CD Pipeline Design Skill**

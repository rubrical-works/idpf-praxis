---
name: drawio-generation
description: Generate valid .drawio.svg diagrams with editable mxGraphModel structure
version: "0.64.0"
license: Complete terms in LICENSE.txt
category: documentation
relevantTechStack: [drawio, diagrams, svg, uml, documentation]
invocationMode: auto
defaultSkill: true
copyright: "Rubrical Works (c) 2026"
---

# DrawIO Generation Skill

**Purpose:** Provide a complete technical specification for generating `.drawio.svg` files — the dual-representation format that renders as SVG in browsers and GitHub while remaining fully editable in draw.io.

**Audience:** Any command, extension, or workflow that needs to produce UML or architectural diagrams.

**Load with:** `Skills/drawio-generation/SKILL.md`

## When to Use This Skill

Invoke this skill when:

- Generating UML diagrams (use case, activity, sequence, class, component, state)
- Creating architectural diagrams for PRDs or design documents
- Producing any `.drawio.svg` file that must open and edit correctly in draw.io
- Validating existing `.drawio.svg` files for completeness

## File Format: Dual SVG + mxGraphModel Representation

A `.drawio.svg` file is a standard SVG file with an embedded `mxfile` XML structure in the `<svg>` element's `content` attribute. This dual representation means:

- **SVG layer** — renders visually in browsers, GitHub preview, and image viewers
- **mxGraphModel layer** — stores the editable graph structure that draw.io reads

Both layers must describe the **same diagram**. If they diverge, the SVG renders one thing while draw.io edits another.

### File Structure

```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
     width="600" height="400" viewBox="0 0 600 400"
     content="&lt;mxfile ...&gt;...HTML-encoded mxGraphModel XML...&lt;/mxfile&gt;"
     style="background-color: rgb(255, 255, 255);">
  <defs/>
  <g>
    <!-- SVG shapes and lines that visually match the mxGraphModel -->
  </g>
</svg>
```

**Key points:**
- The `content` attribute contains the **entire mxfile XML**, HTML-encoded (`<` → `&lt;`, `"` → `&quot;`)
- The `width`, `height`, and `viewBox` on `<svg>` should match the `dx`/`dy` on `<mxGraphModel>`
- SVG elements inside `<g>` are the visual rendering; the `content` attribute is the editable model

## mxGraphModel Structure

The mxGraphModel follows a strict hierarchy:

```
mxfile
 └── diagram (id, name)
      └── mxGraphModel (dx, dy, grid, gridSize, ...)
           └── root
                ├── mxCell id="0"              ← root container (always present)
                ├── mxCell id="1" parent="0"   ← default layer (always present)
                ├── mxCell id="..." vertex="1" ← shape cells
                ├── mxCell id="..." edge="1"   ← edge cells
                └── ...
```

### Required Root Cells

Every mxGraphModel must start with two fixed cells:

```xml
<mxCell id="0"/>
<mxCell id="1" parent="0"/>
```

- Cell `0` is the root container
- Cell `1` is the default layer; all other cells use `parent="1"`

### Shape mxCell (vertex)

Shapes are `mxCell` elements with `vertex="1"` and a child `mxGeometry`:

```xml
<mxCell id="step1"
        value="Step 1: Build Model"
        style="rounded=1;whiteSpace=wrap;html=1;fillColor=#E3F2FD;strokeColor=#1976D2;"
        vertex="1" parent="1">
  <mxGeometry x="110" y="90" width="280" height="80" as="geometry"/>
</mxCell>
```

| Attribute | Purpose |
|-----------|---------|
| `id` | Unique identifier (referenced by edges) |
| `value` | Display text (use `&#10;` for line breaks) |
| `style` | Semicolon-delimited style properties |
| `vertex="1"` | Marks this as a shape (not an edge) |
| `parent="1"` | Belongs to the default layer |

The `mxGeometry` child defines position (`x`, `y`) and size (`width`, `height`).

### Edge mxCell (edge)

Edges connect shapes using `edge="1"` with `source` and `target` attributes:

```xml
<mxCell id="e1"
        value=""
        style="edgeStyle=orthogonalEdgeStyle;endArrow=block;endFill=1;"
        edge="1" parent="1"
        source="step1" target="step2">
  <mxGeometry relative="1" as="geometry"/>
</mxCell>
```

| Attribute | Purpose |
|-----------|---------|
| `id` | Unique identifier |
| `value` | Edge label (empty string for unlabeled) |
| `style` | Edge style (orthogonal, curved, endArrow type) |
| `edge="1"` | Marks this as an edge (not a shape) |
| `source` | ID of the source shape |
| `target` | ID of the target shape |

The `mxGeometry` for edges uses `relative="1"` (positions are relative to source/target).

### Edge Labels

To add a label to an edge, set the `value` attribute:

```xml
<mxCell id="e5" value="No"
        style="edgeStyle=orthogonalEdgeStyle;endArrow=block;endFill=1;"
        edge="1" parent="1"
        source="decision" target="fix">
  <mxGeometry relative="1" as="geometry"/>
</mxCell>
```

## Critical Requirement: SVG ↔ mxGraphModel Synchronization

> **Every SVG visual element must have a corresponding mxCell in the mxGraphModel, and vice versa.**

This is the single most important rule for `.drawio.svg` generation. Violations cause:

- **Missing mxCell for SVG arrow** — the arrow renders visually but is not editable in draw.io (a ghost element)
- **Missing SVG for mxCell** — the element exists in draw.io's editor but is invisible in the rendered SVG
- **Mismatched coordinates** — the shape appears in one place visually but draw.io shows it elsewhere

### Synchronization Checklist

| Check | Verify |
|-------|--------|
| Shape count | Number of `vertex="1"` mxCells = number of SVG shapes (`<rect>`, `<ellipse>`, `<polygon>`) |
| Edge count | Number of `edge="1"` mxCells = number of SVG lines/paths (`<line>`, `<path>`) |
| Coordinates | `mxGeometry x,y` matches SVG element `x,y` (or `cx,cy` for ellipses) |
| Labels | `mxCell value` matches SVG `<text>` content |
| Connections | Every `source`/`target` attribute references a valid shape ID |

### Common Anti-Pattern

```
WRONG: Draw SVG arrows first, then add edge mxCells later
       (leads to mismatched source/target references)

RIGHT: Build the mxGraphModel first, then generate matching SVG
       (the "model-first" approach — see Generation Pattern below)
```

## Generation Pattern: Model-First Approach

Generate `.drawio.svg` files in three sequential steps. Never skip or reorder these steps.

### Step 1: Build mxGraphModel

Create the complete graph model before writing any SVG:

1. **Create shape mxCells** — one `vertex="1"` mxCell per visual element (rectangles, ellipses, diamonds, actors)
2. **Create edge mxCells** — one `edge="1"` mxCell per connection, with `source` and `target` referencing shape IDs
3. **Assign unique IDs** — every mxCell needs a unique `id` attribute; use semantic names (e.g., `step1`, `decision`, `e1`) not auto-generated GUIDs
4. **Calculate geometry** — set `x`, `y`, `width`, `height` on each `mxGeometry` to position elements without overlap; use a grid (10px increments recommended)

**Step 1 output:** A complete `<mxfile>` XML structure with all shapes and edges defined.

### Step 2: Generate SVG

Translate each mxCell into its SVG equivalent:

| mxCell Type | SVG Element | Coordinate Source |
|-------------|-------------|-------------------|
| `vertex="1"` with `rounded=1` | `<rect rx="10" ry="10">` | `mxGeometry x, y, width, height` |
| `vertex="1"` with `ellipse` style | `<ellipse>` | `cx = x + width/2`, `cy = y + height/2`, `rx = width/2`, `ry = height/2` |
| `vertex="1"` with `rhombus` style | `<polygon>` (4 points) | Derived from `mxGeometry` center and size |
| `vertex="1"` with `shape=umlActor` | `<circle>` + `<line>` (stick figure) | Head at `(x + width/2, y + 10)` |
| `edge="1"` | `<line>` or `<path>` | Calculated from source/target positions |
| `mxCell value` text | `<text>` | Centered in shape geometry |

**Coordinate alignment rule:** The SVG element positions must match the `mxGeometry` coordinates exactly. This ensures the rendered SVG and the draw.io editor show the same layout.

### Step 3: Validate Synchronization

Before finalizing, verify both layers match:

1. **Count matching** — count `vertex="1"` mxCells and compare to SVG shapes; count `edge="1"` mxCells and compare to SVG lines/paths
2. **Edge reference verification** — every `source` and `target` attribute on edge mxCells must reference an existing shape `id`
3. **Label matching** — `mxCell value` text should appear in the corresponding SVG `<text>` element
4. **Coordinate spot-check** — verify at least the first and last shape positions match between mxGeometry and SVG

If validation fails, fix the **mxGraphModel first** (model-first rule), then regenerate the SVG to match.

### Anti-Pattern Warning

> **Never write SVG elements without first creating the mxGraphModel equivalent.**

This is the most common cause of broken `.drawio.svg` files. When you write SVG first:
- Edge `source`/`target` references point to IDs that don't exist yet
- Shape IDs in the mxGraphModel don't match what was used in SVG
- Coordinates drift between the two layers

The model-first approach prevents all three problems because the mxGraphModel is the single source of truth and the SVG is derived from it.

## UML Diagram Type Conventions

### Use Case Diagram

| Element | mxCell Style | Layout |
|---------|-------------|--------|
| Actor | `shape=umlActor;` | Left side, vertically spaced 80px apart |
| Use Case | `ellipse;whiteSpace=wrap;` | Center, grouped by feature area |
| System Boundary | `rounded=1;dashed=1;` | Rectangle enclosing all use cases |
| Association | `endArrow=none;` | Actor → Use Case |
| Include | `dashed=1;endArrow=open;` + label `<<include>>` | Use Case → Use Case |
| Extend | `dashed=1;endArrow=open;` + label `<<extend>>` | Use Case → Use Case |

**Layout:** Actors on left, system boundary in center, use cases inside boundary. Space actors 80px apart vertically. Use cases 60px apart.

### Activity Diagram

| Element | mxCell Style | Layout |
|---------|-------------|--------|
| Start | `ellipse;fillColor=#000000;` (small, 30x30) | Top center |
| End | `ellipse;fillColor=#000000;strokeColor=#000000;` with inner circle | Bottom center |
| Action | `rounded=1;whiteSpace=wrap;` | Vertical flow, 120px spacing |
| Decision (diamond) | `rhombus;whiteSpace=wrap;` | Center, with Yes/No labeled edges |
| Fork/Join bar | `shape=line;strokeWidth=3;` (horizontal, 200x5) | Full width |
| Swim Lane | `shape=swimlane;startSize=30;` | Vertical columns per actor |

**Layout:** Top-to-bottom flow. Decisions branch left/right. Fork bars span the width. 120px vertical spacing between actions.

### Sequence Diagram

| Element | mxCell Style | Layout |
|---------|-------------|--------|
| Lifeline | `shape=umlLifeline;` | Top row, horizontally spaced 150px |
| Sync Message | `endArrow=block;endFill=1;` | Left-to-right solid arrow |
| Async Message | `endArrow=open;endFill=0;` | Left-to-right open arrow |
| Return Message | `dashed=1;endArrow=open;` | Right-to-left dashed arrow |
| Activation Box | `fillColor=#E3F2FD;` (narrow rect on lifeline) | Overlaid on lifeline |
| Alt/Loop fragment | `dashed=1;rounded=0;` + label `[alt]` or `[loop]` | Enclosing rectangle |

**Layout:** Lifelines across top, messages descend vertically. 40px vertical spacing between messages. Activation boxes 20px wide centered on lifeline.

### Class Diagram

| Element | mxCell Style | Layout |
|---------|-------------|--------|
| Class box | `shape=classShape;` or 3-section rect | Grid layout, 200px spacing |
| Interface | Same as class + `<<interface>>` label | Above implementing classes |
| Inheritance | `endArrow=block;endFill=0;` (hollow triangle) | Child → Parent |
| Implementation | `dashed=1;endArrow=block;endFill=0;` | Class → Interface |
| Association | `endArrow=open;` | Between related classes |
| Composition | `endArrow=diamond;endFill=1;` (filled) | Whole → Part |
| Aggregation | `endArrow=diamond;endFill=0;` (hollow) | Whole → Part |

### Color Scheme

Use consistent colors across all diagram types:

| Purpose | Fill Color | Stroke Color |
|---------|-----------|-------------|
| Primary action/entity | `#E3F2FD` (light blue) | `#1976D2` |
| Decision/branch | `#FFF3E0` (light orange) | `#F57C00` |
| Start/End | `#000000` | `#000000` |
| Actor | `#FFFFFF` | `#333333` |
| System boundary | `#F5F5F5` (light gray) | `#9E9E9E` |
| Error/exception path | `#FFEBEE` (light red) | `#D32F2F` |
| Success/happy path | `#E8F5E9` (light green) | `#388E3C` |

### Layout Best Practices

1. **Grid alignment** — use 10px grid increments for all coordinates
2. **Minimum spacing** — 60px between shapes, 120px between rows
3. **Label positioning** — center text in shapes; edge labels at midpoint
4. **Consistent sizing** — action boxes 280x60, decisions 120x80, actors 40x60
5. **Flow direction** — top-to-bottom for activity/sequence, left-to-right for use case

## Token Budget Considerations

The `.drawio.svg` dual-representation format (SVG visual layer + HTML-encoded mxGraphModel) means each diagram file consumes roughly **~2x the tokens** of a single-format output. Both the SVG elements and the encoded mxfile content must be written, doubling the output size per diagram.

### Rules

1. **One diagram per tool call** — never batch multiple `.drawio.svg` file writes in a single response. Each diagram should be written in its own tool call to stay within output token limits.
2. **Complex diagram threshold** — diagrams with **~15+ nodes** (shapes + edges) can approach output token limits on their own. For large diagrams, consider splitting into sub-diagrams (e.g., separate sequence diagrams per epic rather than one monolithic diagram).
3. **Separate skill reads from diagram writes** — read this skill file in a separate tool call from the one that writes the diagram. Loading the skill specification and generating a diagram in the same response compounds token usage unnecessarily.
4. **Multi-diagram sequences** — when generating multiple diagrams (e.g., `/create-prd` Phase 5.5 producing 2+ diagrams per epic), write each diagram in its own response cycle. Do not attempt to generate all diagrams at once.

## Validation Checklist

Use this checklist after generating a `.drawio.svg` file and before committing it. All four categories must pass.

### 1. mxGraphModel Completeness

- [ ] Root cells present: `<mxCell id="0"/>` and `<mxCell id="1" parent="0"/>`
- [ ] Every shape has `vertex="1"` and a child `<mxGeometry>` with `x`, `y`, `width`, `height`
- [ ] Every edge has `edge="1"` with `source` and `target` attributes
- [ ] Every `source` and `target` value references a valid shape `id`
- [ ] Every `mxGeometry` on edges has `relative="1"`
- [ ] All `id` values are unique within the mxGraphModel
- [ ] All cells have `parent="1"` (or appropriate parent for grouped elements)

### 2. SVG ↔ mxGraphModel Synchronization

- [ ] Shape count matches: number of `vertex="1"` mxCells = number of SVG shapes
- [ ] Edge count matches: number of `edge="1"` mxCells = number of SVG lines/paths
- [ ] Coordinates aligned: `mxGeometry x,y` matches SVG element positioning
- [ ] Labels match: `mxCell value` text appears in corresponding SVG `<text>` elements
- [ ] `<svg>` dimensions (`width`, `height`, `viewBox`) match `<mxGraphModel>` `dx`, `dy`
- [ ] The `content` attribute contains the complete HTML-encoded mxfile XML

### 3. Story Traceability (PRD diagrams only — skip for non-PRD diagrams)

- [ ] **Use case diagrams:** Each user story maps to a use case ellipse with story reference (e.g., "Story 1.1")
- [ ] **Activity diagrams:** Acceptance criteria steps map to activity nodes
- [ ] **All diagrams:** Story IDs embedded in element labels or annotations for traceability
- [ ] Diagram title references the epic or feature it illustrates

### 4. Editability Verification

- [ ] File opens in draw.io without errors
- [ ] Shapes are selectable and movable (not locked or grouped unexpectedly)
- [ ] Connectors (edges) re-route when shapes are moved
- [ ] Text labels are editable by double-clicking shapes
- [ ] Adding new shapes and connectors works without breaking existing elements

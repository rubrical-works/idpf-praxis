---
name: drawio-generation
description: Generate valid .drawio.svg diagrams with editable mxGraphModel structure
version: "0.55.0"
license: Complete terms in LICENSE.txt
---
# DrawIO Generation Skill
**Purpose:** Technical specification for generating `.drawio.svg` files -- dual-representation format that renders as SVG while remaining fully editable in draw.io.
**Audience:** Commands, extensions, or workflows that produce UML or architectural diagrams.
---
## When to Use This Skill
- Generating UML diagrams (use case, activity, sequence, class, component, state)
- Creating architectural diagrams for PRDs or design documents
- Producing `.drawio.svg` files that must open and edit correctly in draw.io
- Validating existing `.drawio.svg` files
---
## File Format: Dual SVG + mxGraphModel Representation
A `.drawio.svg` is standard SVG with embedded `mxfile` XML in the `<svg>` element's `content` attribute:
- **SVG layer** -- renders in browsers, GitHub, image viewers
- **mxGraphModel layer** -- stores editable graph structure for draw.io
Both layers must describe the **same diagram**.
### File Structure
```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
     width="600" height="400" viewBox="0 0 600 400"
     content="&lt;mxfile ...&gt;...HTML-encoded mxGraphModel XML...&lt;/mxfile&gt;"
     style="background-color: rgb(255, 255, 255);">
  <defs/>
  <g>
    <!-- SVG shapes and lines that visually match the mxGraphModel -->
  </g>
</svg>
```
- `content` attribute: entire mxfile XML, HTML-encoded (`<` -> `&lt;`, `"` -> `&quot;`)
- `width`/`height`/`viewBox` on `<svg>` match `dx`/`dy` on `<mxGraphModel>`
---
## mxGraphModel Structure
```
mxfile
 +-- diagram (id, name)
      +-- mxGraphModel (dx, dy, grid, gridSize, ...)
           +-- root
                +-- mxCell id="0"              <- root container (always present)
                +-- mxCell id="1" parent="0"   <- default layer (always present)
                +-- mxCell id="..." vertex="1" <- shape cells
                +-- mxCell id="..." edge="1"   <- edge cells
```
### Required Root Cells
```xml
<mxCell id="0"/>
<mxCell id="1" parent="0"/>
```
Cell `0` = root container. Cell `1` = default layer; all other cells use `parent="1"`.
### Shape mxCell (vertex)
```xml
<mxCell id="step1"
        value="Step 1: Build Model"
        style="rounded=1;whiteSpace=wrap;html=1;fillColor=#E3F2FD;strokeColor=#1976D2;"
        vertex="1" parent="1">
  <mxGeometry x="110" y="90" width="280" height="80" as="geometry"/>
</mxCell>
```
| Attribute | Purpose |
|-----------|---------|
| `id` | Unique identifier (referenced by edges) |
| `value` | Display text (`&#10;` for line breaks) |
| `style` | Semicolon-delimited style properties |
| `vertex="1"` | Marks as shape |
| `parent="1"` | Belongs to default layer |
`mxGeometry` defines position (`x`, `y`) and size (`width`, `height`).
### Edge mxCell (edge)
```xml
<mxCell id="e1" value=""
        style="edgeStyle=orthogonalEdgeStyle;endArrow=block;endFill=1;"
        edge="1" parent="1" source="step1" target="step2">
  <mxGeometry relative="1" as="geometry"/>
</mxCell>
```
| Attribute | Purpose |
|-----------|---------|
| `edge="1"` | Marks as edge |
| `source` | ID of source shape |
| `target` | ID of target shape |
Edge `mxGeometry` uses `relative="1"`. Set `value` attribute for labels.
---
## Critical Requirement: SVG <-> mxGraphModel Synchronization
> **Every SVG visual element must have a corresponding mxCell, and vice versa.**
### Synchronization Checklist
| Check | Verify |
|-------|--------|
| Shape count | `vertex="1"` mxCells = SVG shapes (`<rect>`, `<ellipse>`, `<polygon>`) |
| Edge count | `edge="1"` mxCells = SVG lines/paths |
| Coordinates | `mxGeometry x,y` matches SVG element positioning |
| Labels | `mxCell value` matches SVG `<text>` content |
| Connections | Every `source`/`target` references valid shape ID |
```
WRONG: Draw SVG arrows first, then add edge mxCells later
RIGHT: Build mxGraphModel first, then generate matching SVG
```
---
## Generation Pattern: Model-First Approach
Three sequential steps. Never skip or reorder.
### Step 1: Build mxGraphModel
1. **Create shape mxCells** -- one `vertex="1"` per visual element
2. **Create edge mxCells** -- one `edge="1"` per connection with `source`/`target`
3. **Assign unique IDs** -- semantic names (`step1`, `decision`, `e1`), not GUIDs
4. **Calculate geometry** -- position without overlap, use 10px grid
**Output:** Complete `<mxfile>` XML with all shapes and edges.
### Step 2: Generate SVG
| mxCell Type | SVG Element | Coordinate Source |
|-------------|-------------|-------------------|
| `vertex="1"` + `rounded=1` | `<rect rx="10" ry="10">` | `mxGeometry x, y, width, height` |
| `vertex="1"` + `ellipse` | `<ellipse>` | `cx = x + width/2`, `cy = y + height/2` |
| `vertex="1"` + `rhombus` | `<polygon>` (4 points) | Derived from center and size |
| `vertex="1"` + `shape=umlActor` | `<circle>` + `<line>` | Head at `(x + width/2, y + 10)` |
| `edge="1"` | `<line>` or `<path>` | From source/target positions |
| `mxCell value` | `<text>` | Centered in shape |
SVG positions must match `mxGeometry` coordinates exactly.
### Step 3: Validate Synchronization
1. **Count matching** -- vertex mxCells = SVG shapes; edge mxCells = SVG lines/paths
2. **Edge references** -- every `source`/`target` references existing shape `id`
3. **Label matching** -- `mxCell value` appears in SVG `<text>`
4. **Coordinate spot-check** -- first and last shape positions match
If validation fails, fix **mxGraphModel first**, then regenerate SVG.
> **Never write SVG elements without first creating the mxGraphModel equivalent.**
---
## Token Budget Considerations
The dual-representation format means each diagram consumes ~2x tokens. Both SVG and encoded mxfile must be written.
1. **One diagram per tool call** -- never batch multiple `.drawio.svg` writes in one response
2. **Complex diagram threshold** -- ~15+ nodes can approach output token limits; split into sub-diagrams
3. **Separate skill reads from diagram writes** -- loading skill and generating diagram in same response compounds tokens
4. **Multi-diagram sequences** -- write each diagram in its own response cycle
---
## Validation Checklist
### 1. mxGraphModel Completeness
- [ ] Root cells: `<mxCell id="0"/>` and `<mxCell id="1" parent="0"/>`
- [ ] Every shape has `vertex="1"` + `<mxGeometry>` with `x`, `y`, `width`, `height`
- [ ] Every edge has `edge="1"` with `source` and `target`
- [ ] Every `source`/`target` references valid shape `id`
- [ ] Every edge `mxGeometry` has `relative="1"`
- [ ] All `id` values unique
- [ ] All cells have `parent="1"` (or appropriate parent)
### 2. SVG <-> mxGraphModel Synchronization
- [ ] Shape count matches
- [ ] Edge count matches
- [ ] Coordinates aligned
- [ ] Labels match
- [ ] `<svg>` dimensions match `<mxGraphModel>` `dx`, `dy`
- [ ] `content` attribute contains complete HTML-encoded mxfile XML
### 3. Story Traceability (for PRD diagrams)
- [ ] Use case diagrams: each story maps to use case ellipse with story reference
- [ ] Activity diagrams: AC steps map to activity nodes
- [ ] Story IDs embedded in labels/annotations
- [ ] Diagram title references epic or feature
### 4. Editability Verification
- [ ] Opens in draw.io without errors
- [ ] Shapes selectable and movable
- [ ] Connectors re-route when shapes moved
- [ ] Text labels editable by double-clicking
- [ ] Adding new shapes/connectors works
---

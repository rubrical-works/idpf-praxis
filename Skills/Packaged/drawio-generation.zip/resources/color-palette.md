# Color Palette Reference
Material Design color palette for `.drawio.svg` diagrams. Each purpose defines a **fill** (light) and **stroke** (dark) pair.
---
## Quick Reference Table
| Purpose | Fill | Stroke | Typical Shapes |
|---------|------|--------|----------------|
| **Primary** | `#E3F2FD` | `#1976D2` | Activity, Use Case, Process |
| **Secondary** | `#E8F5E9` | `#388E3C` | Supporting steps, Success |
| **Warning** | `#FFF3E0` | `#F57C00` | Optional, Deployment |
| **Danger** | `#FFEBEE` | `#D32F2F` | Error, Abort, Failure |
| **Info** | `#FFF9C4` | `#F9A825` | Decision, Registry, Config |
| **Neutral** | `#F5F5F5` | `#BDBDBD` | Legend, Boundary, Disabled |
| **External** | `#F3E5F5` | `#7B1FA2` | Third-party tools |
| **Disabled** | `#ECEFF1` | `#607D8B` | Inactive elements |
| **Start/End** | `#333333` | `#333333` | State circles |
---
## Semantic Color Usage
- **Primary:** Default for main workflow steps, core entities, happy path. Most shapes should use Primary.
- **Secondary:** Supporting actions, success outcomes, secondary branches.
- **Warning:** Optional steps, deployment actions, steps with side effects.
- **Danger:** Error states, destructive ops, failure paths. Use sparingly.
- **Info:** Decision diamonds (always), registry/config operations, conditional gates.
- **Neutral:** Legend boxes, system boundaries, disabled/inactive elements.
- **External Tool:** Third-party integrations (draw.io, GitHub, npm).
- **Disabled:** Grayed-out inactive elements.
- **Start/End:** UML start (filled circle) and end (bull's-eye) state nodes.
## Text Colors
| Role | Hex |
|------|-----|
| Primary text | *(default black)* |
| Subtitle text | `#666666` |

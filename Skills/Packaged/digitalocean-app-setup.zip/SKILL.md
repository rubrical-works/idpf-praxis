---
name: digitalocean-app-setup
description: Configure automated preview, staging, and production deployments with DigitalOcean App Platform
version: "0.55.0"
license: Complete terms in LICENSE.txt
---
**Purpose:** Guide developers through setting up DigitalOcean App Platform deployments with GitHub integration
**Audience:** Developers deploying web applications, APIs, and static sites to DigitalOcean
**Related Skills:** `ci-cd-pipeline-design` -- for broader CI/CD pipeline architecture
## Initial Setup
**Prerequisites:**
- DigitalOcean account
- `doctl` CLI installed: `brew install doctl` or `snap install doctl`
- GitHub repository connected to DigitalOcean
```bash
# Authenticate
doctl auth init
# Create app from spec
doctl apps create --spec resources/app-spec.yaml
```
## Environment Configuration
**Required Secrets** (GitHub > Settings > Secrets and variables > Actions):
| Secret | Source | Description |
|--------|--------|-------------|
| `DIGITALOCEAN_ACCESS_TOKEN` | DO Dashboard > API > Tokens | Personal access token |
**App-Level Environment Variables** (App > Settings > App-Level Environment Variables):
- **App-level**: Shared across all components
- **Component-level**: Scoped to a single service/worker
See `resources/env-setup.md` for complete guide.
## GitHub Integration
**Auto-Deploy on Push:**
1. Dashboard > Apps > Create App
2. Select GitHub as source
3. Choose repository and branch
4. App Platform detects framework and configures build automatically
**Review Apps (Preview Deployments):**
1. App > Settings > Review Apps > Enable
2. Each PR gets a unique URL for testing
3. Review apps destroyed when PR is closed
**GitHub Actions Deployment:**
```yaml
- uses: digitalocean/action-doctl@v2
  with:
    token: ${{ secrets.DIGITALOCEAN_ACCESS_TOKEN }}
- run: doctl apps create-deployment ${{ vars.DO_APP_ID }}
```
## Deployment Strategies
**Production:** App Platform auto-deploys from configured branch (`main` -> Production).
**Staging:** Create a second app pointing to a staging branch.
**Manual Deployment:**
```bash
doctl apps create-deployment <app-id>
doctl apps list-deployments <app-id>
```
**Rollback:**
```bash
doctl apps list-deployments <app-id> --format ID,Phase,Progress
doctl apps create-deployment <app-id> --revision <deployment-id>
```
## Monitoring and Debugging
```bash
# Stream runtime logs
doctl apps logs <app-id> --follow
# View build logs
doctl apps logs <app-id> --type build
```
**Dashboard Metrics:** CPU/memory usage, HTTP request rate/latency/error rate, bandwidth, container restarts.
**Health Checks:**
```yaml
services:
  - name: web
    health_check:
      http_path: /api/health
      initial_delay_seconds: 10
      period_seconds: 30
```
## Common Pitfalls
**Build Issues:**
- **Buildpack detection failure**: Ensure standard project files exist (`package.json`, `requirements.txt`) or use Dockerfile
- **Build timeout**: Optimize with `.doignore` to exclude unnecessary files
- **Node.js version**: Set `engines.node` in `package.json` or use `NODEJS_VERSION` env var
**Deployment Issues:**
- **Port binding**: Expects HTTP on port 8080 by default. Set `HTTP_PORT` or use `$PORT` env var
- **Static site routing**: For SPAs, configure catch-all routes in app spec
- **Database connections**: Use connection pools and Managed Databases for production
**Review App Issues:**
- Review apps count as separate instances (cost awareness)
- Share production database by default -- use separate dev databases
- Env vars inherit from main app; override per-component in spec
## Resources
- `resources/app-spec.yaml` -- Reference App Platform spec
- `resources/deploy.yml` -- GitHub Actions workflow
- `resources/env-setup.md` -- Environment variable setup guide

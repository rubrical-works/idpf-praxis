# DigitalOcean Environment Variable Setup
## Required GitHub Repository Secrets
**DIGITALOCEAN_ACCESS_TOKEN:**
1. Go to https://cloud.digitalocean.com/account/api/tokens
2. Click "Generate New Token" -- Read/Write scope
3. Copy token immediately (shown only once)
**Add to GitHub:** Repository > Settings > Secrets and variables > Actions > New repository secret
## GitHub Actions Variables (non-secret)
Set in Repository > Settings > Secrets and variables > Actions > Variables tab:
| Variable | Description | Example |
|----------|-------------|---------|
| `DO_APP_ID` | App ID for deployment API calls | `xxxxxxxx-xxxx-xxxx-xxxx-xxxxxxxxxxxx` |
| `DO_PRODUCTION_URL` | Production URL for health checks | `https://my-app-xxxxx.ondigitalocean.app` |
## App-Level Environment Variables
Set in DigitalOcean Dashboard (App > Settings > App-Level Environment Variables):
| Variable | Scope | Description |
|----------|-------|-------------|
| `NODE_ENV` | App-level | Runtime environment |
| `DATABASE_URL` | Component | Database connection string |
| `PORT` | Auto-injected | Default: 8080 |
## Tips
- App-level env vars shared across all components
- Component-level vars override app-level vars with same key
- Encrypt sensitive values with `type: SECRET` in app spec
- Manage via `doctl` CLI or app spec YAML
- Review apps inherit env vars; override per-component in spec

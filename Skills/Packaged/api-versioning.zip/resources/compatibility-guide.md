# Backward Compatibility Guide
**Version:** {{VERSION}}
Patterns and practices for maintaining backward compatibility in APIs.
---
## Compatibility Levels
### Fully Compatible (No Version Bump)
- Adding new endpoints, optional query parameters, optional request fields
- Adding new response fields, new enum values (if client handles unknown)
- Documentation/performance improvements
### Backward Compatible (Minor Version)
- New required fields with defaults
- New response formats (with Accept header)
- Relaxed validation rules
### Breaking (Major Version Required)
- Removing endpoints or response fields
- Changing field types or renaming fields
- Tightening validation rules
- Changing authentication requirements
---
## Safe Change Patterns
**Adding fields:**
```json
// v1 (still works): {"name": "Alice"}
// v1.1 (new field): {"name": "Alice", "email": "alice@example.com"}
```
**Adding enum values:** Clients must handle unknown values with default case.
---
## Breaking Change Mitigation
### Field Rename
Parallel fields with deprecation during transition:
```json
{"name": "Alice", "fullName": "Alice"}  // Transition: both present
{"fullName": "Alice"}                    // After transition
```
Add header: `Warning: 299 - "name field deprecated, use fullName"`
### Type Change
New field with different name, or new version:
```json
// v2: {"id": "abc-123"}  // Breaking, requires new version
```
### Removing Fields
Phase 1: Mark deprecated -> Phase 2: Return null -> Phase 3: Remove (new version)
### Validation Changes
- **Tightening** (breaking) - requires new version
- **Relaxing** (safe) - existing requests still work
---
## Client Guidelines (Postel's Law)
1. Ignore unknown response fields
2. Handle missing optional fields
3. Handle unknown enum values
4. Don't rely on field order
**Defensive parsing:**
```javascript
function parseUser(data) {
  return {
    id: data.id,
    name: data.name || 'Unknown',
    email: data.email || null,
  };
}
```
---
## Testing Compatibility
### Contract Testing
```javascript
describe('v1 API contract', () => {
  it('returns expected v1 response shape', async () => {
    const response = await api.get('/v1/users/1');
    expect(response).toHaveProperty('id');
    expect(response).toHaveProperty('name');
  });
});
```
### Backward Compatibility Tests
Ensure v1 client can consume v2 server response without errors.
### Schema Validation (OpenAPI)
```yaml
properties:
  name:
    type: string
    deprecated: true
    description: "Deprecated. Use fullName instead."
```
---
## Documentation Practices
### Deprecation Markers in API Docs
| Field | Type | Description |
|-------|------|-------------|
| name | string | **DEPRECATED** Use fullName. Will be removed in v2. |
| fullName | string | User's full name |
| email | string | User's email (added in v1.1) |
---
**See SKILL.md for complete API versioning guidance**

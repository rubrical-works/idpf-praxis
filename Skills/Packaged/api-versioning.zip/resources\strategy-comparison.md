# API Versioning Strategy Comparison
**Version:** 0.52.0
---
## Strategy Implementations
### URL Path Versioning
```javascript
// Express.js
app.use('/v1', v1Router);
app.use('/v2', v2Router);
```
```python
# Flask
v1_bp = Blueprint('v1', __name__, url_prefix='/v1')
v2_bp = Blueprint('v2', __name__, url_prefix='/v2')
```
### Query Parameter Versioning
```javascript
app.get('/users', (req, res) => {
  const version = req.query.version || '1';
  if (version === '2') return handleV2(req, res);
  return handleV1(req, res);
});
```
### Header Versioning
```javascript
app.get('/users', (req, res) => {
  const version = req.get('Accept-Version') || req.get('X-API-Version') || 'v1';
  switch(version) {
    case 'v2': return handleV2(req, res);
    default: return handleV1(req, res);
  }
});
```
### Media Type Versioning
```javascript
app.get('/users', (req, res) => {
  const accept = req.get('Accept');
  if (accept.includes('vnd.example.v2')) {
    res.type('application/vnd.example.v2+json');
    return handleV2(req, res);
  }
  return handleV1(req, res);
});
```
---
## Comparison Matrices
### By Use Case
| Use Case | Recommended Strategy |
|----------|---------------------|
| Public REST API | URL Path |
| Internal microservices | Header |
| GraphQL API | Schema evolution (no versioning) |
| Frequently changing API | Date-based query param |
| Enterprise/compliant | Media Type |
| Mobile app backend | URL Path |
### By Organization Size
| Size | Recommended | Rationale |
|------|-------------|-----------|
| Startup | URL Path | Simple, clear, easy to document |
| Small team | Query Param | Flexible, easy to add |
| Medium company | URL Path or Header | Balance of clarity and flexibility |
| Enterprise | Media Type | Standards compliance |
### By Breaking Change Frequency
| Frequency | Strategy |
|-----------|----------|
| Rarely | Major version in URL (v1, v2) |
| Occasionally | Minor versions in header |
| Frequently | Date-based versions |
| Continuously | GraphQL evolution |
---
## Hybrid Approaches
**URL + Header:** Major version in URL, minor in header
**URL + Query for Preview:** `/v2/users?preview=true` for beta features
**Media Type + URL Fallback:** Preferred media type, URL fallback for simple clients
---
## Implementation Patterns
### Version Router
```python
class VersionRouter:
    def __init__(self):
        self.handlers = {}
    def register(self, version, handler):
        self.handlers[version] = handler
    def route(self, version, request):
        handler = self.handlers.get(version, self.handlers.get('default'))
        return handler(request)
```
### Version Middleware
```javascript
const versionMiddleware = (req, res, next) => {
  req.apiVersion =
    req.params.version || req.query.version ||
    req.get('X-API-Version') || parseMediaType(req.get('Accept')) || 'v1';
  next();
};
```
---
## Anti-Patterns
- **Version in every endpoint** (`/users/v1`) - inconsistent, version at API root level
- **Versioning without policy** (v1..v5 all maintained) - need deprecation policy
- **Breaking changes without version bump** - breaks existing clients
---
**See SKILL.md for complete API versioning guidance**

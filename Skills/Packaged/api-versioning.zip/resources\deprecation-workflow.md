# Deprecation Workflow
**Version:** 0.52.0
Step-by-step process for deprecating and sunsetting API versions.
---
## Deprecation Lifecycle
```
┌─────────┐    ┌────────────┐    ┌────────┐    ┌─────────┐
│ Active  │ ->  │ Deprecated │ ->  │ Sunset │ ->  │ Removed │
└─────────┘    └────────────┘    └────────┘    └─────────┘
    │               │                │             │
Full support   Still works      Warning       Unavailable
```
---
## Phase 1: Planning
### Pre-Deprecation Checklist
- [ ] Identify version to deprecate
- [ ] Determine replacement version
- [ ] Set deprecation timeline
- [ ] Write migration guide
- [ ] Identify affected clients
- [ ] Prepare communication plan
### Minimum Recommended Timelines
| API Type | Deprecation Notice | Sunset Period | Total |
|----------|-------------------|---------------|-------|
| Internal | 1 month | 1 month | 2 months |
| Partner | 3 months | 3 months | 6 months |
| Public | 6 months | 6 months | 12 months |
| Enterprise | 12 months | 6 months | 18 months |
### Migration Guide Must Include
1. What's changing and why
2. Step-by-step migration instructions
3. Code examples (before/after)
4. FAQ and support contacts
---
## Phase 2: Announcement
**Channels:** Documentation updates, email to API users, API response headers, dashboard banners
**Deprecation headers:**
```
Deprecation: true
Sunset: Sat, 01 Jun 2025 00:00:00 GMT
Link: <https://api.example.com/migration>; rel="deprecation"
```
### Announcement Template
```markdown
# API Deprecation Notice
## Summary
API version [v1] is being deprecated in favor of [v2].
## Timeline
- **Deprecation Date:** [date]
- **Sunset Date:** [date]
- **End of Life:** [date]
## Migration Path
See our [Migration Guide](link) for step-by-step instructions.
```
---
## Phase 3: Deprecation Period
**Implementation:**
```javascript
const deprecationMiddleware = (req, res, next) => {
  if (req.apiVersion === 'v1') {
    res.set('Deprecation', 'true');
    res.set('Sunset', 'Sat, 01 Jun 2025 00:00:00 GMT');
  }
  next();
};
```
**Monitor:** Request count by version, unique clients on old version, migration progress
---
## Phase 4: Sunset Period
**Add warning to responses:**
```json
{
  "data": { ... },
  "warning": {
    "code": "DEPRECATED_VERSION",
    "message": "API v1 will be removed on 2025-06-01. Please migrate to v2."
  }
}
```
- Weekly emails to remaining users
- Direct outreach to heavy users
**Extension criteria:** Valid business reason, migration in progress, limited time only
---
## Phase 5: Removal
### Pre-Removal Checklist
- [ ] All major clients migrated
- [ ] Extension requests processed
- [ ] Final notification sent
- [ ] Error response prepared
### Removal Options
**410 Gone (recommended):**
```javascript
app.use('/v1', (req, res) => {
  res.status(410).json({
    error: 'VERSION_REMOVED',
    message: 'API v1 has been removed. Please use v2.',
    migration_guide: 'https://api.example.com/migration'
  });
});
```
**301 Redirect** to documentation, or **proxy** to new version (temporary, compatible endpoints only)
---
## Metrics to Track
| Metric | Target |
|--------|--------|
| v1 request % | Decreasing |
| v2 adoption % | Increasing |
| Migration support tickets | Decreasing |
### Success Criteria
- < 1% traffic on deprecated version at sunset
- < 0.1% traffic at removal
- Zero critical client outages
---
**See SKILL.md for complete API versioning guidance**

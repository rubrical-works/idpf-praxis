# SQL Basics for Beginners
**Version:** 0.53.1
## The Four Main Operations (CRUD)
**C**reate - Add new data | **R**ead - Get existing data | **U**pdate - Change existing data | **D**elete - Remove data
## Basic SQL Commands
### CREATE TABLE
```sql
CREATE TABLE notes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    text TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);
```
**Column types:** `INTEGER` (whole numbers), `TEXT` (strings), `REAL` (decimals), `TIMESTAMP` (date/time)
**Constraints:** `PRIMARY KEY` (unique ID), `AUTOINCREMENT` (auto count up), `NOT NULL` (required), `DEFAULT` (fallback value)
### INSERT
```sql
INSERT INTO notes (text) VALUES ('Buy milk');
-- With placeholder (safer):
INSERT INTO notes (text) VALUES (?);
```
Pass actual text separately (prevents SQL injection).
### SELECT
```sql
SELECT * FROM notes;                          -- Get everything
SELECT id, text FROM notes;                   -- Specific columns
SELECT * FROM notes WHERE id = 5;             -- With condition
SELECT * FROM notes ORDER BY created_at DESC; -- Sorted (DESC=newest first, ASC=oldest)
```
### UPDATE
```sql
UPDATE notes SET text = 'Buy bread' WHERE id = 5;
```
**Warning:** Always use WHERE or you'll update ALL rows!
### DELETE
```sql
DELETE FROM notes WHERE id = 5;
```
**Warning:** Without WHERE, deletes EVERYTHING!
## Common Patterns
```sql
SELECT * FROM notes WHERE text LIKE '%milk%';  -- Search (% = wildcard)
SELECT COUNT(*) FROM notes;                     -- Count rows
SELECT * FROM notes ORDER BY created_at DESC LIMIT 1;  -- Most recent
SELECT * FROM notes WHERE id = 5 OR id = 10;   -- Multiple with OR
SELECT * FROM notes WHERE text LIKE '%important%' AND created_at > '2024-01-01';  -- AND
```
## SQL Injection (Security!)
**NEVER do this:**
```python
conn.execute(f"INSERT INTO notes (text) VALUES ('{text}')")  # DANGEROUS!
```
**ALWAYS do this:**
```python
conn.execute("INSERT INTO notes (text) VALUES (?)", (text,))  # SAFE
```
The `?` placeholder safely escapes dangerous characters.
## Common SQL Errors
- **"no such table"** - Table doesn't exist, run CREATE TABLE first
- **"no such column"** - Typo in column name
- **"UNIQUE constraint failed"** - Duplicate value in UNIQUE column
- **"NOT NULL constraint failed"** - Required column missing value
## Practice Exercises
```sql
INSERT INTO notes (text) VALUES ('My first note');  -- 1. Add
SELECT * FROM notes;                                 -- 2. See all
SELECT * FROM notes WHERE id = 1;                    -- 3. Find one
UPDATE notes SET text = 'Updated text' WHERE id = 1; -- 4. Update
DELETE FROM notes WHERE id = 1;                       -- 5. Delete
```

---
name: sqlite-integration-for-beginners
description: Add SQLite database to Flask or Sinatra app with beginner-friendly code examples and teaching comments
version: "0.52.0"
license: Complete terms in LICENSE.txt
---
# SQLite Integration for Beginners
## When to Use
- User has working app with in-memory storage (lists/arrays)
- User asks "How do I save data permanently?"
- User wants data to persist after server restart
- User has 3-4 features working and is ready for persistence
## Prerequisites Check
- Working Flask or Sinatra app
- Understand routes and templates
- At least one feature using list/array storage
- Comfortable with basic programming concepts
## Key Concepts to Teach
### Database = Organized Storage
```
Database has TABLES (like spreadsheets)
Each table has:
- COLUMNS: What kind of data (id, name, email)
- ROWS: Actual data entries

Example "notes" table:
┌────┬─────────────────┬────────────────────┐
│ id │ text            │ created_at         │
├────┼─────────────────┼────────────────────┤
│ 1  │ Buy milk        │ 2024-01-15 10:30   │
│ 2  │ Call doctor     │ 2024-01-15 11:45   │
│ 3  │ Finish homework │ 2024-01-15 14:20   │
└────┴─────────────────┴────────────────────┘
```
### SQL Commands
```
CREATE TABLE - Make new table
INSERT INTO  - Add data
SELECT       - Get data
UPDATE       - Change data
DELETE       - Remove data
```
### Connection Pattern
1. CONNECT to database file
2. DO something (add, get, update data)
3. COMMIT (save changes)
4. CLOSE connection
## Implementation Steps
### Step 1: Understand the Transition
**Current code (list):**
```python
notes = []  # Data in RAM - disappears when server stops
@app.route('/')
def home():
    return render_template('index.html', notes=notes)
```
**After SQLite:** Data saved in `notes.db` file -> persists forever
### Step 2: Choose Your Framework
- **Flask users:** See `resources/flask-sqlite-example.py`
- **Sinatra users:** See `resources/sinatra-sqlite-example.rb`
- **SQL basics:** See `resources/sql-basics.md`
## Flask Implementation
See `resources/flask-sqlite-example.py` for complete, commented code.
```python
import sqlite3

def get_db():
    conn = sqlite3.connect('notes.db')
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    conn.execute('''
        CREATE TABLE IF NOT EXISTS notes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            text TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    conn.close()

@app.route('/')
def home():
    conn = get_db()
    notes = conn.execute('SELECT * FROM notes').fetchall()
    conn.close()
    return render_template('index.html', notes=notes)
```
## Sinatra Implementation
See `resources/sinatra-sqlite-example.rb` for complete, commented code.
```ruby
require 'sqlite3'
DB = SQLite3::Database.new 'notes.db'
DB.results_as_hash = true

DB.execute <<-SQL
  CREATE TABLE IF NOT EXISTS notes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    text TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  )
SQL

get '/' do
  @notes = DB.execute('SELECT * FROM notes')
  erb :index
end
```
## Teaching: SQL Statements
**CREATE TABLE:**
```sql
CREATE TABLE IF NOT EXISTS notes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    text TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
```
- `IF NOT EXISTS` - safe to run multiple times
- `AUTOINCREMENT` - automatically increments (1, 2, 3, ...)
- `NOT NULL` - field is required
- `DEFAULT CURRENT_TIMESTAMP` - auto-fills with current time

**INSERT:** `INSERT INTO notes (text) VALUES (?)` - `?` placeholder prevents SQL injection
**SELECT:** `SELECT * FROM notes ORDER BY created_at DESC` - newest first
## Common Questions
- **Where is the database file?** In project folder: `notes.db`
- **Can I look inside?** DB Browser for SQLite (free), sqlite3 CLI, VS Code extensions
- **Made a mistake?** Delete `notes.db`, recreates on next run (data lost)
- **Need to install SQLite?** Python: built-in. Ruby: `gem install sqlite3`
- **SQL injection?** `?` placeholders (prepared statements) are safe. Never put user input directly in SQL.
## Testing the Database
1. Add note through form -> restart server -> note still there
2. Check `notes.db` file exists in project folder
3. Add several notes -> restart -> all persist
4. Delete `notes.db` -> restart -> new empty database
## Troubleshooting
- **"no such table"** - Table not created, run `init_db()`
- **"Database is locked"** - Close DB Browser or other tools, restart server
- **"No such column"** - Typo in column name, check SQL spelling
- **Weird data format in template** - Access dict/Row correctly, see framework examples
## Complete Examples
- `resources/flask-sqlite-example.py`
- `resources/sinatra-sqlite-example.rb`
- `resources/sql-basics.md`
---
**End of SQLite Integration Skill**

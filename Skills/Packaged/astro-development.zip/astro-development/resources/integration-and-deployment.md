# Integration and Deployment Patterns
## Multi-Framework Integration
Astro supports mixing multiple UI frameworks in a single project. Each framework integration renders independently -- they don't share state or lifecycle.
### Adding Integrations
```bash
npx astro add react svelte vue
```
Updates `astro.config.mjs` automatically:
```javascript
import { defineConfig } from 'astro/config';
import react from '@astrojs/react';
import svelte from '@astrojs/svelte';
export default defineConfig({
  integrations: [react(), svelte()],
});
```
### Supported UI Frameworks
| Framework | Package | JSX/Template |
|-----------|---------|-------------|
| React | `@astrojs/react` | `.jsx` / `.tsx` |
| Preact | `@astrojs/preact` | `.jsx` / `.tsx` |
| Vue | `@astrojs/vue` | `.vue` |
| Svelte | `@astrojs/svelte` | `.svelte` |
| Solid | `@astrojs/solid-js` | `.jsx` / `.tsx` |
| Alpine.js | `@astrojs/alpinejs` | Inline directives |
### When to Mix Frameworks
| Scenario | Recommended Approach |
|----------|---------------------|
| Team has React and Vue developers | Use both -- each team works in their framework |
| Migrating from React to Svelte | Add Svelte, migrate incrementally, remove React when done |
| Need a specific library (e.g., React Three Fiber) | Add React for that component only |
| Building everything from scratch | Pick one framework and stick with it |
| Prototyping with existing component libraries | Use whichever framework the library targets |
### Multi-Framework Considerations
**File extension conflicts (React + Solid both use `.jsx`/`.tsx`):**
```javascript
import { defineConfig } from 'astro/config';
import react from '@astrojs/react';
import solid from '@astrojs/solid-js';
export default defineConfig({
  integrations: [
    react({ include: ['**/react/*'] }),
    solid({ include: ['**/solid/*'] }),
  ],
});
```
Organize: `src/components/react/Counter.tsx` and `src/components/solid/Toggle.tsx`.
**State sharing between framework islands:**
- Custom events on `document` or `window`
- Shared stores via `nanostores` (framework-agnostic)
- Pass data through Astro component props (parent coordinates children)
**Bundle size impact:**
| Runtime | Size (gzipped) |
|---------|---------------|
| React | ~40KB |
| Preact | ~3KB (React-compatible) |
| Svelte | ~2KB (compile-time) |
| Vue | ~33KB |
| Solid | ~7KB |
If you only need one or two React components, consider Preact with `compat` mode for smaller bundles with React API compatibility.
---
## Rendering Mode Selection
### Decision Matrix
```
Does this page need real-time data or user-specific content?
  |
  +- NO  -> Static (default) -- pre-rendered at build time
  |
  +- YES -> Does most of the site need dynamic rendering?
              |
              +- NO  -> Hybrid mode (static default, opt routes into SSR)
              |         export const prerender = false
              |
              +- YES -> Server mode (all routes SSR default)
                         export const prerender = true (to opt out)
```
### Static Mode (Default)
No configuration needed. All pages pre-rendered at build time.
**Best for:** Blogs, documentation, marketing sites, portfolios.
### Hybrid Mode
Static by default. Individual routes opt into server rendering:
```javascript
import node from '@astrojs/node';
export default defineConfig({
  adapter: node({ mode: 'standalone' }),
});
```
```astro
---
// src/pages/dashboard.astro
export const prerender = false;
const user = await getUser(Astro.cookies.get('session'));
---
<h1>Welcome, {user.name}</h1>
```
**Best for:** Mostly static sites with a few dynamic pages (login, dashboard, API routes).
### Server Mode
All routes render on-demand:
```javascript
import node from '@astrojs/node';
export default defineConfig({
  output: 'server',
  adapter: node({ mode: 'standalone' }),
});
```
Opt specific pages into static: `export const prerender = true`
**Best for:** Apps with authentication, real-time data, per-user content.
---
## Deployment Adapter Selection
Required for hybrid or server rendering modes. Choose based on hosting platform.
### Official Adapters
| Adapter | Package | Platform | Mode |
|---------|---------|----------|------|
| Node.js | `@astrojs/node` | Self-hosted, Docker, VPS | `standalone` or `middleware` |
| Vercel | `@astrojs/vercel` | Vercel | Serverless or Edge |
| Netlify | `@astrojs/netlify` | Netlify | Serverless or Edge |
| Cloudflare | `@astrojs/cloudflare` | Cloudflare Pages/Workers | Edge |
### Adapter Decision Guide
| Your Setup | Adapter | Why |
|------------|---------|-----|
| Deploying to Vercel | `@astrojs/vercel` | Native integration, zero config |
| Deploying to Netlify | `@astrojs/netlify` | Native integration, zero config |
| Deploying to Cloudflare | `@astrojs/cloudflare` | Edge rendering, global distribution |
| Self-hosting (Docker, VPS) | `@astrojs/node` | Full control, `standalone` mode |
| Behind Express/Fastify | `@astrojs/node` | `middleware` mode for integration |
| Static site only | No adapter needed | No server-side rendering |
### Installation
```bash
npx astro add vercel    # or netlify, cloudflare, node
```
### Node.js Adapter Modes
**Standalone** -- runs as independent Node.js server (`node ./dist/server/entry.mjs`):
```javascript
export default defineConfig({
  adapter: node({ mode: 'standalone' }),
});
```
**Middleware** -- integrates with existing Node.js framework (Express, Fastify):
```javascript
export default defineConfig({
  adapter: node({ mode: 'middleware' }),
});
```
---
## Performance Patterns
### Zero-JS by Default
Astro ships zero JavaScript unless you explicitly add `client:*` directives. Verify with browser DevTools Network tab -- only hydrated island scripts should appear.
### Image Optimization
Use Astro's built-in `<Image />` for automatic optimization:
```astro
---
import { Image } from 'astro:assets';
import heroImage from '../assets/hero.jpg';
---
<Image src={heroImage} alt="Hero image" width={800} />
```
**Benefits:** Automatic WebP/AVIF conversion, responsive srcset, lazy loading, CLS prevention.
**Skip for:** External images from CDNs that already optimize (Cloudinary, Imgix) -- use `<img>` instead.
### View Transitions
Smooth page transitions without a client-side router:
```astro
---
import { ViewTransitions } from 'astro:transitions';
---
<html>
  <head><ViewTransitions /></head>
  <body><slot /></body>
</html>
```
Uses browser-native View Transitions API. Pages still fully reload (no SPA), but with smooth morphing animations. Persistent elements use `transition:persist`:
```astro
<audio id="player" transition:persist>
  <source src="/music.mp3" />
</audio>
```
**When to use:** Sites where page transitions feel jarring. Minimal JS overhead via native browser APIs.

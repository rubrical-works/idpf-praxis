# Islands Architecture Decision Guide
## Decision Flowchart
For each component on a page, ask in order:
```
Does this component need browser interactivity?
  |
  +- NO  -> No directive (static HTML, zero JS)
  |
  +- YES -> Needs to work immediately on page load?
              |
              +- YES -> Requires client-only rendering (no SSR)?
              |           |
              |           +- YES -> client:only="framework" (canvas, WebGL)
              |           +- NO  -> client:load (buy buttons, nav, auth forms)
              |
              +- NO  -> Below the fold?
                          |
                          +- YES -> client:visible (carousels, galleries)
                          +- NO  -> Conditional on screen size?
                                     |
                                     +- YES -> client:media="(query)" (mobile menu)
                                     +- NO  -> client:idle (comments, chat, analytics)
```
## Directive Deep Dive
### `client:load` -- Immediate Priority
Hydrates immediately on page load. Component renders server-side HTML first, then JS takes over.
```astro
---
import BuyButton from '../components/BuyButton.jsx';
---
<BuyButton client:load productId="abc-123" />
```
- **Use for:** Above-fold interactive elements, auth/login forms, elements users interact with immediately
- **Not for:** Below-fold content (`client:visible`), non-critical widgets (`client:idle`), every component "just to be safe"
### `client:idle` -- Deferred Priority
Hydrates after page loads and browser fires `requestIdleCallback`. Appears as static HTML until browser has spare cycles.
```astro
<CommentSection client:idle postId="123" />
```
Optional timeout: `client:idle={{timeout: 3000}}`
- **Use for:** Visible but non-urgent interactivity (comments, reactions, share buttons), analytics, secondary navigation
### `client:visible` -- Viewport Priority
Hydrates when component scrolls into viewport via `IntersectionObserver`.
```astro
<ImageGallery client:visible images={galleryData} />
```
Optional rootMargin: `client:visible={{rootMargin: "200px"}}`
- **Use for:** Below-fold content, heavy components expensive to hydrate, bottom-of-page content
### `client:media` -- Conditional Priority
Hydrates only when a CSS media query matches. If query never matches, JS never loads.
```astro
<MobileMenu client:media="(max-width: 768px)" />
```
- **Use for:** Mobile-only components, viewport-specific features
- **Note:** HTML still renders on all viewports -- only JS hydration is conditional
### `client:only` -- Client-Side Only
Renders entirely on client. No server-side HTML generated. Must specify framework name.
```astro
<CanvasEditor client:only="react" />
```
Fallback: `<CanvasEditor client:only="react"><p slot="fallback">Loading...</p></CanvasEditor>`
- **Use for:** Browser-only APIs (Canvas, WebGL, Web Audio), third-party widgets requiring DOM
- **Not for:** Standard interactive components -- use `client:load` for better SEO and initial paint
## Common Mistakes
### Mistake 1: Hydrating Everything
```astro
<!-- BAD: Every component gets client:load -->
<Header client:load />
<Hero client:load />
<Features client:load />
<Footer client:load />
<!-- GOOD: Only interactive parts get directives -->
<Header />
<Hero />
<Features>
  <FeatureDemo client:visible />
</Features>
<Footer />
```
### Mistake 2: Using `client:load` for Below-Fold Content
```astro
<!-- BAD -->
<TestimonialCarousel client:load />
<!-- GOOD -->
<TestimonialCarousel client:visible />
```
### Mistake 3: Forgetting Framework Name with `client:only`
```astro
<!-- BAD -->
<Widget client:only />
<!-- GOOD -->
<Widget client:only="react" />
```
## Performance Impact
| Directive | Initial JS Impact | Time to Interactive Impact |
|-----------|-------------------|---------------------------|
| No directive | 0 KB | None |
| `client:idle` | Deferred | Minimal |
| `client:visible` | Deferred until scroll | Minimal |
| `client:media` | Conditional | None if query doesn't match |
| `client:load` | Immediate | Proportional to component size |
| `client:only` | Immediate + no SSR HTML | Largest (no static fallback) |
**Rule of thumb:** If fewer than 20% of your page's components use `client:load`, you're using Islands effectively.

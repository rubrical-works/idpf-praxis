---
name: playwright-explorer
description: Interactive browser exploration using Playwright with natural language interaction, DOM reading, and session management
version: "0.64.0"
license: Complete terms in LICENSE.txt
category: testing
relevantTechStack: [playwright, e2e, browser-testing, web-app, frontend]
invocationMode: direct-only
copyright: "Rubrical Works (c) 2026"
---

# Playwright Explorer

Interactive browser exploration skill that connects to running web applications via Playwright, enabling natural language-driven DOM inspection, element interaction, and session management.

## When to Use This Skill

Invoke this Skill when:
- Exploring a running web application interactively
- Inspecting DOM structure, visible text, or interactive elements
- Performing natural language browser interactions (click, fill, navigate)
- Debugging UI issues with live browser inspection
- Verifying UI state during development

## Prerequisites

- Node.js 18+
- A running web application (dev server)
- Playwright and Chromium (auto-installed if missing)

## Modules

This skill provides a library of modules in `lib/`:

| Module | Purpose |
|--------|---------|
| `preflight.js` | Pre-flight verification gate — detects and installs required components |
| `detect-components.js` | Detects Node.js, Playwright, Chromium, system dependencies |
| `auto-install.js` | Installs missing components (package install requires user confirmation) |
| `browser-connection.js` | URL-based and CDP-based browser connection with dev server auto-detection |
| `dom-reader.js` | Extracts visible text, interactive elements, layout, styles, and test IDs |
| `nl-interaction.js` | Natural language action execution with priority-based selector resolution |
| `session-lifecycle.js` | Background process persistence, file-based IPC, health checks, cleanup |
| `error-recovery.js` | Crash handling, timeout recovery, orphaned process cleanup |

## Workflow

### 1. Pre-Flight Check

Run `preflight.verifyAll()` to detect required components:
- Node.js 18+
- `@playwright/test` package
- Chromium browser binary
- System dependencies (Linux)

Missing components are auto-installed (packages require user confirmation).

### 2. Connect to Application

Use `browser-connection.connect()` with a target URL or let it auto-detect common dev server ports (3000, 5173, 8080, 4200, 8000, 4000, 3001).

### 3. Explore

- **Read DOM** — `dom-reader.extractVisibleText()`, `extractInteractiveElements()`, `extractTestIds()`
- **Interact** — `nl-interaction.executeAction()` supports click, fill, type, goto, goBack, waitForSelector
- **Selector priority** — data-testid > ARIA role > visible text > CSS

### 4. Session Management

Sessions persist via file-based IPC (`.tmp-pw-cmd.json`, `.tmp-pw-result.json`). Health checks detect stale sessions. Error recovery handles crashes, timeouts, and connection loss with automatic cleanup.

## Error Handling

All modules return structured results with `success`/`error` fields. The error recovery module handles:
- Target app crashes (page close/error events)
- Action timeouts (30s navigation, 10s element interaction)
- Orphaned browser processes and temp files
- Connection loss with reconnection guidance

**End of Playwright Explorer Skill**

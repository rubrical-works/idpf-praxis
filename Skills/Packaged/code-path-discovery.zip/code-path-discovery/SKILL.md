---
name: code-path-discovery
description: Scan TypeScript/JavaScript source files for behavioral paths and return candidates in 6-category format for /paths turn-based discovery
version: "0.64.0"
license: Complete terms in LICENSE.txt
category: analysis
relevantTechStack: [javascript, typescript]
invocationMode: manual
defaultSkill: false
copyright: "Rubrical Works (c) 2026"
---

# Code Path Discovery Skill

## Purpose

Scans TypeScript/JavaScript source code within a specified directory to detect behavioral patterns and map them to the 6-category path format used by `/paths`. Returns candidate scenarios as `{ shortLabel, description }` objects per category, ready for turn-based collaborative discovery.

## When to Invoke

- **`/paths --from-code [path]`** — Primary invocation point; called by `/paths` Step 3b when `--from-code` flag is present
- **Manual code analysis** — When exploring an unfamiliar codebase to understand its behavioral flows

## Parameters

| Parameter | Required | Type | Description |
|-----------|----------|------|-------------|
| `path` | Yes | string | Path to source directory to scan (relative or absolute) |
| `issueTitle` | Yes | string | Issue title for context when generating candidate descriptions |
| `issueBody` | No | string | Issue body for additional context |

## How to Use

1. Receive `path`, `issueTitle`, and `issueBody` parameters from `/paths` Step 3b
2. Load skill instructions from `resources/skill-instructions.md`
3. Follow the scanning and mapping workflow in skill instructions
4. Return results as structured output for `/paths` Step 5

## Output Format

Returns an object with 6 category keys, each containing an array of candidate scenarios:

```json
{
  "nominalPath": [
    { "shortLabel": "User login flow", "description": "POST /login validates credentials and returns JWT token" }
  ],
  "alternativePaths": [
    { "shortLabel": "OAuth redirect", "description": "GET /auth/callback handles third-party authentication" }
  ],
  "exceptionPaths": [
    { "shortLabel": "Database connection error", "description": "catch block in db.connect() returns 503 Service Unavailable" }
  ],
  "edgeCases": [
    { "shortLabel": "Empty request body", "description": "Guard clause returns 400 when req.body is null/undefined" }
  ],
  "cornerCases": [
    { "shortLabel": "Concurrent session limit", "description": "Auth guard + session count check reject login when max sessions reached" }
  ],
  "negativeTestScenarios": [
    { "shortLabel": "Invalid token format", "description": "JWT validation middleware rejects malformed tokens with 401" }
  ]
}
```

Each `shortLabel` and `description` maps directly to `/paths` Step 5a `AskUserQuestion` `options[].label` and `options[].description`.

## Resources

- [Skill Instructions](resources/skill-instructions.md) — Pattern scanning rules and category mapping logic

## Related

- **`/paths` command** — Primary consumer of this skill's output
- **anti-pattern-analysis skill** — Complementary code analysis (focuses on quality, not behavioral paths)

## Known Limitations

Validated against `.claude/scripts/shared/` (36 JavaScript files, CLI utility scripts).

**False positive patterns observed:**
- **Guard clause detection (`if (!x)`)** may match control flow conditions that are not boundary guards (e.g., `if (!match)` for string parsing is control flow, not a boundary check). User validation in `/paths` Step 5b mitigates this.
- **`module.exports` as nominal path** — In utility libraries, `module.exports` marks the API surface but doesn't represent a user-facing flow. More useful in route/handler files.
- **Catch blocks in utility code** — Generic error wrapping (e.g., `catch (_e) { /* skip */ }`) may not represent meaningful exception paths.

**Not detected:**
- Implicit error flows via callback conventions (e.g., `callback(err)`)
- Promise chain error propagation without explicit `.catch()`
- Configuration-driven behavior not visible in code structure

**End of Skill Document**

---
name: extract-prd
description: Extract lifecycle artifacts from existing codebases
version: "0.52.0"
license: Complete terms in LICENSE.txt
---
# Skill: extract-prd
**Purpose:** Extract lifecycle artifacts from existing codebases
**Audience:** Developers documenting legacy or undocumented projects
**Load with:** Anti-Hallucination-Rules-for-PRD-Work.md
---
**Critical:** All extracted content must be traceable to code evidence. Never invent details not supported by tests, code patterns, or documentation. Mark all inferences with confidence levels and flag for user validation.
**Output:** CHARTER.md + Inception/ artifacts (not PRD worksheets)
## When to Use
- Legacy codebase without documentation
- Project built without upfront requirements
- Onboarding to existing project
- Pre-LTS baseline documentation
- Session startup detects code but no charter
## Skill Commands
| Command | Purpose | Output |
|---------|---------|--------|
| `Analyze-Structure` | Map file/directory organization, detect tech stack | Inception/Architecture.md, Inception/Tech-Stack.md |
| `Extract-From-Tests` | Parse test files for feature descriptions | Inception/Scope-Boundaries.md |
| `Extract-From-API` | Parse API definitions for endpoints/operations | Inception/Scope-Boundaries.md |
| `Detect-NFRs` | Identify NFRs from code patterns | Inception/Constraints.md, Inception/Test-Strategy.md |
| `Generate-Artifacts` | Output CHARTER.md + Inception/ directory | Full lifecycle structure |
## Extraction Source Mapping
### Priority 1: High-Value Sources
| Source | Extracts To | Parsing Approach |
|--------|-------------|------------------|
| **Test files** | Inception/Scope-Boundaries.md, Inception/Test-Strategy.md | Test descriptions, assertions |
| **API routes** | Inception/Scope-Boundaries.md | Route definitions, handlers |
| **OpenAPI/Swagger** | Inception/Scope-Boundaries.md, Inception/Architecture.md | Schema parsing |
| **GraphQL schema** | Inception/Scope-Boundaries.md, Inception/Architecture.md | SDL parsing |
| **Source structure** | Inception/Architecture.md | Directory patterns, layer detection |
### Priority 2: Supporting Sources
| Source | Extracts To | Parsing Approach |
|--------|-------------|------------------|
| **README.md** | CHARTER.md, Inception/Charter-Details.md | Section extraction |
| **Config files** | Inception/Constraints.md | Pattern matching |
| **Package files** | Inception/Tech-Stack.md | JSON/YAML/TOML parsing |
| **Dockerfile** | Inception/Architecture.md | Command analysis |
### Priority 3: Supplementary Sources
| Source | Extracts To | Parsing Approach |
|--------|-------------|------------------|
| **Git history** | Inception/Milestones.md | Commit message analysis |
| **Comments** | Inception/Charter-Details.md | Docstring extraction |
| **Error handlers** | Inception/Constraints.md | Exception patterns |
| **CI/CD files** | Transition/Deployment-Guide.md (draft) | Workflow parsing |
## Test Parsing Patterns
### Python (pytest)
```python
def test_user_can_register_with_email():
    """User registration with email and password"""
    # -> Feature: User Registration, Behavior: register with email
```
- Function name: `test_<feature>_<behavior>` -> Feature + Behavior
- Docstring -> Scope item description
- Assertions -> Scope boundaries
### JavaScript/TypeScript (Jest/Mocha)
```javascript
describe('User Registration', () => {
  it('should allow registration with email and password', () => {});
});
```
- `describe()` -> Feature grouping; `it()`/`test()` -> Individual behaviors; Nested `describe()` -> Feature hierarchy
See `resources/test-parsing-guide.md` for Ruby, Java, Go, C# patterns.
## NFR Detection Patterns
### Security -> Inception/Constraints.md
| Code Pattern | Inferred Constraint |
|--------------|---------------------|
| `bcrypt`, `argon2`, `scrypt` | Password hashing required |
| `@authenticate`, `requireAuth` | Authentication required |
| `@authorize`, `checkPermission` | Authorization controls |
| `csrf_token`, `csrfProtection` | CSRF protection |
| `validate`, `sanitize`, `escape` | Input validation required |
| `encrypt`, `decrypt`, `AES` | Data encryption required |
| `rateLimit`, `throttle` | Rate limiting configured |
### Performance -> Inception/Constraints.md
| Code Pattern | Inferred Constraint |
|--------------|---------------------|
| `@cache`, `redis`, `memcached` | Caching implemented |
| `pool`, `connection pool` | Connection pooling required |
| `index`, `createIndex` | Database indexing strategy |
| `pagination`, `limit`, `offset` | Pagination support |
### Reliability -> Inception/Constraints.md
| Code Pattern | Inferred Constraint |
|--------------|---------------------|
| `retry`, `maxRetries` | Retry logic implemented |
| `circuit`, `breaker` | Circuit breaker pattern |
| `timeout`, `deadline` | Timeout handling |
| `transaction`, `commit`, `rollback` | Transaction support |
### Test Patterns -> Inception/Test-Strategy.md
| Code Pattern | Inferred Strategy |
|--------------|-------------------|
| `pytest`, `jest`, `rspec` | Test framework identified |
| `mock`, `stub`, `fake` | Mocking strategy |
| `coverage`, `nyc`, `istanbul` | Coverage requirements |
| `e2e`, `integration`, `unit` | Test level strategy |
See `resources/nfr-detection-guide.md` for comprehensive patterns.
## Architecture Inference -> Inception/Architecture.md
### Application Type Detection
| Pattern | Inferred Architecture |
|---------|----------------------|
| `/api/*` routes, REST handlers | REST API |
| `schema.graphql`, resolvers | GraphQL API |
| `/pages/*`, `/app/*` (Next.js) | SSR Web Application |
| `index.html`, SPA routing | Single Page Application |
| `main()`, CLI args | Command Line Tool |
| `worker`, `queue`, `job` | Background Worker |
### Framework Detection -> Inception/Tech-Stack.md
| Files/Patterns | Framework |
|----------------|-----------|
| `package.json` + `express` | Express.js |
| `package.json` + `next` | Next.js |
| `requirements.txt`/`pyproject.toml` + `flask` | Flask |
| `requirements.txt`/`pyproject.toml` + `fastapi` | FastAPI |
| `pyproject.toml` + `django` | Django |
| `Gemfile` + `rails` | Ruby on Rails |
| `pom.xml` + `spring` | Spring Boot |
| `go.mod` + `gin` | Gin (Go) |
### Database Detection -> Inception/Tech-Stack.md
| Pattern | Database Type |
|---------|---------------|
| `sqlite`, `.db` file | SQLite |
| `postgres`, `pg` | PostgreSQL |
| `mysql`, `mariadb` | MySQL/MariaDB |
| `mongodb`, `mongoose` | MongoDB |
| `prisma`, `typeorm`, `sequelize` | ORM (various) |
## Artifact Generation
### CHARTER.md Template
```markdown
# Project Charter: {project-name}
**Status:** Draft (Extracted)
**Extraction Confidence:** {overall-confidence}
## Vision
{Extracted from README or inferred from package description}
## Current Focus
{Inferred from recent commits or "Unknown - needs input"}
## Tech Stack
| Layer | Technology |
|-------|------------|
| Language | {detected} |
| Framework | {detected} |
| Database | {detected} |
## In Scope (Current)
- {Extracted feature 1}
- {Extracted feature 2}
---
*Extracted by extract-prd skill - Review and refine*
```
See `resources/worksheet-templates/` for Charter-Details, Tech-Stack, and Scope-Boundaries templates.
### Output Structure
```
project-root/
├── CHARTER.md
├── Inception/
│   ├── Charter-Details.md
│   ├── Architecture.md
│   ├── Tech-Stack.md
│   ├── Scope-Boundaries.md
│   ├── Test-Strategy.md
│   ├── Constraints.md
│   └── Milestones.md               <- Empty (needs input)
├── Construction/
│   ├── Test-Plans/
│   ├── Design-Decisions/
│   └── Tech-Debt/
└── Transition/
    ├── Deployment-Guide.md         <- Draft if CI/CD detected
    ├── Runbook.md
    └── User-Documentation.md
```
## Confidence Levels
| Level | Criteria | User Action |
|-------|----------|-------------|
| **High** | Multiple sources confirm, explicit in tests | Verify only |
| **Medium** | Single source, reasonable inference | Review and confirm |
| **Low** | Indirect evidence, pattern-based guess | Validate carefully |
**Overall Confidence:** Lowest confidence of any critical section.
## Workflow Integration
```
Session Startup -> CHARTER.md exists?
  [NO] -> Code exists? -> [YES] -> Offer extraction mode
    -> User confirms -> extract-prd -> Generate-Artifacts
      -> User reviews -> Edits -> Commit
```
**With create-prd:** `extract-prd` -> Inception/ from code; `create-prd` -> PRD from proposal + Inception/
## User Confirmation Flow
After extraction, present summary with confidence levels per file and items needing review.
### Targeted Questions for Gaps
| Gap Type | Targeted Question |
|----------|-------------------|
| Vision (Low) | "What problem does this project solve?" |
| Out of scope | "What should this project explicitly NOT do?" |
| Milestones | "What are the key milestones or phases planned?" |
| Target users | "Who are the primary users of this project?" |
| Constraints | "Any specific constraints (performance, security, compliance)?" |
**Rules:** Only ask about Low confidence or "needs input" items. Present 2-3 at a time. Accept "skip"/"unknown".
## Limitations
1. Cannot understand intent - only extracts what's explicit in code
2. Missing context - business rationale not captured
3. False positives possible
4. Best support: Python, JavaScript, Java, Ruby, Go
5. May miss framework-specific patterns
**Extracted artifacts are drafts requiring human refinement.**
---
**End of Skill**

# NFR Detection Guide
**Version:** 0.52.0
**Purpose:** Patterns for inferring Non-Functional Requirements from code
---
## Security (SEC)
### SEC-001: Password Hashing
**Patterns:** `bcrypt.hashpw`, `argon2.hash`, `hashlib.pbkdf2_hmac`, `BCrypt.hashpw`
> SEC-001: User passwords must be hashed using industry-standard algorithms (bcrypt, argon2, or PBKDF2) before storage.
### SEC-002: Authentication Required
**Patterns:** `@login_required`, `@jwt_required`, `authMiddleware`, `@UseGuards(AuthGuard)`, `@PreAuthorize`, `@Secured`
> SEC-002: Protected resources require valid authentication before access.
### SEC-003: Authorization Controls
**Patterns:** `@requires_permission`, `@roles_required`, `user.has_role`, `@Roles`, `checkPermission`
> SEC-003: Role-based access control (RBAC) enforced for sensitive operations.
### SEC-004: CSRF Protection
**Patterns:** `csrf_token()`, `@csrf_protect`, `CSRFProtect(app)`, `app.use(csrf())`
> SEC-004: Cross-Site Request Forgery (CSRF) protection implemented for state-changing requests.
### SEC-005: Security Headers
**Patterns:** `helmet()`, `X-Frame-Options`, `Content-Security-Policy`, `Strict-Transport-Security`
> SEC-005: Security headers (HSTS, CSP, X-Frame-Options, etc.) configured per OWASP recommendations.
### SEC-006: Input Validation
**Patterns:** `validate(data, schema)`, `sanitize()`, `escape_html()`, `joi.validate()`, `@Valid @RequestBody`
> SEC-006: All user input validated and sanitized before processing.
### SEC-007: Data Encryption
**Patterns:** `cipher.encrypt`, `Fernet().encrypt`, `AES.new()`, `crypto.createCipheriv`
> SEC-007: Sensitive data encrypted at rest using AES-256 or equivalent.
### SEC-008: Rate Limiting
**Patterns:** `@ratelimit`, `Limiter()`, `rateLimit()`, `@Throttle`
> SEC-008: API rate limiting implemented to prevent abuse.
---
## Performance (PERF)
### PERF-001: Caching
**Patterns:** `@cache.cached`, `redis.get`, `@lru_cache`, `@Cacheable`, `redis.setex`
> PERF-001: Frequently accessed data cached with [TTL] second expiry.
### PERF-002: Async Processing
**Patterns:** `async def`, `await`, `asyncio.gather`, `Promise.all`
> PERF-002: Non-blocking async processing for I/O operations.
### PERF-003: Connection Pooling
**Patterns:** `create_pool(min_size=, max_size=)`, `create_engine(pool_size=)`, `new Pool({ max: })`
> PERF-003: Database connection pooling configured (pool size: [N]).
### PERF-004: Database Indexing
**Patterns:** `Index()`, `create_index()`, `CREATE INDEX`
> PERF-004: Database indexes defined for frequently queried columns.
### PERF-005: Pagination
**Patterns:** `.limit().offset()`, `Paginator()`, `.skip().limit()`
> PERF-005: List endpoints support pagination (default page size: [N]).
### PERF-006: Response Compression
**Patterns:** `Compress(app)`, `compression()`, `Content-Encoding: gzip`
> PERF-006: HTTP responses compressed (gzip/brotli).
---
## Reliability (REL)
### REL-001: Retry Logic
**Patterns:** `@retry(max_attempts=)`, `tenacity.retry()`, `retry(operation, { retries: })`
> REL-001: Transient failures handled with retry logic (max [N] attempts).
### REL-002: Circuit Breaker
**Patterns:** `@circuit(failure_threshold=)`, `CircuitBreaker()`, `new CircuitBreaker()`
> REL-002: Circuit breaker pattern prevents cascade failures.
### REL-003: Timeout Handling
**Patterns:** `requests.get(url, timeout=)`, `asyncio.wait_for(timeout=)`, `axios.get({ timeout: })`
> REL-003: External calls have timeout limits ([N] seconds).
### REL-004: Fallback Behavior
**Patterns:** `try/except` with fallback value, `.catch(() => fallbackValue)`, `getOrDefault()`
> REL-004: Graceful degradation with fallback behavior for failures.
### REL-005: Transaction Support
**Patterns:** `with db.begin()`, `db.session.commit()`, `prisma.$transaction()`, `@Transactional`
> REL-005: Data operations wrapped in transactions for consistency.
### REL-007: Health Checks
**Patterns:** `@app.route('/health')`, `app.get('/health')`, `livenessProbe`/`readinessProbe`
> REL-007: Health check endpoint available for monitoring.
---
## Observability (OBS)
### OBS-001: Logging
**Patterns:** `logger.info()`, `logging.getLogger()`, `winston.createLogger()`
> OBS-001: Structured logging implemented for observability.
### OBS-002: Metrics
**Patterns:** `prometheus_client.Counter()`, `statsd.increment()`, `promClient.register.metrics()`
> OBS-002: Application metrics collected for monitoring.
### OBS-003: Distributed Tracing
**Patterns:** `opentelemetry`, `tracer.startSpan()`, `@opentelemetry/api`
> OBS-003: Distributed tracing enabled for request tracking.
### OBS-004: Audit Logging
**Patterns:** `audit_log.record()`, `AuditLog.create()`
> OBS-004: Security-relevant actions recorded in audit log.
---
## Confidence Scoring
| Evidence Type | Confidence |
|---------------|------------|
| Explicit decorator/annotation | High |
| Library import + usage | High |
| Configuration value | Medium |
| Pattern in single location | Medium |
| Comment/docstring mention | Low |
| Naming convention only | Low |
---
**End of Guide**

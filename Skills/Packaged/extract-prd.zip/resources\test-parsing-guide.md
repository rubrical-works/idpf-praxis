# Test Parsing Guide
**Version:** 0.52.0
**Purpose:** Rules for extracting requirements from test files
---
## Python (pytest)
**Files:** `test_*.py`, `*_test.py`, `tests/*.py`
**Naming:** `test_<feature>_<action>_<condition>()` -- Feature from first segment, action from middle, condition from final.
```python
def test_user_registration_with_valid_email():
    """User should be able to register with a valid email address"""
    user = register_user("test@example.com", "password123")
    assert user.id is not None
    assert user.email == "test@example.com"
# → Feature: User Registration, AC: ID assigned, email stored
```
**Fixtures as context:** `def test_x(authenticated_user):` implies authentication requirement.
**Parametrized:** `@pytest.mark.parametrize` indicates multiple scenarios/edge cases.
---
## JavaScript/TypeScript (Jest)
**Files:** `*.test.js`, `*.spec.js`, `__tests__/*.js`
**Structure:** Outer `describe` = Feature, inner `describe` = Context, `it`/`test` = AC
```javascript
describe('Shopping Cart', () => {
  describe('adding items', () => {
    it('should add item to empty cart', () => { ... });
    it('should update quantity for existing item', () => { ... });
  });
});
// → Feature: Shopping Cart, Sub: Adding Items, AC-1: Add to empty, AC-2: Update quantity
```
**Async tests:** `async/await` pattern indicates API integration.
---
## Java (JUnit 5)
**Files:** `*Test.java`, `src/test/java/**/*.java`
- Class `@DisplayName` = Feature name
- Method `@DisplayName` = Behavior/AC (fallback: method name)
- `@Nested` + `@DisplayName` = Context grouping
- `@Tag("security")` = Categorization
---
## Ruby (RSpec)
**Files:** `*_spec.rb`, `spec/**/*_spec.rb`
- `describe` (class) = Feature, `describe` (method) = Operation
- `context` = Scenario/condition, `it` = Behavior
- `shared_examples` = Cross-cutting requirements
- Metadata tags (`:slow`, `:integration`) = Test characteristics
---
## Go (testing)
**Files:** `*_test.go`
- `TestFeature_Context` naming convention
- Table-driven tests = Multiple scenarios
- `t.Run("name")` subtests = Individual ACs
---
## C# (xUnit/NUnit)
- xUnit: `[Fact]` for single, `[Theory]` + `[InlineData]` for parametrized
- NUnit: `[Test]`, `[TestCase]`, `[TestFixture]`
- Naming: `Method_Condition_Expected` convention
---
## Extraction Priority
| Source | Priority | Confidence |
|--------|----------|------------|
| Test description (`it`, `@DisplayName`) | High | High |
| Test function name | Medium | High |
| Docstring/comment | Medium | Medium |
| Assertion content | Low | Medium |
| Fixture/setup | Low | Low |
## Edge Cases to Capture
1. **Error scenarios** - Tests with `throws`, `rejects`, `raises`
2. **Boundary conditions** - Parametrized with edge values
3. **Empty/null handling** - Tests with empty inputs
4. **Authorization** - Tests checking roles/permissions
5. **Async behavior** - Tests with async/await patterns
---
**End of Guide**

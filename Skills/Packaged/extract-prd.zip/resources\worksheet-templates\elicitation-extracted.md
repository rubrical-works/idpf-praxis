# Elicitation Worksheet - [Project Name]
**Version:** 0.52.0
**Extracted:** [Date]
**Method:** PRD Extraction (extract-prd Skill v1.0)
---
## 1. Extracted Features
### Feature: [Feature Name]
**ID:** FEAT-[NNN]
**Confidence:** High | Medium | Low
**Description:**
[Extracted from test description, docstring, or inferred]
**Evidence:**
- [ ] Test: `[test file:test name]`
- [ ] API: `[HTTP method] [route]`
- [ ] README: `[section reference]`
- [ ] Code: `[file:function]`
**Behaviors Detected:**
| Behavior | Source | Priority |
|----------|--------|----------|
| [behavior 1] | [test/code] | High/Medium/Low |
**Status:**
- [ ] Confirmed - Accurate as extracted
- [ ] Modified - Needs refinement (see notes)
- [ ] Rejected - Not a real feature
- [ ] Merged - Combined with another feature
**Refinement Notes:**
[User notes for modification]
---
## 2. Extracted Non-Functional Requirements
### [Category] Requirements
#### [ID]: [NFR Title]
**Category:** Security | Performance | Reliability | Observability
**Confidence:** High | Medium | Low
**Pattern Detected:**
```
[code snippet showing pattern]
```
**Inferred Requirement:**
[Description of NFR]
**Status:**
- [ ] Confirmed
- [ ] Modified
- [ ] Rejected
---
## 3. API Endpoints Detected
| Method | Path | Description | Auth Required |
|--------|------|-------------|---------------|
| GET | /api/[resource] | [inferred] | Yes/No |
| POST | /api/[resource] | [inferred] | Yes/No |
| PUT | /api/[resource]/:id | [inferred] | Yes/No |
| DELETE | /api/[resource]/:id | [inferred] | Yes/No |
---
## 4. Constraints Detected
| Constraint | Evidence | Impact |
|------------|----------|--------|
| [constraint] | [source] | [impact] |
| Dependency | Version Constraint | Reason |
|------------|-------------------|--------|
| [package] | [version spec] | [if known] |
---
## 5. Gaps Identified
| Area | Observation |
|------|-------------|
| [area] | No tests found for [functionality] |
| Feature | Evidence | Notes |
|---------|----------|-------|
| [feature] | [code location] | Found in code but no tests/docs |
---
## 6. Extraction Statistics
| Metric | Count |
|--------|-------|
| Features Extracted | [N] |
| NFRs Detected | [N] |
| API Endpoints | [N] |
| Test Files Analyzed | [N] |
| High Confidence Items | [N] |
| Medium Confidence Items | [N] |
| Low Confidence Items | [N] |
---
## 7. Refinement Checklist
- [ ] Review each feature for accuracy
- [ ] Confirm or reject each NFR
- [ ] Add missing features not in code
- [ ] Provide business context for features
- [ ] Prioritize features (if not detected)
- [ ] Add constraints not evident in code
- [ ] Document dependencies between features
---
**Status:** Draft - Requires User Validation
**Next Step:** Validate all items, add missing context, then proceed to Specification phase
---
**End of Elicitation Worksheet**

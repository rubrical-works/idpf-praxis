# Discovery Worksheet - [Project Name]
**Version:** 0.52.0
**Extracted:** [Date]
**Method:** PRD Extraction (extract-prd Skill v1.0)
---
## 1. Project Overview
### 1.1 Summary
[Extracted from README.md or inferred from file structure]
### 1.2 Project Type
- [ ] Web Application
- [ ] REST API
- [ ] CLI Tool
- [ ] Library/Package
- [ ] Background Worker
- [ ] Mobile App
- [ ] Other: ________________
---
## 2. Technology Stack
| Category | Technology | Version | Confidence |
|----------|------------|---------|------------|
| **Language** | [Detected] | [Version] | High/Medium/Low |
| **Framework** | [Detected] | [Version] | High/Medium/Low |
| **Database** | [Detected] | [Version] | High/Medium/Low |
| **Cache** | [Detected if present] | [Version] | High/Medium/Low |
| **Message Queue** | [Detected if present] | [Version] | High/Medium/Low |
### 2.1 Key Dependencies
| Dependency | Purpose | Category |
|------------|---------|----------|
| [package] | [inferred purpose] | Core/Utility/Testing |
---
## 3. Architecture
### 3.1 Architecture Pattern
- [ ] Monolith
- [ ] Microservices
- [ ] Serverless
- [ ] Event-Driven
- [ ] Layered (MVC/MVP/MVVM)
- [ ] Other: ________________
### 3.2 Directory Structure Analysis
```
[Key directories and their purposes]
```
### 3.3 Entry Points
| Entry Point | Type | Purpose |
|-------------|------|---------|
| [file/route] | [API/CLI/Web] | [description] |
---
## 4. Stakeholders (To Confirm)
### 4.1 User Types Detected
| User Type | Evidence | Confidence |
|-----------|----------|------------|
| [User type] | [test/route/feature] | High/Medium/Low |
### 4.2 Roles/Permissions Detected
| Role | Permissions | Evidence |
|------|-------------|----------|
| [role] | [permissions] | [source] |
---
## 5. Domain Analysis
### 5.1 Domain Indicators
| Pattern | Domain Suggestion |
|---------|-------------------|
| [detected pattern] | [suggested domain] |
### 5.2 Potential Compliance Requirements
| Indicator | Possible Requirement |
|-----------|---------------------|
| [e.g., payment handling] | PCI-DSS |
| [e.g., health data] | HIPAA |
| [e.g., EU users] | GDPR |
---
## 6. Integration Points
### 6.1 External Services Detected
| Service | Type | Evidence |
|---------|------|----------|
| [service] | [API/Database/Queue] | [config/code] |
### 6.2 APIs Exposed
| Endpoint Pattern | Operations | Count |
|------------------|------------|-------|
| [/api/resource] | GET, POST, etc. | [N] |
---
## 7. Refinement Checklist
- [ ] Confirm project overview is accurate
- [ ] Verify technology stack versions
- [ ] Validate architecture assessment
- [ ] Identify missing stakeholders
- [ ] Add business context not in code
- [ ] Confirm domain/compliance requirements
---
**Status:** Draft - Requires User Validation
**Next Step:** Review and refine, then proceed to Elicitation Worksheet
---
**End of Discovery Worksheet**

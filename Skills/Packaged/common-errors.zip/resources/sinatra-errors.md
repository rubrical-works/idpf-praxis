# Sinatra-Specific Errors
**Version:** 0.53.1
## Routing Errors
### undefined method `get' for main:Object
**Fix:** Add `require 'sinatra'` at top of app.rb
### Route not found (404)
- Case sensitivity: `/About` != `/about`
- Missing leading slash: `get 'home'` should be `get '/home'`
- Wrong HTTP method: form uses POST but route uses GET
### Route handler returning nil
```ruby
# Wrong:
get '/' do
  @notes = Notes.all
  # Nothing returned
end
# Right:
get '/' do
  @notes = Notes.all
  erb :index
end
```
---
## Template Errors
### Errno::ENOENT
Required structure: `views/` folder (not `Views/`, not `templates/`).
### undefined method for nil:NilClass in template
Set all variables template needs before rendering:
```ruby
get '/' do
  @notes = []  # Set variables template needs
  erb :index
end
```
### SyntaxError in ERB
Ensure all `<% %>` blocks properly closed and `<% if/each %>` have matching `<% end %>`.
---
## Gem/Bundler Errors
### LoadError: cannot load such file -- sinatra
```bash
bundle install   # Or: gem install sinatra
```
Best practice: always `bundle exec ruby app.rb`
---
## Server Errors
### Address already in use - bind(2)
1. `lsof -i :4567` then `kill <PID>`
2. Or use different port: `set :port, 4568`
### Server not auto-reloading
```ruby
# Gemfile: gem 'sinatra-contrib'
# app.rb:
require 'sinatra/reloader' if development?
```
---
## Static File Errors
Files must be in `public/` folder:
```erb
<link rel="stylesheet" href="/style.css">
```
---
## Form/Params Errors
### params is empty
Form method must match route: `post '/add' do` for `<form method="post">`
### NoMethodError: undefined method `[]' for nil
```ruby
# Wrong: params[:user][:name]           # Fails if params[:user] nil
# Right: params.dig(:user, :name)        # Returns nil safely
```
---
## Session Errors
```ruby
enable :sessions
session[:user] = 'john'  # Now works
```

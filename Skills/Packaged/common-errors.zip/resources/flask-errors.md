# Flask-Specific Errors
**Version:** {{VERSION}}
## Import/Routing Errors
### werkzeug.routing.BuildError
**Cause:** `url_for()` with wrong function name
```python
# Wrong: return redirect(url_for('homepage'))  # Function is 'home' not 'homepage'
# Right: return redirect(url_for('home'))       # Matches @app.route def home():
```
### jinja2.exceptions.UndefinedError
**Cause:** Template references variable not passed
```python
# Wrong: return render_template('index.html')              # Missing 'notes'
# Right: return render_template('index.html', notes=notes)  # Pass all required vars
```
---
## Request Errors
### werkzeug.exceptions.BadRequest: 400
**Cause:** Accessing form data that wasn't submitted
```python
# Wrong: note = request.form['note']        # KeyError if missing
# Right: note = request.form.get('note', '') # Safe default
```
---
## Context Errors
### RuntimeError: Working outside of application context
```python
# Wrong: print(current_app.config['DEBUG'])  # No active context
# Right:
with app.app_context():
    print(current_app.config['DEBUG'])
```
---
## Template Errors
### jinja2.exceptions.TemplateSyntaxError
Common: missing `{% endif %}`/`{% endfor %}`, unclosed `{{ var`, using `{{ }}` for control flow.
### TypeError: 'NoneType' object is not iterable
```python
users = get_users() or []  # Default to empty list if None
return render_template('index.html', users=users)
```
---
## Static File Errors
```html
<!-- Wrong: <link href="style.css"> -->
<!-- Right: -->
<link rel="stylesheet" href="{{ url_for('static', filename='style.css') }}">
```
Required: `static/` folder at project root.
---
## Debug Mode
`app.run(debug=True)` enables auto-reload. Never use in production.
## Session Errors
### RuntimeError: The session is unavailable
```python
app.secret_key = 'your-secret-key'  # Required for sessions
```
## Redirect Errors
```python
# Wrong: return redirect('home')            # Goes to URL "/home"
# Right: return redirect(url_for('home'))    # Goes to home() route
```
Redirect loop: route redirecting to itself -> ensure redirects point to different routes.

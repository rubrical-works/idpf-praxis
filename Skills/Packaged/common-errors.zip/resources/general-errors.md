# General Programming Errors
**Version:** 0.53.1
## Logic Errors
### Infinite Loops
```python
# Wrong: forgot to increment
i = 0
while i < 10:
    print(i)
    # i += 1  <- missing!
```
### Off-by-One Errors
Common: starting at 1 instead of 0, `<` vs `<=`, forgetting zero-indexing.
---
## Variable Errors
### Undefined Variable
Python: `NameError`, Ruby: `NameError`, JavaScript: `ReferenceError`
**Fix:** Define before use, check spelling.
### Wrong Variable Scope
```python
def get_name():
    name = "Alice"  # Only exists inside function
print(name)  # Error!
```
**Fix:** Return value or define in correct scope.
---
## String Errors
### Quote Mismatch
```python
message = "Hello, it's me"  # Use " when string has '
message = 'Hello "world"'   # Use ' when string has "
```
### String Concatenation Type Error
```python
# Wrong: print("Age: " + age)     # Can't add string + int
# Right: print(f"Age: {age}")      # f-string
```
---
## Comparison Errors
### Assignment vs Comparison
`=` (assignment) vs `==` (comparison)
### Comparing Different Types
```python
user_input = "5"    # String from form
if user_input == 5: # String vs int - always false!
```
**Fix:** Convert types before comparing.
---
## Function Errors
### Forgetting to Return
```python
# Wrong:
def add(a, b):
    result = a + b  # No return!
# Right:
def add(a, b):
    return a + b
```
---
## Data Structure Errors
### Index Out of Range
```python
items = ["a", "b", "c"]  # Indices: 0, 1, 2
print(items[3])           # Error! No index 3
```
### Key Not Found
```python
value = my_dict.get('key', 'default')  # Safe access
```
---
## Common Fixes Checklist
- [ ] File saved?
- [ ] Server restarted?
- [ ] Variable names spelled correctly?
- [ ] All brackets/quotes closed?
- [ ] Correct data types?
- [ ] Function returns a value?

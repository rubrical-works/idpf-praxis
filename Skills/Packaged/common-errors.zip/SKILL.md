---
name: common-beginner-coding-errors
description: Diagnose and solve common beginner programming mistakes in Flask or Sinatra development with detailed explanations
version: "0.53.1"
license: Complete terms in LICENSE.txt
---
# Common Beginner Coding Errors
Helps beginners diagnose and fix common errors in Flask or Sinatra web development.
## When to Use This Skill
- Beginner reports an error message
- Code isn't working as expected
- Application behavior seems wrong
- User asks "Why isn't this working?"
- Common mistake patterns detected
- Application crashes unexpectedly
- Need help reading exception messages or stack traces
- Framework-specific errors (Flask, Sinatra, Python, Ruby)
## How to Use
1. **Identify the error** from user's report
2. **Find the matching error pattern** below
3. **Apply the solution** with explanation
4. **Verify the fix** worked
## Common Errors by Category
### 1. File Management Errors
#### Error: Changes Don't Appear When Refreshing Browser
**Diagnosis:** Ask:
1. Did you save the file? (Check for unsaved indicator: dot or *)
2. Did you restart the server? (Flask auto-reloads with debug=True, Sinatra doesn't)
3. Are you editing the correct file?
**Solutions:**
- **File Not Saved:** Ctrl+S (Windows/Linux) or Cmd+S (Mac). Habit: Edit -> Save -> Test -> Repeat
- **Server Not Restarted (Sinatra):** Ctrl+C to stop, then `ruby app.rb` again
- **Browser Cache:** Hard refresh Ctrl+Shift+R or Cmd+Shift+R
#### Error: Template Not Found
Flask: `TemplateNotFound: index.html` / Sinatra: `Errno::ENOENT`
**Flask structure:**
```
my-project/
+-- app.py
+-- templates/      <- Must be named exactly "templates"
    +-- index.html
```
Common mistakes: `template/` (missing 's'), `Templates/` (wrong case)
**Sinatra structure:**
```
my-project/
+-- app.rb
+-- views/          <- Must be named exactly "views"
    +-- index.erb
```
### 2. Python-Specific Errors
#### Error: IndentationError
**Wrong:**
```python
def my_function():
print("hello")  # Not indented!
```
**Right:**
```python
def my_function():
    print("hello")  # Indented 4 spaces
```
Fix: Use 4 spaces per level, don't mix tabs/spaces, configure editor to insert spaces on Tab.
#### Error: ModuleNotFoundError: No module named 'flask'
**Solution 1: Virtual Environment Not Activated**
```
Wrong:  C:\Projects\my-app>
Right: (venv) C:\Projects\my-app>
Fix: Windows: venv\Scripts\activate / Mac/Linux: source venv/bin/activate
```
**Solution 2: Flask Not Installed** - `pip install flask`
**Solution 3: Running Wrong Python** - Check `which python` or `where python`, should point to venv folder.
### 3. Ruby/Sinatra-Specific Errors
#### Error: uninitialized constant Sinatra (NameError)
1. Check if installed: `bundle list | grep sinatra`
2. Check require: `require 'sinatra'`
3. Run with bundler: `bundle exec ruby app.rb`
### 4. Route/URL Errors
#### Error: 404 Not Found
- **Typo in URL** - Routes are case-sensitive: `/About` != `/about`
- **Route Not Defined** - Add the route to your code
- **Wrong HTTP Method** - Form sends POST but route expects GET:
  Flask: `@app.route('/add', methods=['GET', 'POST'])`
### 5. Server Errors
#### Error: Address Already in Use
1. Find and stop other server (Ctrl+C in other terminal)
2. Kill process: Mac/Linux `lsof -i :5000` then `kill <PID>` / Windows `netstat -ano | findstr :5000` then `taskkill /PID <PID> /F`
3. Use different port: Flask `app.run(debug=True, port=5001)` / Sinatra `set :port, 4568`
### 6. Function/Route Errors
#### Error: Nothing Returned from Route
**Flask:**
```python
@app.route('/')
def home():
    notes = get_notes()
    return render_template('index.html', notes=notes)  # Must return something
```
**Sinatra:**
```ruby
get '/' do
  @notes = get_notes
  erb :index  # Must return something
end
```
## Error Diagnosis Process
1. **Get info:** exact error message, file/line number, what they tried, terminal output
2. **Identify category:** IndentationError, TemplateNotFound, ModuleNotFoundError, 404, Address already in use, NameError
3. **Guide to solution:** explain cause, show fix steps, explain why it works, verify
4. **Teach prevention:** how to avoid in future
## Additional Resources
- `resources/flask-errors.md` - Flask-specific issues
- `resources/sinatra-errors.md` - Sinatra-specific issues
- `resources/general-errors.md` - Language-agnostic issues

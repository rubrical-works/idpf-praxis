# Triangulation Examples
**Version:** {{VERSION}}
Multiple specific tests guide toward a general implementation.
**Process:** Test 1 -> hardcoded value | Test 2 -> hardcoded fails | Generalize to pass both
## Example 1: Addition
```python
# Test 1
def test_adds_two_and_three():
    assert add(2, 3) == 5
# Fake: return 5

# Test 2 (triangulate)
def test_adds_one_and_one():
    assert add(1, 1) == 2
# Hardcoded 5 fails -> must generalize

# Generalize
def add(a, b):
    return a + b
```
## Example 2: FizzBuzz
```python
# Step 1: fizzbuzz(1) == "1" -> return "1"
# Step 2: fizzbuzz(2) == "2" -> return str(n)
# Step 3: fizzbuzz(3) == "Fizz" -> if n % 3 == 0: return "Fizz"; return str(n)
# Step 4: fizzbuzz(6) == "Fizz" -> already passes (general for multiples of 3)
# Continue: Buzz (5), FizzBuzz (15), etc.
```
## When to Use
| Situation | Approach |
|-----------|----------|
| Solution obvious | Implement directly |
| Solution unclear | Triangulate |
| Complex algorithm | Triangulate step by step |
| Simple utility | Implement directly |
**Signs you need more tests:** Implementation too specific, hardcoded values remain, edge cases uncovered
## Workflow
```
Test 1 -> Fake It (hardcode)
    |
Test 2 -> Forces generalization
    |
Test 3 -> Confirms pattern
    |
Implementation complete
```
## Patterns
- **Edge to Center:** Simplest case -> basic case -> complex case
- **Happy to Sad:** Success -> another success -> error case
## Quick Reference
| Tests | Implementation |
|-------|----------------|
| 1 test | Can hardcode |
| 2 tests | Must start generalizing |
| 3+ tests | Should be general |
> "As tests get more specific, code gets more generic." -- Robert C. Martin

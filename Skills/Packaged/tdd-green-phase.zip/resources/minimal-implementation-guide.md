# Minimal Implementation Guide
**Version:** {{VERSION}}
**Goal:** Write the simplest code that makes the test pass. Not the best. Not the most complete. Just passing.
## YAGNI Principle
Don't implement features until a test requires them.
**Example:**
```python
# Test requires:
def test_user_has_email():
    user = User("test@example.com")
    assert user.email == "test@example.com"

# YAGNI:
class User:
    def __init__(self, email):
        self.email = email

# Over-engineered (violates YAGNI):
class User:
    def __init__(self, email, name=None, age=None, phone=None):
        # ... 7 extra fields with no test coverage
```
**YAGNI Checklist:** Does a failing test require this? Will test fail without it? Am I guessing future needs?
## Avoiding Premature Optimization
**Make it work, then make it right, then make it fast.** GREEN = "make it work" only.
Optimize in REFACTOR phase, when performance tests fail, or when profiling shows bottleneck.
## Strategies
### Fake It
```python
def add(a, b):
    return 5  # Hardcoded - generalize with more tests
```
### Obvious Implementation
```python
def add(a, b):
    return a + b  # Solution is clear
```
### Triangulation
Multiple tests drive general solution (see triangulation-examples.md).
## Common Mistakes
**Anticipating future tests** - Don't handle empty lists or negatives if no test requires it
**Adding error handling early** - Add when a test requires it
## Quick Reference
| Do | Don't |
|----|-------|
| Pass the current test | Anticipate future tests |
| Use simplest solution | Optimize prematurely |
| Hardcode if appropriate | Over-generalize early |
| Wait for tests to drive design | Design without tests |
```
Does my test pass? -> Yes -> Stop coding
                   -> No  -> Write minimal fix
```

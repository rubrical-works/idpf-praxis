# GREEN Phase Checklist
**Version:** {{VERSION}}
## Before Implementing
- [ ] RED phase complete with verified failing test
- [ ] Test requirements clearly understood
- [ ] Minimum implementation approach identified
- [ ] No plans to add untested features
## Writing Implementation
- [ ] Code implements exactly what test requires
- [ ] Implementation is minimal (YAGNI)
- [ ] No features beyond test scope
- [ ] Code is clear and understandable
- [ ] Implementation complete (no placeholders)
## Executing
- [ ] Runs without errors
- [ ] Target test PASSES (green)
- [ ] No unexpected side effects
## Regression Check
- [ ] Full test suite executed
- [ ] All existing tests still pass
- [ ] No regressions introduced
## Before REFACTOR
- [ ] Test green and verified
- [ ] Implementation minimal but complete
- [ ] No broken tests
- [ ] Proceed autonomously to REFACTOR phase
## Quick Diagnostics
- **Test still fails** -> Implementation incomplete; revise
- **Other tests break** -> Regression; fix to keep all green
- **Seems too simple** -> That's OK! Future tests drive complexity
## YAGNI Reminders
- No "might need later" features
- No premature optimization
- No abstractions before third use

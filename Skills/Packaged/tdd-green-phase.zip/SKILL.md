---
name: tdd-green-phase
description: Guide experienced developers through GREEN phase of TDD cycle - writing minimal implementation to pass failing tests
version: "0.55.0"
license: Complete terms in LICENSE.txt
---
# TDD GREEN Phase
## When to Use
- RED phase test verified as failing
- Proceeding autonomously from RED phase
- Implementing feature to pass test
## Prerequisites
- Completed RED phase with verified failing test
- Clear understanding of what test expects
- Claude Code available for execution and testing
## Objective
**Write the minimum code to make the test pass.**
- Implements exactly what test requires, nothing more
- Simplest solution that makes test green
- No premature optimization
## Workflow
### Step 1: Understand Test Requirements
- What behavior, inputs, outputs does test define?
- **Key:** Test defines the contract. Implementation fulfills it, nothing more.
### Step 2: Plan Minimal Implementation
**Identify:** Minimum logic, required data structures, necessary dependencies
**Avoid:** Features not in test, abstractions not yet needed, optimizations, untested error handling
### Step 3: Implement to Pass Test
**ASSISTANT provides in single code block:**
```
TASK: [Brief description of implementation]
STEP 1: [Open/locate implementation file]
STEP 2: [Navigate to specific location]
STEP 3: [Add/modify implementation code - COMPLETE code block]
STEP 4: [Context about implementation choices]
STEP 5: [Save file]
STEP 6: [Run test command]
STEP 7: [Verify test PASSES]
STEP 8: [Report back: Did test pass?]
```
### Step 4: Execute and Verify
- [ ] Test executed without errors
- [ ] Test passed (green)
- [ ] No other tests broke
- [ ] Implementation is minimal
### Step 5: Analyze
- **Passes** -> GREEN complete, proceed autonomously to REFACTOR
- **Still fails** -> ASSISTANT revises, repeat Step 3
- **Other tests fail** -> Regression; ASSISTANT fixes, re-run all
## Best Practices
### YAGNI
- Hard-coded values acceptable if test passes
- Trust future tests to drive future features
- Rule of Three: abstract after third duplication
### Simplest Thing That Works
```
Test: Function should return sum of two numbers
WRONG: Generic calculation engine, config system, plugin architecture
RIGHT: Function takes two parameters, returns their sum. Done.
```
### Hard-Code First, Generalize Later
- Specific output expected? Return it hard-coded. Generalize when future tests require.
## Common Mistakes
| Mistake | Solution |
|---------|----------|
| Over-implementation | Implement ONLY what test requires |
| Premature abstraction | Wait for Rule of Three |
| Ignoring failure details | Read failure message carefully |
| Breaking existing tests | Run full suite, fix regressions first |
## Implementation Strategies
| Strategy | When | Example |
|----------|------|---------|
| Fake It | Simple test, clear path | `return 5` (hardcoded) |
| Obvious Implementation | Straightforward solution | `return a + b` |
| Triangulation | Unclear generalization | Multiple tests force it |
## Integration with IDPF-Agile
TDD executes **autonomously**. Only required user interaction: story completion (In Review -> Done).
## GREEN Phase Checklist
- [ ] Target test PASSES (green)
- [ ] Implementation is minimal (no over-engineering)
- [ ] No existing tests broke (full suite green)
- [ ] No untested features added
## Resources
- `resources/green-phase-checklist.md` - Quick reference checklist
- `resources/minimal-implementation-guide.md` - How to identify minimum code
- `resources/triangulation-examples.md` - When and how to use triangulation
## Relationship to Other Skills
**Flows from:** `tdd-red-phase` | **Flows to:** `tdd-refactor-phase`
**Related:** `tdd-failure-recovery`, `test-writing-patterns`
---
**End of TDD GREEN Phase Skill**
